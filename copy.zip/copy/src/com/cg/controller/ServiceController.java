package com.cg.controller;

import java.lang.Character.Subset;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Service;
import com.cg.bean.SubService;
import com.cg.service.Iservice;

@Controller
public class ServiceController {

	@Autowired
	Iservice serviceImpl;
	
	List<Service> serviceList = new ArrayList<Service>();
	
	@RequestMapping(value="/servicePage",method=RequestMethod.GET)
	public ModelAndView servicePage(){
		serviceList = serviceImpl.fetchListOfServices();
		ModelAndView mav = new ModelAndView("service");
		mav.addObject("service", new Service());
		mav.addObject("serviceList", serviceList);
		return mav;
	}
	
	@RequestMapping(value="/subServicePage",method=RequestMethod.GET)
	public ModelAndView subServicePage(){
		List<Service> allServicesList = serviceImpl.fetchListOfServices();
		//List<SubService> subServiceList = serviceImpl.fetchListOfSubService();
		ModelAndView mav = new ModelAndView("subService");
		mav.addObject("subService", new SubService());
		//mav.addObject("subServiceList", subServiceList);
		mav.addObject("allServicesList", allServicesList);
		return mav;
	}
	
	@RequestMapping(value="/addService",method=RequestMethod.POST)
	public ModelAndView addService(@ModelAttribute("service")@Valid Service service ,BindingResult result){
		ModelAndView mav = new ModelAndView("service");
		for (Service service2 : serviceList) {
			if(service2.getServiceName().equals(service.getServiceName())){
				System.out.println("error occured");
				result.rejectValue("serviceName", "error.service", "Service Name is already existing");
			}
		}
		if(result.hasErrors()){
			mav.addObject("serviceList", serviceList);
			return mav;
		}
		else{
			serviceList = serviceImpl.addService(service);
			mav.addObject("serviceList", serviceList);
			mav.addObject("service", new Service());
			return mav;
		}
	}
	
	@RequestMapping(value="/edit", method = RequestMethod.GET)
	public ModelAndView editService(@RequestParam("id") int serviceId){
		Service serviceEdit = new Service();
		for (Service service : serviceList) {
			if(serviceId == service.getServiceId()){
				serviceEdit=service;
				serviceList.remove(service);
				break;
			}
			else{
				continue;
			}
		}
		ModelAndView mav = new ModelAndView("service");
		mav.addObject("service", serviceEdit);
		mav.addObject("serviceList", serviceList);
		return mav;
		
	}
	@RequestMapping(value="/delete", method = RequestMethod.GET)
	public ModelAndView deleteService(@RequestParam("id") int serviceId){
		serviceList = serviceImpl.deleteService(serviceId);
		ModelAndView mav = new ModelAndView("service");
		Service service = new Service();
		mav.addObject("service",service);
		mav.addObject("serviceList", serviceList);
		return mav;
		
	}
	
	@RequestMapping(value="/addSubServices",method=RequestMethod.POST)
	public ModelAndView addSubServices(@ModelAttribute("subService") SubService subService){
		ModelAndView mav = new ModelAndView("subService");
		List<Service> allServicesList = serviceImpl.fetchListOfServices();
		//List<SubService> subServiceList = serviceImpl.fetchListOfSubService();
		subService.setServiceId(subService.getService().getServiceId());
		serviceImpl.addSubservice(subService);
		//mav.addObject("subServiceList", subServiceList);
		mav.addObject("allServicesList", allServicesList);
		mav.addObject("subService", new SubService());
		return mav;
	}
	
	
}
