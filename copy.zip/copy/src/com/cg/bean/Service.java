package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.UniqueConstraint;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Service {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int serviceId;
	@NotEmpty(message="Service Name Cannot be empty")
	@Column(unique=true)
	private String serviceName;
	@NotEmpty(message="Application Name cannot be empty")
	private String applicationName;
	@NotEmpty(message="Vendor cannot be empty")
	private String vendor;
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	@Override
	public String toString() {
		return "Service [serviceId=" + serviceId + ", serviceName="
				+ serviceName + ", applicationName=" + applicationName
				+ ", vendor=" + vendor + "]";
	}
}
