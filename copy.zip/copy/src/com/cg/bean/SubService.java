package com.cg.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Transient;

import org.hibernate.annotations.ForeignKey;

@Entity
public class SubService {
	
	private int serviceId;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int subServiceId;
	private String subServiceName;
	@Transient
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="serviceId")
	private Service service;
	
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public int getSubServiceId() {
		return subServiceId;
	}
	public void setSubServiceId(int subServiceId) {
		this.subServiceId = subServiceId;
	}
	public String getSubServiceName() {
		return subServiceName;
	}
	public void setSubServiceName(String subServiceName) {
		this.subServiceName = subServiceName;
	}
	public Service getService() {
		return service;
	}
	public void setService(Service service) {
		this.service = service;
	}
	
	@Override
	public String toString() {
		return "SubService [serviceId=" + serviceId + ", subServiceId="
				+ subServiceId + ", subServiceName=" + subServiceName
				+ ", service=" + service + "]";
	}
}
