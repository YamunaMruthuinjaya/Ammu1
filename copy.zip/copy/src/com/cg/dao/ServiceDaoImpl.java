package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.bean.Service;
import com.cg.bean.SubService;


@Repository
public class ServiceDaoImpl implements IServiceDao{

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public List<Service> addService(Service service) {

		List<Service> serviceList = new ArrayList<Service>();
		
		Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.saveOrUpdate(service);
        serviceList = session.createQuery("from Service").list();
        session.getTransaction().commit(); 
        session.close();
        
		return serviceList;
		
	}

	@Override
	public List<Service> deleteService(int serviceId) {

		List<Service> serviceList = new ArrayList<Service>();
		Session session = sessionFactory.openSession();
        session.beginTransaction(); 
        Service service = (Service) session.get(Service.class, serviceId); 
        session.delete(service);
        serviceList = session.createQuery("from Service").list();
        session.getTransaction().commit(); 
        session.close();
		return serviceList;
	}

	@Override
	public List<Service> fetchListOfServices() {
		
		List<Service> serviceList = new ArrayList<Service>();
		
		Session session = sessionFactory.openSession();
        session.beginTransaction();
        serviceList = session.createQuery("from Service").list();
        session.getTransaction().commit(); 
        session.close();
        
		return serviceList;
			
	}

	@Override
	public void addSubService(SubService subService) {
		
		Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.saveOrUpdate(subService);
        session.getTransaction().commit(); 
        session.close();
	}

	/*@Override
	public List<SubService> fetchListOfSubService() {
		
		List<SubService> subServiceList = new ArrayList<SubService>();
		Session session = sessionFactory.openSession();
        session.beginTransaction();
        subServiceList = session.createQuery("select s.serviceName,ss.subServiceName,s.applicationName,s.vendor from service s, subservice ss where s.serviceId=ss.serviceId").list();
        session.getTransaction().commit(); 
        session.close();
		return subServiceList;
	}*/

}
