package com.cg.service;

import java.util.List;

import com.cg.dto.Student;

public interface IStudService {

	boolean registerStud(Student stud);

	List<Student> fetchStuds();

	Student delStud(int sId);

}
