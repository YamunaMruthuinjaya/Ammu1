package com.cg.exception;

public class StudException extends Exception{

}
