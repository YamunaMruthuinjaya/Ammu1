package com.cg.dao;

import java.util.List;

import com.cg.dto.Student;

public interface IStudDao {

	boolean registerStud(Student stud);

	List<Student> fetchStuds();

	Student delStud(int sId);

}
