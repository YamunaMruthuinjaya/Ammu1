package com.cg.eztrac.common.impl;

import com.cg.eztrac.cache.ICacheManager;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

public class CacheManagerImpl implements ICacheManager {

	final CacheManager cm = CacheManager.getInstance();
	private String className = CacheManagerImpl.class.getSimpleName();
	
	public boolean addDataToCache(Element element,String cacheName){
		String methodName = "addDataToCache";
		LoggerManager.writeInfoLog(className,methodName ,ICommonConstants.LOGIN_SERVICE_LOG_KEY, "Before adding the data into cache");
		boolean status=false;
		try {
			Cache cache = cm.getCache(cacheName);
			int size = cache.getSize();
			int diskStoreSize = cache.getDiskStoreSize();
			cache.put(element);
			status=true;
			LoggerManager.writeInfoLog(className,methodName ,ICommonConstants.LOGIN_SERVICE_LOG_KEY, "Added Element:"+element.getKey()+" into cache:"+cacheName+" - CACHE In-Memory Size:"+size+" - CACHE DiskStoreSize:"+diskStoreSize);
		} catch (Exception e) {
			LoggerManager.writeErrorLog(className, methodName, e.getMessage(),e , " Exception while adding data into EHCACHE addDataToCache");
			status=false;
		}
		
		return status;
	}

	@Override
	public Element getDataFromCache(String objectValueName,String cacheName) {
		Element element = null;
		String methodName = "getDataFromCache";
		try {
			Cache cache = cm.getCache(cacheName);
			element = cache.get(objectValueName);
		} catch (Exception e) {
			LoggerManager.writeErrorLog(className, methodName, e.getMessage(),e , " Exception while getting data from EHCACHE addDataToCache");
			element = null;
		}
		return element;
	}

}