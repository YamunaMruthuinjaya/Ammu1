package com.cg.eztrac.common;

public enum UserStatus {
	ACTIVE,
	INACTIVE;
}
