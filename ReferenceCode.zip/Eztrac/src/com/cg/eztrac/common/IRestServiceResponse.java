package com.cg.eztrac.common;
public interface IRestServiceResponse {
	
	String getTokenId();
	
	String getChannelId();
	
	String getResponseCode();
	
	String getResponseDescription();

} 