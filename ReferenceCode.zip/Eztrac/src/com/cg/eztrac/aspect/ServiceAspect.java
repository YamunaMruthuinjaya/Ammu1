package com.cg.eztrac.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.vo.BaseVO;

@Aspect
@Component
public class ServiceAspect {
	
	@Before("execution( * com.cg.eztrac.controller.*Controller.*(..))")
	public void setTokenAdvice(JoinPoint pjp) {
		Object[] arguments = pjp.getArgs();
			for (Object parameter : arguments) {
				if(null != parameter){
					if( parameter instanceof BaseVO ){
					BaseVO baseVO = (BaseVO)parameter;
					baseVO.setTokenId(CommonUtility.getTokenId());
				}
			}
		}
	}
}
