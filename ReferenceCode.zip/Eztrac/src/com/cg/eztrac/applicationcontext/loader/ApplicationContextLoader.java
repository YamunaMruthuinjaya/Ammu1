package com.cg.eztrac.applicationcontext.loader;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.domain.PMDetailsDO;
import com.cg.eztrac.domain.PMODetailsDO;
import com.cg.eztrac.domain.ResourceDetailsDO;
import com.cg.eztrac.domain.RolePermissionDO;
import com.cg.eztrac.domain.SectionDetailDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.handler.OnLoadHandler;
import com.cg.eztrac.service.domainobject.SystemDetailsDO;
import com.cg.eztrac.vo.ParamVO;
import com.cg.eztrac.vo.SectionVO;

import net.sf.ehcache.CacheManager;

@Component
public class ApplicationContextLoader {
	
	private static final String CLASS_NAME = ApplicationContextLoader.class.getSimpleName();
	@Autowired 	ServletContextImpl servletContextImpl;
	
	@Autowired Environment env;
	
	@Autowired OnLoadHandler onLoadHandler;
	
	/** method called only once at application start up to load COMMON SERIVES(SECTION DETAIL,ROLE PERMISSION,PARAM) from service*/
	@EventListener(ContextRefreshedEvent.class)
	public void contextRefreshedEvent(ContextRefreshedEvent event)  throws CustomException{
		final String METHOD_NAME = "contextRefreshedEvent";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.APPLICATION_CONTEXT+" Application context", "application context called upon application start-up");
		/** condition to avoId multiple load from context ( webcontext and dispatcherServlet context ) */
		try {
			if(null == event.getApplicationContext().getParent()) {
				loadSystemDetails();
				loadParamDetailsIntoContext();
				
				if (env.getProperty("eztrack.security.enableflag").equalsIgnoreCase(ICommonConstants.N_STRING)) {
					loadSectionDetailsIntoContext();
					loadRolePermissionDetailsIntoContext();
					allRoleMenuAccebiltiy();
				}
				loadPMODetails();
				loadPMDetails();
				loadAllResourceDetails();
			}
		} catch (CustomException e) {
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, e.getMessage(),e , ICommonConstants.APPLICATION_CONTEXT+" exception while loading services into  the application context ");
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
	}
	

	/**CALL PMO_detail_service and ADD to servlet context*/
	public void loadPMODetails() throws CustomException {
        String methodName="loadPMODetails";
        LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "Before calling the loadPMODetails() from Application context");
        List<PMODetailsDO> pmoDetailsDOList = onLoadHandler.loadPMODetails();
        if(null != pmoDetailsDOList && !pmoDetailsDOList.isEmpty()){
               servletContextImpl.addObjectToServletContext(ICommonConstants.PMO_DETAILS_CONTEXT, pmoDetailsDOList);
        }
        LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "loadPMODetails() is called and data is added to servlet context");
	}

	private void loadPMDetails() throws CustomException{
		String methodName="loadPMDetails";
        LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "Before calling the loadPMDetails() from Application context");
        List<PMDetailsDO> pmDetailsDOList = onLoadHandler.loadPMDetails();
        if(null != pmDetailsDOList && !pmDetailsDOList.isEmpty()){
               servletContextImpl.addObjectToServletContext(ICommonConstants.PM_DETAILS_CONTEXT, pmDetailsDOList);
        }
        LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "loadPMDetails() is called and data is added to servlet context");
		
	}
	
	private void loadAllResourceDetails() throws CustomException{
		String methodName="loadAllResourceDetails";
        LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "Before calling the loadAllResourceDetails() from Application context");
        List<ResourceDetailsDO> resourceDetailsDOList = onLoadHandler.loadResourceDetails();
        if(null != resourceDetailsDOList && !resourceDetailsDOList.isEmpty()){
               servletContextImpl.addObjectToServletContext(ICommonConstants.ALL_RESOURCE_DETAILS_CONTEXT, resourceDetailsDOList);
        }
        LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "loadAllResourceDetails() is called and data is added to servlet context");
				
	}

	/**CALL system_detail_service and ADD to servlet context*/
	public void loadSystemDetails() throws CustomException {
        String methodName="loadSystemDetails";
        LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "Before calling the loadSystemDetails() from Application context");
        List<SystemDetailsDO> systemDetailsDOList = onLoadHandler.loadSystemDetails();
        if(null != systemDetailsDOList && !systemDetailsDOList.isEmpty()){
               servletContextImpl.addObjectToServletContext(ICommonConstants.SYSTEM_SUBSYSTEM_DETAILS_CONTEXT, systemDetailsDOList);
        }
        LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "loadSystemDetails() is called and data is added to servlet context");
	}
	
	/**CALL param_details_service and ADD to servlet context*/
	public void loadParamDetailsIntoContext() throws CustomException {
		String methodName="loadParamDetailsIntoContext";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.APPLICATION_CONTEXT+"In application context", "Before calling the loadParamDetails() from Application context");
		Map<String, List<ParamVO>> loadParamDetails = onLoadHandler.loadParamDetails();
		if(null != loadParamDetails && !loadParamDetails.isEmpty()){
			servletContextImpl.addObjectToServletContext(ICommonConstants.ALL_PARAM_DETAILS_CONTEXT, loadParamDetails);
		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.APPLICATION_CONTEXT+" Application context", "loadParamDetails() is called and data is added to servlet context");
	}
	
	/**CALL section_details_service and ADD to servlet context*/
	public void loadSectionDetailsIntoContext() throws CustomException {
		String methodName="loadSectionDetailsIntoContext";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.APPLICATION_CONTEXT+"In application context",ICommonConstants.SECTION_DETAILS_SERVICES_FLOW+ "Before calling the loadSectionDetails() from Application context");
		List<SectionDetailDO> loadSectionDetails = onLoadHandler.loadSectionDetails();
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.APPLICATION_CONTEXT+"In application context",ICommonConstants.SECTION_DETAILS_SERVICES_FLOW+ "After calling the loadSectionDetails() from Application context");
		if(null != loadSectionDetails && !loadSectionDetails.isEmpty()){
			servletContextImpl.addObjectToServletContext(ICommonConstants.ALL_SEC_DETAILS_CONTEXT, loadSectionDetails);
		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName,ICommonConstants.APPLICATION_CONTEXT+" Application context", ICommonConstants.SECTION_DETAILS_SERVICES_FLOW+"loadSectionDetails() is called and data is added to servlet context");
	}
	
	/**CALL role_permission_service and ADD to servlet context*/
	public void loadRolePermissionDetailsIntoContext() throws CustomException {
		String methodName="loadRolePermissionDetailsIntoContext";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.APPLICATION_CONTEXT+" Application context", ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+ "Before calling the loadRolePermissionDetails() from Application context");
		List<RolePermissionDO> loadRolePermissionDetails = onLoadHandler.loadRolePermissionDetails();
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.APPLICATION_CONTEXT+" Application context", ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+ "After calling the loadRolePermissionDetails() from Application context");
		if(null != loadRolePermissionDetails && !loadRolePermissionDetails.isEmpty()){
			servletContextImpl.addObjectToServletContext(ICommonConstants.ALL_ROLE_DETAILS_CONTEXT, loadRolePermissionDetails);
		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.APPLICATION_CONTEXT+" Application context", ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+"loadRolePermissionDetails() is called and data is added to servlet context");
	}
	
	public void allRoleMenuAccebiltiy() throws CustomException {
		String methodName="allRoleMenuAccebiltiy";
		Map<Integer, Map<Integer, List<SectionVO>>> allRoleMenuAccebiltiy = CommonUtility.getUserRoleAccebiltiyObj(servletContextImpl.getObjectFromServletContext(ICommonConstants.ALL_ROLE_DETAILS_CONTEXT), servletContextImpl.getObjectFromServletContext(ICommonConstants.ALL_SEC_DETAILS_CONTEXT),false);
		if(null != allRoleMenuAccebiltiy && !allRoleMenuAccebiltiy.isEmpty()){
			servletContextImpl.addObjectToServletContext(ICommonConstants.All_ROLE_MENU_ACCESS_CONTEXT, allRoleMenuAccebiltiy);
		} else{
			servletContextImpl.addObjectToServletContext(ICommonConstants.All_ROLE_MENU_ACCESS_CONTEXT, null);
		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.APPLICATION_CONTEXT+" Application context", "All role menu accessbility data structure is created and data is added to servlet context");
	}
	
	@EventListener(ContextClosedEvent.class)
	public void contextClosedEvent(ContextClosedEvent event) throws CustomException{
		final String METHOD_NAME = "contextClosedEvent";
		try {
			if(event.getApplicationContext().getParent() == null){
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.APPLICATION_CONTEXT+" Application context", "application context is closed and before removing data from cache");
				CacheManager cm = CacheManager.getInstance();
				if(null != cm) {
					String[] cacheNames = cm.getCacheNames();
					for (String cacheName : cacheNames) {
						cm.removeCache(cacheName);
					}
				}
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.APPLICATION_CONTEXT+" Application context", "application context is closed and after removing data from cache");
			}
		} catch (CustomException e) {
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, e.getMessage(),e , " exception while closing the application context ");
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
	}

}
