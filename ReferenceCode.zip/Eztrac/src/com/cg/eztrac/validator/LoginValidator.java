package com.cg.eztrac.validator;

import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.util.EztracValidationUtil;
import com.cg.eztrac.vo.LoginVO;

@Component(value="loginValidator")
public class LoginValidator implements Validator {
	 String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";
	 String pattern1="";
	 /*(?=.*[0-9]) a digit must occur at least once
	 (?=.*[a-z]) a lower case letter must occur at least once
	 (?=.*[A-Z]) an upper case letter must occur at least once
	 (?=.*[@#$%^&+=]) a special character must occur at least once
	 (?=\\S+$) no whitespace allowed in the entire string
	 .{8,} at least 8 characters*/
	 Pattern patternc = Pattern.compile(pattern);
	 
	 private static final String CLASSNAME = "LoginValidator";
	
	@Override
	public boolean supports(Class<?> clazz) {
		return LoginVO.class.isAssignableFrom(clazz);		
	}	
  
	@Override
	public void validate(Object target, Errors errors) {
		String methodName = "validate";
		 LoginVO loginVO = (LoginVO) target;
		
		LoggerManager.writeInfoLog(CLASSNAME,methodName, methodName , methodName);
		
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "username", "error.login.username.required");
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "password","error.login.password.required");
		
	      if (loginVO.getUsername() != null && (loginVO.getUsername().length() < 5 ||
	    		  loginVO.getUsername().length() > 9)) {
	          errors.rejectValue("username", "error.login.username.len");
	      }
	      
	      if (loginVO.getPassword() != null){
	    	  if(loginVO.getPassword().contains(" ") ) {
	    		  errors.rejectValue("password", "error.login.password.spaces");
	    	  }
	    	  if (loginVO.getPassword().length() < 5 &&
	    			  loginVO.getPassword().length() > 19) {
	    		  errors.rejectValue("password", " error.login.password.len");
	    	  }
//	    	  Matcher match = patternc.matcher(loginVO.getPassword());
	    	  /*if (!match.matches()) {
	    		  errors.rejectValue("password", " Password did not match the pattern");
	    	  }*/
	      }
	}
}
