package com.cg.eztrac.validator;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.util.EztracValidationUtil;
import com.cg.eztrac.vo.PerVO;

@Component(value="perCCValidator")
public class PerCCValidator implements Validator {
	
	private static final String CLASS_NAME = "PerCCValidator";
	
	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object perObj, Errors errors) {
		// TODO Auto-generated method stub
		final String METHOD_NAME = "validate";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Server side validations for PER","Per validator");
		
		PerVO perVo = (PerVO)perObj;
		//PerChangeControlVO perCcVo = (PerChangeControlVO)perCcObj;
		
	//	EztracValidationUtil.rejectValue(errors, "perNumber", "required value");
		
		//CC Number
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "perChangeControl.ccNumber", "error.perchangecontrol.ccNumber.required");
		
		//Category 
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors,"perChangeControl.ccCategoryId","error.perchangecontrol.ccCategoryId.required");
		
		//Change Control Phase
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors,"perChangeControl.ccPhase","error.perchangecontrol.ccPhase.required");
		
		//Start Date and End Date
		if(!StringUtils.isEmpty(perVo.getPerChangeControl().getCcStartDate()) && !StringUtils.isEmpty(perVo.getPerChangeControl().getCcEndDate())) {
			EztracValidationUtil.rejectIfDateComparisonFails(errors, "perChangeControl.ccEndDateString", "error.perchangecontrol.ccEndDateString.invalid", perVo.getPerChangeControl().getCcStartDate(), perVo.getPerChangeControl().getCcEndDate());
	     } /*else if(StringUtils.isEmpty(perVo.getPerChangeControl().getCcStartDate()) && !StringUtils.isEmpty(perVo.getPerChangeControl().getCcEndDate())) {
				EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "perChangeControl.ccStartDate", "error.per.ccStartDate.required");
			}*/

		//Start Date and cancellation Date
		if(!StringUtils.isEmpty(perVo.getPerChangeControl().getCcStartDate()) && !StringUtils.isEmpty(perVo.getPerChangeControl().getPerCCCancellationDate())) {
			EztracValidationUtil.rejectIfDateComparisonFails(errors, "perChangeControl.perCCCancellationDateString", "error.perchangecontrol.perCCCancellationDateString.invalid", perVo.getPerChangeControl().getCcStartDate(), perVo.getPerChangeControl().getPerCCCancellationDate());
        }
		
		//Start Date and Completion Date
		if(!StringUtils.isEmpty(perVo.getPerChangeControl().getCcStartDate()) && !StringUtils.isEmpty(perVo.getPerChangeControl().getPerCCCompletionDate())) {
			EztracValidationUtil.rejectIfDateComparisonFails(errors, "perChangeControl.perCCCompletionDateString", "error.perchangecontrol.perCCCompletionDateString.invalid", perVo.getPerChangeControl().getCcStartDate(), perVo.getPerChangeControl().getPerCCCompletionDate());
        }

}
}
