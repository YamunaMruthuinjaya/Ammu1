package com.cg.eztrac.validator;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.exception.CustomException;

@Component(value="dateRange")
public class DateRange {
	
	private static final String CLASS_NAME = "DateRange";
	private static final DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	String stDate;
	String endDate;
	String currentWeekDateRange;

	public static void main(String[] args) {
		DateRange dateRange=new DateRange();
		dateRange.getCurrentDate();

	}

	public String getCurrentDate()
	{  
		final String METHOD_NAME = "getCurrentDate";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered getCurrentDate method to calculate the CurrentWeekDateRange", "Start");
		
	        try {
				Calendar cal1 = Calendar.getInstance();
				Date currentDate = cal1.getTime();
				LocalDate currentLocalDate = currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				int currentMonth = currentLocalDate.getMonthValue();
      
				Calendar cal2 = Calendar.getInstance();
				cal2.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);	  
				
				Date date1 = cal2.getTime();
				LocalDate localDate1 = date1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				int mondayMonth = localDate1.getMonthValue();
				
				if(mondayMonth<currentMonth)
				{
				Calendar cal3 = Calendar.getInstance();  
				cal3.set(Calendar.DAY_OF_MONTH, 1);
				    stDate=sdf.format(cal3.getTime());
				}
				else
				{
				    stDate=sdf.format(cal2.getTime());
				}	        
				
				Calendar cal4=Calendar.getInstance();
				cal4.set(Calendar.DAY_OF_WEEK,Calendar.SUNDAY);
				cal4.set(Calendar.HOUR_OF_DAY,0);
   
				cal4.set(Calendar.MINUTE,0);
				cal4.set(Calendar.SECOND,0);
				cal4.add(Calendar.DATE,7);	        
      
				LocalDate localDate2 = cal4.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				int sundayMonth = localDate2.getMonthValue();
   
				if(sundayMonth>currentMonth)
				{
				  Calendar calendar = Calendar.getInstance();
				    int lastDate = calendar.getActualMaximum(Calendar.DATE);
				    calendar.set(Calendar.DATE, lastDate);
				    endDate=sdf.format(calendar.getTime());
				}
				else
				{	            	        
				endDate=sdf.format(cal4.getTime());
				}
				
				currentWeekDateRange=stDate+"-"+endDate;
			} catch (Exception e) {
				e.printStackTrace();
				throw new CustomException("", "Kindly reload the page!!");
			}
	        
	        LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the currentWeekDateRange from getCurrentDate()", "End");
	        return currentWeekDateRange;
	}
	
}
