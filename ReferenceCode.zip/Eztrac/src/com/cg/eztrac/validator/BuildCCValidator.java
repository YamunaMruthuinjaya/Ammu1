package com.cg.eztrac.validator;


//BuildCCValidator
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.util.EztracValidationUtil;
import com.cg.eztrac.vo.BuildChangeControlVO;


@Component(value="buildCCValidator")
public class BuildCCValidator implements Validator {
	
	private static final String CLASS_NAME = "buildCCValidator";
	
	
	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object buildCcObj, Errors errors) {
		// TODO Auto-generated method stub
		final String METHOD_NAME = "validate";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Server side validations for Build","Build validator");
		
		
			BuildChangeControlVO buildCcVO=(BuildChangeControlVO)buildCcObj;

		
			EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildCcVO.BuildCCReqLoe","error.build_cc.loe.value" , buildCcVO.getBuildCCReqLoe(), 0, 500);
			EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildCcVO.BuildCCDesignLoe","error.build_cc.loe.value" , buildCcVO.getBuildCCDesignLoe(), 0, 500);
			EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildCcVO.BuildCCConLoe","error.build_cc.loe.value" , buildCcVO.getBuildCCConLoe(), 0, 500);
			EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildCcVO.BuildCCTestingLoe","error.build_cc.loe.value" , buildCcVO.getBuildCCTestingLoe(), 0, 500);
			EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildCcVO.BuildCCReleaseLoe","error.build_cc.loe.value" , buildCcVO.getBuildCCReleaseLoe(), 0, 500);			
		

}
}
