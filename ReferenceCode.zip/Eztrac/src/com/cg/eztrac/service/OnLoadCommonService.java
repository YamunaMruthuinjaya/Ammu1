package com.cg.eztrac.service;

import com.cg.eztrac.service.request.PMDetailsRequest;
import com.cg.eztrac.service.request.PMODetailsRequest;
import com.cg.eztrac.service.request.ParamDetailsRequest;
import com.cg.eztrac.service.request.ResourceDetailsRequest;
import com.cg.eztrac.service.request.RolePermissionRequest;
import com.cg.eztrac.service.request.SectionDetailRequest;
import com.cg.eztrac.service.request.SystemDetailsRequest;
import com.cg.eztrac.service.response.PMOResponse;
import com.cg.eztrac.service.response.PMResponse;
import com.cg.eztrac.service.response.ParamDetailsRes;
import com.cg.eztrac.service.response.ResourceResponse;
import com.cg.eztrac.service.response.RolePermissionRes;
import com.cg.eztrac.service.response.SectionsRes;
import com.cg.eztrac.service.response.SystemRes;

public interface OnLoadCommonService {
	
	public ParamDetailsRes getAllParamDetails(ParamDetailsRequest paramDetailsRequest);
	
	/*public RolePermissionRes getAllRolePermissionDetails(RolePermissionRequest rolePermissionRequest);*/
	public SystemRes getSystemDetails(SystemDetailsRequest systemDetailsRequest);
	public PMOResponse getPMODetails(PMODetailsRequest pmoDetailsRequest);
	public PMResponse getPMDetails(PMDetailsRequest pmDetailsRequest);
	public ResourceResponse getResourceDetails(ResourceDetailsRequest resourceDetailsRequest);
}
