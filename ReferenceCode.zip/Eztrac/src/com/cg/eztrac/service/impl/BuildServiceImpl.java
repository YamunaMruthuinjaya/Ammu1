package com.cg.eztrac.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.BuildDO;
import com.cg.eztrac.domain.BuildListDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.IServiceMandates;
import com.cg.eztrac.service.request.BuildChangeControlListRequest;
import com.cg.eztrac.service.request.BuildChangeControlRequest;
import com.cg.eztrac.service.request.BuildDeleteRequest;
import com.cg.eztrac.service.request.BuildDeleteResponse;
import com.cg.eztrac.service.request.BuildDetailsRequest;
import com.cg.eztrac.service.request.BuildInsertRequest;
import com.cg.eztrac.service.request.BuildListRequest;
import com.cg.eztrac.service.request.SaveChangeControlRequest;
import com.cg.eztrac.service.response.BuildChangeControlListResponse;
import com.cg.eztrac.service.response.BuildChangeControlResponse;
import com.cg.eztrac.service.response.BuildDetailsResponse;
import com.cg.eztrac.service.response.BuildInsertResponse;
import com.cg.eztrac.service.response.BuildListResponse;
import com.cg.eztrac.service.response.SaveChangeControlResponse;

@Component(value="buildServiceImpl")
public class BuildServiceImpl implements IServiceMandates {
	
	private static final String CLASS_NAME = BuildServiceImpl.class.getName();

	@Override
	public Object serviceProcessor(Object doObject, String action) throws CustomException {
		final String METHOD_NAME = "serviceProcessor";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Build serviceProcessor method", "");
		
		Object responseObject =null;
		try {
			if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildServiceImpl.serviceProcessor:","Build Details");
				BuildDO buildDO = (BuildDO)doObject;
				BuildDetailsRequest buildDetailsRequest = (BuildDetailsRequest) populateRequest(buildDO,action);
				BuildDetailsResponse buildDetailsResponse = (BuildDetailsResponse) invokeService(buildDetailsRequest,action);
				responseObject = populateResponse(buildDetailsResponse, buildDO,action);
			}
			else if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)){
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildServiceImpl.serviceProcessor:","Build List");
				BuildListDO buildListDO = (BuildListDO)doObject;
				BuildListRequest buildListRequest = (BuildListRequest) populateRequest(buildListDO, action);
				BuildListResponse buildListResponse = (BuildListResponse) invokeService(buildListRequest,action);
				responseObject = populateResponse(buildListResponse, buildListDO,action);
			}
			else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)){
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildServiceImpl.serviceProcessor:","Build Insert");
				BuildDO buildDO = (BuildDO)doObject;
				BuildInsertRequest buildInsertRequest = (BuildInsertRequest) populateRequest(buildDO, action);
				BuildInsertResponse buildInsertResponse = (BuildInsertResponse) invokeService(buildInsertRequest,action);
				responseObject = populateResponse(buildInsertResponse, buildDO,action);
			}
			else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)){
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildServiceImpl.serviceProcessor:","Build Delete");
				BuildDO buildDO = (BuildDO)doObject;
				BuildDeleteRequest buildDeleteRequest = (BuildDeleteRequest) populateRequest(buildDO, action);
				BuildDeleteResponse buildDeleteResponse = (BuildDeleteResponse) invokeService(buildDeleteRequest,action);
				responseObject = populateResponse(buildDeleteResponse, buildDO,action);
			}else if(action.equals(ICommonConstants.BUILD_CC_LIST_REQUEST_ACTION)){

				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildServiceImpl.serviceProcessor:","Build CC LIST");
				BuildDO buildDO = (BuildDO)doObject;
				BuildChangeControlListRequest buildChangeControlListRequest = (BuildChangeControlListRequest) populateRequest(buildDO, action);
				BuildChangeControlListResponse buildChangeControlListResponse = (BuildChangeControlListResponse) invokeService(buildChangeControlListRequest,action);
				responseObject = populateResponse(buildChangeControlListResponse, buildDO,action);

			}else if(action.equals(ICommonConstants.BUILD_CC_ID_REQUEST_ACTION)){

				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildServiceImpl.serviceProcessor:","Build CC");
				BuildDO buildDO = (BuildDO)doObject;
				BuildChangeControlRequest buildChangeControlRequest = (BuildChangeControlRequest) populateRequest(buildDO, action);
				BuildChangeControlResponse buildChangeControlResponse = (BuildChangeControlResponse) invokeService(buildChangeControlRequest,action);
				responseObject = populateResponse(buildChangeControlResponse, buildDO,action);
				
			}else if(action.equals(ICommonConstants.BUILD_CC_SAVE_ACTION)){

				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildServiceImpl.serviceProcessor:","Save Build CC");
				BuildDO buildDO = (BuildDO)doObject;
				SaveChangeControlRequest saveChangeControlRequest = (SaveChangeControlRequest) populateRequest(buildDO, action);
				SaveChangeControlResponse saveChangeControlResponse = (SaveChangeControlResponse) invokeService(saveChangeControlRequest,action);
				responseObject = populateResponse(saveChangeControlResponse, buildDO,action);
				
			}
		}
		catch (CustomException e) {
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		return responseObject;
	}

	@Override
	public Object populateRequest(Object requestObject, String action) throws CustomException {
		String METHOD_NAME = "populateRequest";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Build populateRequest method", "");
		
		if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildDetailRequest","Build Details");
			BuildDO buildDO = (BuildDO)requestObject;
			BuildDetailsRequest buildDetailsRequest = new BuildDetailsRequest();
			buildDetailsRequest.setBuildId(buildDO.getBuildId());
			buildDetailsRequest.setTokenId(buildDO.getTokenId());
			buildDetailsRequest.setChannelId("EZ");
			return buildDetailsRequest;
		}
		else if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildListRequest","Build List");
			BuildListDO buildListDO = (BuildListDO)requestObject;
			BuildListRequest buildListRequest = new BuildListRequest();
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildListDO.getBuild() to buildListRequest","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(buildListDO.getBuild(), buildListRequest);
			buildListRequest.setTokenId(buildListDO.getTokenId());
			buildListRequest.setChannelId("EZ");
			return buildListRequest;
		}
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildInsertRequest","Build Insert");
			BuildDO buildDO = (BuildDO)requestObject;
			BuildInsertRequest buildInsertRequest = new BuildInsertRequest();
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildDO to buildInsertRequest","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(buildDO, buildInsertRequest);
			buildInsertRequest.setChannelId("EZ");
			return buildInsertRequest;
		}
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildDeleteRequest","Build Delete");
			BuildDO buildDO = (BuildDO)requestObject;
			BuildDeleteRequest buildDeleteRequest = new BuildDeleteRequest();
			buildDeleteRequest.setBuildId(buildDO.getBuildId());
			buildDeleteRequest.setTokenId(buildDO.getTokenId());
			buildDeleteRequest.setChannelId("CN");
			return buildDeleteRequest;
		}
		else if(action.equals(ICommonConstants.BUILD_CC_LIST_REQUEST_ACTION)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populate BuildCC LIST Request","Build CC LIST");
			BuildDO buildDO = (BuildDO)requestObject;
			BuildChangeControlListRequest buildChangeControlListRequest = new BuildChangeControlListRequest();
			buildChangeControlListRequest.setBuildId(buildDO.getBuildId());
			buildChangeControlListRequest.setTokenId(buildDO.getTokenId());
			buildChangeControlListRequest.setChannelId("EZ");
			return buildChangeControlListRequest;
		}
		else if(action.equals(ICommonConstants.BUILD_CC_ID_REQUEST_ACTION)){

			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populate BuildCC Request","Build CC ");
			BuildDO buildDO = (BuildDO)requestObject;
			BuildChangeControlRequest buildChangeControlRequest = new BuildChangeControlRequest();
			buildChangeControlRequest.setBuildCCId(buildDO.getBuildChangeControl().getBuildCCId());
			buildChangeControlRequest.setTokenId(buildDO.getTokenId());
			buildChangeControlRequest.setChannelId("EZ");
			return buildChangeControlRequest;
		
			
		}
		else if(action.equals(ICommonConstants.BUILD_CC_SAVE_ACTION)){

			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populate Save BuildCC Request","Build CC Save");
			BuildDO buildDO = (BuildDO)requestObject;
			SaveChangeControlRequest saveChangeControlRequest = new SaveChangeControlRequest();
			saveChangeControlRequest.setBuildChangeControl(buildDO.getBuildChangeControl());
			saveChangeControlRequest.setTokenId(buildDO.getTokenId());
			saveChangeControlRequest.setChannelId("EZ");
			return saveChangeControlRequest;
		
			
		}
		else{
			throw new CustomException("400", "Invalid Request");
		}
	}

	@Override
	public Object invokeService(Object requestObject, String action) throws CustomException {
		final String METHOD_NAME = "invokeService";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Build invoke service method", "");
		
		if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			BuildDetailsRequest buildDetailsRequest = (BuildDetailsRequest) requestObject;
			BuildDetailsResponse response = null; 
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build Details", "Before calling rest service invocation");
				response= (BuildDetailsResponse) EztracRestClient.invokeRestService(buildDetailsRequest, CommonUtility.getValFrmAppUrlProp("ez.service.getBuildDetails.url"), BuildDetailsResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build Details", "After rest service invocation");
			}
			catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return response;
		}
		else if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			BuildListRequest buildListRequest = (BuildListRequest) requestObject;
			BuildListResponse response = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build List", "Before calling rest service invocation");
				response= (BuildListResponse) EztracRestClient.invokeRestService(buildListRequest, CommonUtility.getValFrmAppUrlProp("ez.service.getBuildList.url"), BuildListResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build List", "After rest service invocation");
			}
			catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_SB1001))
					{
						return response;
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return response;
		}
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
			BuildInsertRequest buildInsertRequest = (BuildInsertRequest) requestObject;
			BuildInsertResponse response = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build Insert", "Before calling rest service invocation");
				response = (BuildInsertResponse) EztracRestClient.invokeRestService(buildInsertRequest, CommonUtility.getValFrmAppUrlProp("ez.service.insertBuildDetails.url"), BuildInsertResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build Insert", "After rest service invocation");
			}
			catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WB1001) || 
							response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WB1003) )
					{
						return response;
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return response;
		}
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			BuildDeleteRequest buildDeleteRequest = (BuildDeleteRequest) requestObject;
			BuildDeleteResponse response = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build Delete", "Before calling rest service invocation");
				response = (BuildDeleteResponse) EztracRestClient.invokeRestService(buildDeleteRequest, CommonUtility.getValFrmAppUrlProp("ez.service.deleteBuildDetails.url"), BuildDeleteResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build Delete", "After rest service invocation");
			} catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WB1002)) 
					{
						return response;
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return response;
		} else if (action.equals(ICommonConstants.BUILD_CC_LIST_REQUEST_ACTION)) {

			BuildChangeControlListRequest buildCcListRequest = (BuildChangeControlListRequest) requestObject;
			BuildChangeControlListResponse buildCcListresponse = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,
						ICommonConstants.BUILD_SERVICE_LOG_KEY + "Build CC LIST",
						"Before calling rest service invocation");
				buildCcListresponse = (BuildChangeControlListResponse) EztracRestClient.invokeRestService(
						buildCcListRequest, CommonUtility.getValFrmAppUrlProp("ez.service.getBuildCCList.url"),
						BuildChangeControlListResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,
						ICommonConstants.BUILD_SERVICE_LOG_KEY + "Build CC LIST", "After rest service invocation");
			} catch (CustomException e) {
				if (null != buildCcListresponse) {
					if (buildCcListresponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1000)
							|| buildCcListresponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1001)) {
						throw new CustomException(buildCcListresponse.getResponseCode(),
								buildCcListresponse.getResponseDescription());
					} else if (buildCcListresponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WB1002)) {
						return buildCcListresponse;
					} else {
						throw new CustomException(e.getErrCode(), e.getErrMsg());
					}
				} else {
					throw new CustomException(e.getErrCode(), e.getErrMsg());
				}
			}
			return buildCcListresponse;

		}else if (action.equals(ICommonConstants.BUILD_CC_ID_REQUEST_ACTION)) {

			BuildChangeControlRequest buildCcRequest = (BuildChangeControlRequest) requestObject;
			BuildChangeControlResponse buildCcResponse = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,
						ICommonConstants.BUILD_SERVICE_LOG_KEY + "Build CC ",
						"Before calling rest service invocation");
				buildCcResponse = (BuildChangeControlResponse) EztracRestClient.invokeRestService(
						buildCcRequest, CommonUtility.getValFrmAppUrlProp("ez.service.getBuildCCDetails.url"),
						BuildChangeControlResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,
						ICommonConstants.BUILD_SERVICE_LOG_KEY + "Build CC Details", "After rest service invocation");
			} catch (CustomException e) {
				if (null != buildCcResponse) {
					if (buildCcResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1000)
							|| buildCcResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1001)) {
						throw new CustomException(buildCcResponse.getResponseCode(),
								buildCcResponse.getResponseDescription());
					} else if (buildCcResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WB1002)) {
						return buildCcResponse;
					} else {
						throw new CustomException(e.getErrCode(), e.getErrMsg());
					}
				} else {
					throw new CustomException(e.getErrCode(), e.getErrMsg());
				}
			}
			return buildCcResponse;

		}else if (action.equals(ICommonConstants.BUILD_CC_SAVE_ACTION)) {

			SaveChangeControlRequest saveChangeControlRequest = (SaveChangeControlRequest) requestObject;
			SaveChangeControlResponse saveChangeControlResponse = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,
						ICommonConstants.BUILD_SERVICE_LOG_KEY + "Build CC SAVE",
						"Before calling rest service invocation");
				saveChangeControlResponse = (SaveChangeControlResponse) EztracRestClient.invokeRestService(
						saveChangeControlRequest, CommonUtility.getValFrmAppUrlProp("ez.service.updateBuildCCDetails.url"),
						SaveChangeControlResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,
						ICommonConstants.BUILD_SERVICE_LOG_KEY + "Build CC SAVE", "After rest service invocation");
			} catch (CustomException e) {
				if (null != saveChangeControlResponse) {
					if (saveChangeControlResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1000)
							|| saveChangeControlResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1001)) {
						throw new CustomException(saveChangeControlResponse.getResponseCode(),
								saveChangeControlResponse.getResponseDescription());
					} else if (saveChangeControlResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WB1002)) {
						return saveChangeControlResponse;
					} else {
						throw new CustomException(e.getErrCode(), e.getErrMsg());
					}
				} else {
					throw new CustomException(e.getErrCode(), e.getErrMsg());
				}
			}
			return saveChangeControlResponse;

		}
		else {
			throw new CustomException("400", "Invalid Request");
		}
	}
	
	@Override
	public Object populateResponse(Object responseObject, Object doObject, String action) throws CustomException {
		final String METHOD_NAME = "populateResponse";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Build populateResponse method", "");
		
		if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildDetailsResponse","Build Details");
			BuildDetailsResponse buildDetailsResponse= (BuildDetailsResponse) responseObject;
			BuildDO buildDO = (BuildDO)doObject;
			buildDO = buildDetailsResponse.getBuild();
			buildDO.setTokenId(buildDetailsResponse.getTokenId());
			return buildDO;
		}
		
		else if (action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildListResponse","Build List");
			BuildListResponse buildListResponse = (BuildListResponse) responseObject;
			BuildListDO buildListDO = (BuildListDO)doObject;
			if(buildListResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_SB1000) && null!=buildListResponse.getBuildDetails()) {
				buildListDO.setBuildList(buildListResponse.getBuildDetails());
			}
			if(buildListResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_SB1001)) {
				Map<String, String> responseCodeMap=new HashMap<String, String>();
				responseCodeMap.put(buildListResponse.getResponseCode(), ICommonConstants.NO_RECORDS_FOUND);
				buildListDO.setResponseMap(responseCodeMap);
			}
			return buildListDO;
		}
		
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildInsertResponse","Build Insert");
			BuildInsertResponse buildInsertResponse= (BuildInsertResponse) responseObject;
			BuildDO buildDO = (BuildDO)doObject;
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			String insertResponseCode = buildInsertResponse.getResponseCode();
			if(insertResponseCode.equals(ICommonConstants.SERVICESTATUS_SB1000)) {
				buildDO = new BuildDO();
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildInsertResponse.getBuild() to buildDO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(buildInsertResponse.getBuild(), buildDO);
				responseCodeMap.put(insertResponseCode, ICommonConstants.INSERT_SUCCESS);
			}
			else if(insertResponseCode.equals(ICommonConstants.SERVICESTATUS_SB1002)) {
				buildDO = new BuildDO();
				responseCodeMap.put(insertResponseCode, ICommonConstants.INSERT_PARTIAL_SUCCESS);
			}
			else if(insertResponseCode.equals(ICommonConstants.SERVICESTATUS_WB1001) ||  insertResponseCode.equals(ICommonConstants.SERVICESTATUS_WB1003) ) 
			{
				responseCodeMap.put(insertResponseCode,buildInsertResponse.getResponseDescription());
			}
			buildDO.setResponseMap(responseCodeMap);
			return buildDO;
		}
		
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildDeleteResponse","Build Delete");
			BuildDeleteResponse buildDeleteResponse= (BuildDeleteResponse) responseObject;
			BuildDO buildDO = (BuildDO)doObject;
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			String deleteResponseCode = buildDeleteResponse.getResponseCode();
			
			if(deleteResponseCode.equals(ICommonConstants.SERVICESTATUS_SB1000)) {
				buildDO = new BuildDO();
				responseCodeMap.put(deleteResponseCode, ICommonConstants.DELETE_SUCCESS);
			}
			else if(deleteResponseCode.equals(ICommonConstants.SERVICESTATUS_WB1002)) {
				responseCodeMap.put(deleteResponseCode, ICommonConstants.BUILD_DELETE_FAILURE);
			}
			
			buildDO.setResponseMap(responseCodeMap);
			buildDO.setTokenId(buildDeleteResponse.getTokenId());
			return buildDO;
		}
		else if(action.equals(ICommonConstants.BUILD_CC_LIST_REQUEST_ACTION)){

			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populate BuildChangeControlListResponse","Build CC LIST");
			BuildChangeControlListResponse buildCcListResponse= (BuildChangeControlListResponse) responseObject;
			BuildDO buildDO = (BuildDO)doObject;
			buildDO.setBuildChangeControlList(buildCcListResponse.getBuildChangeControlList());
			return buildDO;
		}
		else if(action.equals(ICommonConstants.BUILD_CC_ID_REQUEST_ACTION)){

			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populate BuildChangeControlResponse","Build CC ");
			BuildChangeControlResponse buildCcResponse= (BuildChangeControlResponse) responseObject;
			BuildDO buildDO = (BuildDO)doObject;
			buildDO = buildCcResponse.getBuild();
			buildDO.setTokenId(buildCcResponse.getTokenId());
			return buildDO;
		}
		else if (action.equals(ICommonConstants.BUILD_CC_SAVE_ACTION)) {

			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populate SaveChangeControlResponse", "Build CC Save");
			SaveChangeControlResponse saveChangeControlResponse = (SaveChangeControlResponse) responseObject;
			BuildDO buildDO = (BuildDO) doObject;
			buildDO = saveChangeControlResponse.getBuild();
			Map<String, String> resMaps = new HashMap<String, String>();
			resMaps.put(saveChangeControlResponse.getResponseCode(),
					saveChangeControlResponse.getResponseDescription());
			buildDO.setResponseMap(resMaps);
			buildDO.setTokenId(saveChangeControlResponse.getTokenId());
			return buildDO;
		}
		
		else {
			throw new CustomException("400", "Invalid Request");
		}
	}

	/*@Override
	public Object populateResponse(Object responseObject, Object doObject, String action) throws CustomException {
		final String METHOD_NAME = "populateResponse";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Build populateResponse method", "");
		
		if (action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildListResponse","Build List");
			BuildListResponse buildListResponse = (BuildListResponse) responseObject;
			BuildListDO buildListDO = (BuildListDO)doObject;
			if(null!=buildListResponse.getBuildDetails()) {
				buildListDO.setBuildList(buildListResponse.getBuildDetails());
			}
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			responseCodeMap.put(buildListResponse.getResponseCode(), buildListResponse.getResponseDescription());
			buildListDO.setResponseMap(responseCodeMap);
			return buildListDO;
		}
		
		else if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildDetailsResponse","Build Details");
			BuildDetailsResponse buildDetailsResponse= (BuildDetailsResponse) responseObject;
			BuildDO buildDO = (BuildDO)doObject;
			buildDO = buildDetailsResponse.getBuild();
			buildDO.setTokenId(buildDetailsResponse.getTokenId());
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			responseCodeMap.put(buildDetailsResponse.getResponseCode(), buildDetailsResponse.getResponseDescription());
			buildDO.setResponseMap(responseCodeMap);
			return buildDO;
		}
		
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildInsertResponse","Build Insert");
			BuildInsertResponse buildInsertResponse= (BuildInsertResponse) responseObject;
			BuildDO buildDO = (BuildDO)doObject;
			if(null!=buildInsertResponse) {
				buildDO = new BuildDO();
				CommonUtility.copyBeanProperties(buildInsertResponse.getBuild(), buildDO);
				buildDO.setTokenId(buildInsertResponse.getTokenId());
			}
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			responseCodeMap.put(buildInsertResponse.getResponseCode(), buildInsertResponse.getResponseDescription());
			buildDO.setResponseMap(responseCodeMap);
			return buildDO;
		}
		
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildDeleteResponse","Build Delete");
			BuildDeleteResponse buildDeleteResponse= (BuildDeleteResponse) responseObject;
			
			if(null!=buildDeleteResponse) {
				Map<String, String> responseCodeMap=new HashMap<String, String>();
				responseCodeMap.put(buildDeleteResponse.getResponseCode(), buildDeleteResponse.getResponseDescription());
				if(buildDeleteResponse.getResponseCode().equals("200")) {
					BuildDO newBuildDO = new BuildDO();
					newBuildDO.setResponseMap(responseCodeMap);
					newBuildDO.setTokenId(buildDeleteResponse.getTokenId());
					return newBuildDO;
				}
				else {
					BuildDO buildDO = (BuildDO)doObject;
					buildDO.setResponseMap(responseCodeMap);
					buildDO.setTokenId(buildDeleteResponse.getTokenId());
					return buildDO;
				}
			}
			else {
				return null;
			}
		}
		
		else {
			throw new CustomException("400", "Invalid Request");
		}
	}*/
	
}
