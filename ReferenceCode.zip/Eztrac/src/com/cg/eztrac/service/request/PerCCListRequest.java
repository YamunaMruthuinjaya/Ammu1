package com.cg.eztrac.service.request;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceRequest;
import com.cg.eztrac.domain.PerDO;

@Component(value="perCCListRequest")
public class PerCCListRequest implements IRestServiceRequest {

	private Integer perId;
	private String tokenId;
	private String channelId;
	
	public Integer getPerId() {
		return perId;
	}
	public void setPerId(Integer perId) {
		this.perId = perId;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	@Override
	public String toString() {
		return "PerCCListRequest [perId=" + perId + ", tokenId=" + tokenId + ", channel=" + channelId + "]";
	}
	
	
}
