package com.cg.eztrac.service.request;

import java.util.List;

import com.cg.eztrac.common.IRestServiceRequest;

public class GetPerListTimeSheetRequest implements IRestServiceRequest {

	private int systemId;
	private int subSystemId;
	private String perNo;	
	private List<GetPerListTimeSheetRequest> perListTimeSheetRequest;
	
	private int subAccountId;
	private String tokenId;
	private String channelId;
	
	
	@Override
	public String getChannelId() {
		return null;
	}

	@Override
	public String getTokenId() {
		return null;
	}

	
	/**
	 * @return the perListTimeSheetRequest
	 */
	public List<GetPerListTimeSheetRequest> getPerListTimeSheetRequest() {
		return perListTimeSheetRequest;
	}

	/**
	 * @param perListTimeSheetRequest the perListTimeSheetRequest to set
	 */
	public void setPerListTimeSheetRequest(List<GetPerListTimeSheetRequest> perListTimeSheetRequest) {
		this.perListTimeSheetRequest = perListTimeSheetRequest;
	}

		
		
		
		/**
		 * @return the perNo
		 */
		public String getPerNo() {
			return perNo;
		}
		/**
		 * @param perNo the perNo to set
		 */
		public void setPerNo(String perNo) {
			this.perNo = perNo;
		}

		/**
		 * @return the systemId
		 */
		public int getSystemId() {
			return systemId;
		}

		/**
		 * @param systemId the systemId to set
		 */
		public void setSystemId(int systemId) {
			this.systemId = systemId;
		}

		/**
		 * @return the subSystemId
		 */
		public int getSubSystemId() {
			return subSystemId;
		}

		/**
		 * @param subSystemId the subSystemId to set
		 */
		public void setSubSystemId(int subSystemId) {
			this.subSystemId = subSystemId;
		}

		/**
		 * @param tokenId the tokenId to set
		 */
		public void setTokenId(String tokenId) {
			this.tokenId = tokenId;
		}

		/**
		 * @param channelId the channelId to set
		 */
		public void setChannelId(String channelId) {
			this.channelId = channelId;
		}

		/**
		 * @return the subAccountId
		 */
		public int getSubAccountId() {
			return subAccountId;
		}

		/**
		 * @param subAccountId the subAccountId to set
		 */
		public void setSubAccountId(int subAccountId) {
			this.subAccountId = subAccountId;
		}

		
	}
