package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class BuildChangeControlListRequest implements IRestServiceRequest {

	private Integer buildId;
	private String tokenId;
	private String channelId;

	public Integer getBuildId() {
		return buildId;
	}

	public void setBuildId(Integer buildId) {
		this.buildId = buildId;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

}
