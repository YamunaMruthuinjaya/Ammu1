package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class AutocompletePerListRequest implements IRestServiceRequest {

	
	private int systemId;
	private int subSystemId;
	private String perNumber;
	
	
	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTokenId() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return the systemId
	 */
	public int getSystemId() {
		return systemId;
	}

	/**
	 * @param systemId the systemId to set
	 */
	public void setSystemId(int systemId) {
		this.systemId = systemId;
	}

	/**
	 * @return the subSystemId
	 */
	public int getSubSystemId() {
		return subSystemId;
	}

	/**
	 * @param subSystemId the subSystemId to set
	 */
	public void setSubSystemId(int subSystemId) {
		this.subSystemId = subSystemId;
	}

	/**
	 * @return the perNumber
	 */
	public String getPerNumber() {
		return perNumber;
	}

	/**
	 * @param perNumber the perNumber to set
	 */
	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}

}
