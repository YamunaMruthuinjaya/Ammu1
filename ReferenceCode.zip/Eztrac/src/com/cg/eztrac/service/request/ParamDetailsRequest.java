package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class ParamDetailsRequest implements IRestServiceRequest {
	
	private int subAccountId;
	private String Status_CD;
	
	public int getSubAccountId() {
		return subAccountId;
	}
	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}
	public String getStatus_CD() {
		return Status_CD;
	}
	public void setStatus_CD(String status_CD) {
		Status_CD = status_CD;
	}
	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getTokenId() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String toString() {
		return "ParamDetailsRequest [subAccountId=" + subAccountId + ", Status_CD=" + Status_CD + "]";
	}

}
