package com.cg.eztrac.service.request;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceRequest;

@Component(value="buildDetailsRequest")
public class BuildDetailsRequest implements IRestServiceRequest {
	
	private Integer buildId;
	private Integer systemId;
	private Integer subSystemId;
	
	private String tokenId;
	private String channelId;
	public Integer getBuildId() {
		return buildId;
	}
	public void setBuildId(Integer buildId) {
		this.buildId = buildId;
	}
	public Integer getSystemId() {
		return systemId;
	}
	public void setSystemId(Integer systemId) {
		this.systemId = systemId;
	}
	public Integer getSubSystemId() {
		return subSystemId;
	}
	public void setSubSystemId(Integer subSystemId) {
		this.subSystemId = subSystemId;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	@Override
	public String toString() {
		return "BuildDetailsRequest [buildId=" + buildId + ", systemId=" + systemId + ", subSystemId=" + subSystemId
				+ ", tokenId=" + tokenId + ", channelId=" + channelId + "]";
	}
	
}
