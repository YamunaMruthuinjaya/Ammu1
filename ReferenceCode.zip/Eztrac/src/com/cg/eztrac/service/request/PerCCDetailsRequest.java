package com.cg.eztrac.service.request;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceRequest;

@Component(value="perCCDetailsRequest")
public class PerCCDetailsRequest implements IRestServiceRequest {
	
	private Integer ccId;
	private String tokenId;
	private String channelId;
	
	public Integer getCcId() {
		return ccId;
	}
	public void setCcId(Integer ccId) {
		this.ccId = ccId;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	
	@Override
	public String toString() {
		return "PerCCDetailsRequest [ccId=" + ccId + ", tokenId=" + tokenId + ", channelId=" + channelId + "]";
	}
	
}
