package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class BuildChangeControlRequest implements IRestServiceRequest {

	private int buildCCId;
	private String tokenId;
	private String channelId;

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public int getBuildCCId() {
		return buildCCId;
	}

	public void setBuildCCId(int buildCCId) {
		this.buildCCId = buildCCId;
	}

}
