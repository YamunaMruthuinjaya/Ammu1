package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class LoginInfoReq implements IRestServiceRequest{
	String loginId;
	String passowrd;
	String sessionId;
	String channel;
	String tokenId;

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	@Override
	public String getTokenId() {
		return tokenId;
	}
	public String getPassowrd() {
		return passowrd;
	}

	public void setPassowrd(String passowrd) {
		this.passowrd = passowrd;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}


	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	@Override
	public String getChannelId() {
		return null;
	}


}
