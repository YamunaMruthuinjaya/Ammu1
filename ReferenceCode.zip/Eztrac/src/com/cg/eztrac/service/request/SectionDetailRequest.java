package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class SectionDetailRequest implements IRestServiceRequest{
	String tokenId = "";
	String channelId = "";
	Integer subAccountId;
	
	public Integer getSubAccountId() {
		return subAccountId;
	}
	public void setSubAccountId(Integer subAccountId) {
		this.subAccountId = subAccountId;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
}
