package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;
import com.cg.eztrac.domain.BuildChangeControlDO;

public class SaveChangeControlRequest implements IRestServiceRequest {

	private BuildChangeControlDO buildChangeControl;
	private String tokenId;
	private String channelId;

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public BuildChangeControlDO getBuildChangeControl() {
		return buildChangeControl;
	}

	public void setBuildChangeControl(BuildChangeControlDO buildChangeControl) {
		this.buildChangeControl = buildChangeControl;
	}

}
