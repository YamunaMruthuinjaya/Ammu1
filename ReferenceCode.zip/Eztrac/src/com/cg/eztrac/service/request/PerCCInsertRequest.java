package com.cg.eztrac.service.request;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceRequest;
import com.cg.eztrac.domain.PerDO;

@Component(value="perCCInsertRequest")
public class PerCCInsertRequest  extends PerDO implements IRestServiceRequest {
	
	private String channelId;
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	
	@Override
	public String toString() {
		return "PerCCInsertRequest [channelId=" + channelId + "]";
	}
	
}
