package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class PerDeleteRequest implements IRestServiceRequest {
	
	private Integer perId;
	private String tokenId;
	private String channelId;
	
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public Integer getPerId() {
		return perId;
	}
	public void setPerId(Integer perId) {
		this.perId = perId;
	}

}
