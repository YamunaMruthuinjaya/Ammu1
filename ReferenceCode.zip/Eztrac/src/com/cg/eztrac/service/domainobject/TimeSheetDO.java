package com.cg.eztrac.service.domainobject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.BaseDO;
import com.cg.eztrac.domain.PerDO;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.handler.TimeSheetHandler;
import com.cg.eztrac.service.impl.TimeSheetServiceImpl;
import com.cg.eztrac.service.request.InsertTimeSheetRequest;
import com.cg.eztrac.service.request.InsertTimeSheetRequest.TimeSheetRow;
import com.cg.eztrac.service.response.TimeSheetResponse.TimeSheetDetailResponse;
import com.cg.eztrac.vo.InvoiceVO;
import com.cg.eztrac.vo.TimeSheetDetailVO;
import com.cg.eztrac.vo.TimeSheetVO;

public class TimeSheetDO extends BaseDO {
	
	private static final String CLASS_NAME = "TimeSheetDO";
			
	DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	private HashMap<String, HashMap<Integer, List<TimeSheetDetailDO>>> timeSheetDetailMap;
	private Map<String, TimeSheetHeaderDO> timeSheetHeaderMap;
	private Integer systemId;
	private Integer subSystemId;
	private String startDate;
	private String endDate;
	private String projectName;
	private String perNumber;
	private List<PerDO> perDetail;
	private List<Integer> timeSheetIdList;
	private Integer userId;
	private List<TimeSheetDetailResponse> timeSheetList;
	//Response Code and Description Map
	private Map<String,String> responseMap;
	
	public void setTimeSheetDetailMap(HashMap<String, HashMap<Integer, List<TimeSheetDetailDO>>> timeSheetDetailMap) {
		this.timeSheetDetailMap = timeSheetDetailMap;
	}

	public HashMap<String, HashMap<Integer, List<TimeSheetDetailDO>>> getTimeSheetDetailMap() {
		return timeSheetDetailMap;
	}

	public Map<String, TimeSheetHeaderDO> getTimeSheetHeaderMap() {
		return timeSheetHeaderMap;
	}

	public void setTimeSheetHeaderMap(Map<String, TimeSheetHeaderDO> timeSheetHeaderMap) {
		this.timeSheetHeaderMap = timeSheetHeaderMap;
	}

	public Integer getSystemId() {
		return systemId;
	}

	public void setSystemId(Integer systemId) {
		this.systemId = systemId;
	}

	public Integer getSubSystemId() {
		return subSystemId;
	}

	public void setSubSystemId(Integer subSystemId) {
		this.subSystemId = subSystemId;
	}

	public String getStartDate() {
		return startDate;
	}
	
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	public String getProjectName() {
		return projectName;
	}
	
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	public String getPerNumber() {
		return perNumber;
	}

	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}
	
	public List<PerDO> getPerDetail() {
		return perDetail;
	}

	public void setPerDetail(List<PerDO> perDetail) {
		this.perDetail = perDetail;
	}

	public List<Integer> getTimeSheetIdList() {
		return timeSheetIdList;
	}
	
	public void setTimeSheetIdList(List<Integer> timeSheetIdList) {
		this.timeSheetIdList = timeSheetIdList;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public List<TimeSheetDetailResponse> getTimeSheetList() {
		return timeSheetList;
	}

	public void setTimeSheetList(List<TimeSheetDetailResponse> timeSheetList) {
		this.timeSheetList = timeSheetList;
	}

	public Map<String, String> getResponseMap() {
		return responseMap;
	}

	public void setResponseMap(Map<String, String> responseMap) {
		this.responseMap = responseMap;
	}
	

	public TimeSheetDO getTimeSheetDetails(TimeSheetDO timeSheetDO, List<SystemDetailsDO> systemDetailsDOList,InvoiceVO invoiceVO) {
		final String METHOD_NAME="getTimeSheetDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered getTimeSheetDetails DO method", "getTimeSheetDetails - Start");

		TimeSheetServiceImpl timeSheetService = new TimeSheetServiceImpl();
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling timeSheetService.serviceProcessor()", "GetTimesheet");
		timeSheetService.serviceProcessor(timeSheetDO, ICommonConstants.LIST_REQUEST_ACTION);
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from timeSheetService.serviceProcessor()", "GetTimesheet");
		
		if(null!=timeSheetDO.getTimeSheetList()) {
			buildTimeSheetMap(timeSheetDO.getTimeSheetList(), systemDetailsDOList,invoiceVO);
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "returning from getTimeSheetDetails DO method", "getTimeSheetDetails - End");
		return timeSheetDO;
	}
	
	public TimeSheetDO insertTimeSheetDetails(InsertTimeSheetRequest insertTimeSheetRequest) throws CustomException{
		final String METHOD_NAME = "insertTimeSheetDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered timesheetHandler.insertTimeSheetDetails()","insertTimeSheetDetails -Start");
		TimeSheetDO timeSheetDO = null;
		TimeSheetServiceImpl timeSheetService = new TimeSheetServiceImpl();
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling timeSheetService.serviceProcessor()", "InsertTimeSheet");
			timeSheetDO = (TimeSheetDO) timeSheetService.serviceProcessor(insertTimeSheetRequest, ICommonConstants.INSERT_REQUEST_ACTION);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from timeSheetService.serviceProcessor()", "InsertTimeSheet");
		}
		catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME,METHOD_NAME, "Timesheet Insertion Exception - In TimeSheetDO", e, "");
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning from timesheetHandler.insertTimeSheetDetails()","insertTimeSheetDetails -End");
		return timeSheetDO;
	}
	
	public void deleteTimeSheetDetails(TimeSheetDO timeSheetDO) throws CustomException{
		final String METHOD_NAME = "deleteTimeSheet";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered timesheetHandler.deleteTimeSheet()","deleteTimeSheet -Start");
		
		TimeSheetServiceImpl timeSheetService = new TimeSheetServiceImpl();
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling timeSheetService.serviceProcessor()", "DeleteTimeSheet");
			timeSheetService.serviceProcessor(timeSheetDO, ICommonConstants.DELETE_REQUEST_ACTION);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from timeSheetService.serviceProcessor()", "DeleteTimeSheet");
		}
		catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME,METHOD_NAME, "Timesheet Delete Exception - In TimeSheetDO", e, "");
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning from timesheetHandler.deleteTimeSheet()","deleteTimeSheet -End");
	}
	
	private void buildTimeSheetMap(List<TimeSheetDetailResponse> timeSheetDetailResponseList, List<SystemDetailsDO> systemDetailsDOList,InvoiceVO invoiceVO) {
		final String METHOD_NAME="buildTimeSheetMap";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered buildTimeSheetMap DO method", "buildTimeSheetMap - Start");
		
		timeSheetDetailMap = new HashMap<String, HashMap<Integer, List<TimeSheetDetailDO>>>();
		TimeSheetHandler timeSheetHandler = new TimeSheetHandler();
		HashMap<Integer, List<TimeSheetDetailDO>> innerMap = null;
		List<TimeSheetDetailDO> timeSheetDetailDoList;
		boolean taskAlreadyAdded;
		
		try {
			for (TimeSheetDetailResponse response : timeSheetDetailResponseList) {
				String timeSheetMapkey = response.getPerId() + "_" + response.getBuildId()+ "_" + response.getSubSytemId()+ "_" + response.getTaskId();
				taskAlreadyAdded = false;
				
				if(timeSheetDetailMap.containsKey(timeSheetMapkey)){
					if(timeSheetDetailMap.get(timeSheetMapkey).containsKey(response.getTaskId())){
						taskAlreadyAdded = true;
					}
					TimeSheetDetailDO timeSheetDetailDO = new TimeSheetDetailDO();
					CommonUtility.copyBeanProperties(response, timeSheetDetailDO);
					timeSheetDetailDO.setReadOnlyFlag(getReadOnlyFlag(timeSheetDetailDO,invoiceVO));
					
					if(taskAlreadyAdded){
						HashMap<Integer, List<TimeSheetDetailDO>> tempMap = timeSheetDetailMap.get(timeSheetMapkey);
						int tempTaksId = response.getTaskId();
						if(tempMap.containsKey(tempTaksId)){
							timeSheetDetailMap.get(timeSheetMapkey).get(tempTaksId).add(timeSheetDetailDO);
						}
					} else {
						innerMap = new HashMap<Integer, List<TimeSheetDetailDO>>();
						timeSheetDetailDoList = new ArrayList<TimeSheetDetailDO>();
						timeSheetDetailDoList.add(timeSheetDetailDO);
						innerMap.put(response.getTaskId(), timeSheetDetailDoList);
						timeSheetDetailMap.get(timeSheetMapkey).putAll(innerMap);
					}
				}else{
					innerMap = new HashMap<Integer, List<TimeSheetDetailDO>>();
					timeSheetDetailDoList = new ArrayList<TimeSheetDetailDO>();
					TimeSheetDetailDO timeSheetDetailDO = new TimeSheetDetailDO();
					CommonUtility.copyBeanProperties(response, timeSheetDetailDO);
					timeSheetDetailDO.setReadOnlyFlag(getReadOnlyFlag(timeSheetDetailDO,invoiceVO));
					timeSheetDetailDO.setSubSystemName(timeSheetHandler.getSubSystemName(timeSheetDetailDO.getSubSytemId(), systemDetailsDOList));
					timeSheetDetailDoList.add(timeSheetDetailDO);
					innerMap.put(response.getTaskId(), timeSheetDetailDoList);
					timeSheetDetailMap.put(timeSheetMapkey, innerMap);
				}
			}
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME,METHOD_NAME, "Timesheet Delete Exception - In TimeSheetDO", e, "");
			throw new CustomException("", "Could'nt fetch the TimesheetDetails, Please try again later!!!");
		}
		System.out.println(timeSheetDetailMap);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting the timeSheetDetailsMap to TimeSheetDo", "");
		this.setTimeSheetDetailMap(timeSheetDetailMap);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning from buildTimeSheetMap DO method", "buildTimeSheetMap - End");
	}

	private String getReadOnlyFlag(TimeSheetDetailDO timeSheetDetailDO,InvoiceVO invoiceVO) {
		final String METHOD_NAME="getReadOnlyFlag";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered getReadOnlyFlag DO method", "getReadOnlyFlag - Start");
		
		String isReadOnly = "N";
		Date workDate;
		String invoiceCutOffDateString = invoiceVO.getInvoiceYear()+"-"+invoiceVO.getInvoiceMonth()+"-"+invoiceVO.getInvoiceDt();
		if(null!=timeSheetDetailDO.getWorkDate() && null!=timeSheetDetailDO.getStatusCode()) {
			try {
				workDate = sdf.parse(timeSheetDetailDO.getWorkDate());
				Date invoiceCutOffDate = sdf.parse(invoiceCutOffDateString);
				int result = workDate.compareTo(invoiceCutOffDate);
				if(result <= 0 && timeSheetDetailDO.getStatusCode().equalsIgnoreCase(ICommonConstants.TIMESHEET_SUBMIT_STATUS)){
					isReadOnly = "Y";
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			/*if(timeSheetDetailDO.getStatusCode().equalsIgnoreCase(ICommonConstants.TIMESHEET_SUBMIT_STATUS)){
				isReadOnly = "Y";
			}*/
		}
		else {
			isReadOnly = "N";
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "returning from getReadOnlyFlag DO method", "getReadOnlyFlag - End");
		return isReadOnly;
	}

	public InsertTimeSheetRequest populateInsertTimeSheetRequest(TimeSheetVO timeSheetVO, UserDO userDO) {
		final String METHOD_NAME="populateInsertTimeSheetRequest";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered populateInsertTimeSheetRequest DO method", "Start");
		
		InsertTimeSheetRequest insertTimeSheetRequest = new InsertTimeSheetRequest();
		try {
			List<TimeSheetRow> timeSheetRowList = new ArrayList<TimeSheetRow>();
			
			Map<Integer, Map<Integer, List<TimeSheetDetailVO>>> userInputMap = timeSheetVO.getTimeSheetInsertionMap();
			if(null==userInputMap) {
				insertTimeSheetRequest =  null;
			}
			else {
				int buildId;
				int taskId;
				int userId = userDO.getUserId();
				int resourceId;
				if(null!=timeSheetVO.getResourceId()){
					resourceId = timeSheetVO.getResourceId();
				}
				else{
					resourceId =userDO.getUserId();
				}
				boolean onsiteFlag = false;
				if(null!=userDO.getClientReportingFlag()) {
					String clientReportingFlag = userDO.getClientReportingFlag() ;
					if(clientReportingFlag.equalsIgnoreCase("Y")){
						onsiteFlag = true;
					}
				}
				TimeSheetRow timeSheetRow;
				for (Entry<Integer, Map<Integer, List<TimeSheetDetailVO>>> entry : userInputMap.entrySet()) {
					buildId = entry.getKey();
				    for (Entry<Integer, List<TimeSheetDetailVO>> entry1 : entry.getValue().entrySet()) {
				    	taskId = entry1.getKey();
				    	for(TimeSheetDetailVO timeSheetDetailVO : entry1.getValue()){
				    		if(timeSheetDetailVO.getUpdateFlag().equalsIgnoreCase("Y") && timeSheetDetailVO.getTimeSheetId() != 0){
					    		timeSheetRow = new TimeSheetRow();
					    		timeSheetRow.setTimeSheetId(String.valueOf(timeSheetDetailVO.getTimeSheetId()));
					    		timeSheetRow.setApprovedBy(userId);
					    		timeSheetRow.setApprovedOn(sdf.format(new Date()));
					    		timeSheetRow.setBuildId(buildId);
					    		timeSheetRow.setCreatedBy(userId);
					    		if(timeSheetDetailVO.getHoursWorked() <= 0){
					    			timeSheetRow.setStatusCd("D");
					    		}else{
					    			timeSheetRow.setStatusCd(timeSheetVO.getInsertType());
					    		}
					    		timeSheetRow.setDateWorked(timeSheetDetailVO.getWorkDate());
					    		timeSheetRow.setHoursWorked(timeSheetDetailVO.getHoursWorked());
					    		timeSheetRow.setLastModidfiedOn(sdf.format(new Date()));
					    		timeSheetRow.setLastModifiedBy(userId);
					    		timeSheetRow.setOnsiteFlag(onsiteFlag);
					    		timeSheetRow.setSubTaskId(0);
					    		timeSheetRow.setTaskId(taskId);
					    		timeSheetRow.setUserId(resourceId);
					    		timeSheetRowList.add(timeSheetRow);
				    		}else if(timeSheetDetailVO.getUpdateFlag().equalsIgnoreCase("Y") && timeSheetDetailVO.getHoursWorked() > 0){
				    			timeSheetRow = new TimeSheetRow();
					    		timeSheetRow.setApprovedBy(userId);
					    		timeSheetRow.setApprovedOn(sdf.format(new Date()));
					    		timeSheetRow.setBuildId(buildId);
					    		timeSheetRow.setCreatedBy(userId);
					    		timeSheetRow.setStatusCd(timeSheetVO.getInsertType());
					    		timeSheetRow.setDateWorked(timeSheetDetailVO.getWorkDate());
					    		timeSheetRow.setHoursWorked(timeSheetDetailVO.getHoursWorked());
					    		timeSheetRow.setLastModidfiedOn(sdf.format(new Date()));
					    		timeSheetRow.setLastModifiedBy(userId);
					    		timeSheetRow.setOnsiteFlag(onsiteFlag);
					    		timeSheetRow.setSubTaskId(0);
					    		timeSheetRow.setTaskId(taskId);
					    		timeSheetRow.setUserId(resourceId);
					    		timeSheetRowList.add(timeSheetRow);
				    		}
				    	}
				    }
				}
				insertTimeSheetRequest.setTimesheetList(timeSheetRowList);
				insertTimeSheetRequest.setTokenId(timeSheetVO.getTokenId());
			}
		} catch (CustomException e) {
			e.printStackTrace();
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning from populateInsertTimeSheetRequest DO method", "End");
		return insertTimeSheetRequest;
	}

	
}