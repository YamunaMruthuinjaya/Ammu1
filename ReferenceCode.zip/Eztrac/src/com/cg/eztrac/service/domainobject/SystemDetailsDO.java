package com.cg.eztrac.service.domainobject;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.OnLoadCommonService;
import com.cg.eztrac.service.impl.OnLoadCommonServiceImpl;
import com.cg.eztrac.service.request.SystemDetailsRequest;
import com.cg.eztrac.service.response.SystemDetailsResponse;
import com.cg.eztrac.service.response.SystemRes;
import com.google.gson.Gson;

public class SystemDetailsDO {

	String className = SystemDetailsDO.class.getSimpleName();
	private int subAccountId;
	private int systemID;
	private String systemName;
	private List<SubSystemDO> subsystemDetails;
	private String systemStatus;
	
	public List<SystemDetailsDO> callSystemDetailService(SystemDetailsDO systemDetailsDO) {
		
		String methodName="callSystemDetailService";
		
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.SYSTEM_SERVICE_LOG_KEY+"In callSystemDetailService", "Before populating the systemDetailsRequest from DO");
		SystemDetailsRequest systemDetailsRequest  = populateSystemRequestFromDO(systemDetailsDO);
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.SYSTEM_SERVICE_LOG_KEY+"In SystemDetailsDO", "Details are populated into systemDetailsRequest");
		
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.SYSTEM_SERVICE_LOG_KEY+"In SystemDetailsDO", "Before calling the getSystemDetails() to get systemDetailResponseList ");
		OnLoadCommonService onLoadCommonServcie = new OnLoadCommonServiceImpl();
		SystemRes systemRes = onLoadCommonServcie.getSystemDetails(systemDetailsRequest);
		List<SystemDetailsResponse> systemDetailsListResponse = systemRes.getSystemDetails();
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.SYSTEM_SERVICE_LOG_KEY+"In SystemDetailsDO", "getAllSystemDetails() is called and got systemDetailServiceResponseList");
		List<SystemDetailsDO> systemDetailsDOList = populateResponseToDO(systemDetailsListResponse);
		return systemDetailsDOList;
	}
	
	private SystemDetailsRequest populateSystemRequestFromDO(SystemDetailsDO systemDetailsDO) {
		
		String methodName = "populateSystemRequestFromDO";
		SystemDetailsRequest systemDetailsRequest = new SystemDetailsRequest();
		systemDetailsRequest.setSubAccountId(1);
		LoggerManager.writeInfoLog(className, methodName, ICommonConstants.SYSTEM_SERVICE_LOG_KEY + "In populateSystemRequestFromDO", "systemDetailsRequest populated from DO");
		
		return systemDetailsRequest;
	}

	private List<SystemDetailsDO> populateResponseToDO(List<SystemDetailsResponse> systemDetailResponseList) {
		String methodName="populateResponseToDO";
		List<SystemDetailsDO> systemDetailsDOList = new ArrayList<SystemDetailsDO>();
		
		try {
			SystemDetailsDO systemDetailsDO = null;
			Gson gson = new Gson();
			for (int i = 0; i < systemDetailResponseList.size(); i++) {
				systemDetailsDO = new SystemDetailsDO();
				String systemDetailDOJson = gson.toJson(systemDetailResponseList.get(i));
				systemDetailsDO = gson.fromJson(systemDetailDOJson, SystemDetailsDO.class);
				systemDetailsDOList.add(systemDetailsDO);
			}
			LoggerManager.writeInfoLog(className, methodName, ICommonConstants.SYSTEM_SERVICE + "In systemDetailsDO", "Setting SystemDetailsDO from systemDetailsDetailResponse");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemDetailsDOList;
	}

	public int getSubAccountId() {
		return subAccountId;
	}

	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}

	public int getSystemID() {
		return systemID;
	}

	public void setSystemID(int systemID) {
		this.systemID = systemID;
	}

	public String getSystemName() {
		return systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	public List<SubSystemDO> getSubsystemDetails() {
		return subsystemDetails;
	}

	public void setSubsystemDetails(List<SubSystemDO> subsystemDetails) {
		this.subsystemDetails = subsystemDetails;
	}

	public String getSystemStatus() {
		return systemStatus;
	}

	public void setSystemStatus(String systemStatus) {
		this.systemStatus = systemStatus;
	}

}