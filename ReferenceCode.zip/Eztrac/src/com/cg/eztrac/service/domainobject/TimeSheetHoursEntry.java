package com.cg.eztrac.service.domainobject;

import java.util.Date;

public class TimeSheetHoursEntry {

	private String timeSheetId1;
	private String timeSheetId2;
	private String timeSheetId3;
	private String timeSheetId4;
	private String timeSheetId5;
	private String timeSheetId6;
	private String timeSheetId7;

	private Date date1;
	private Date date2;
	private Date date3;
	private Date date4;
	private Date date5;
	private Date date6;
	private Date date7;

	private int hours1;
	private int hours2;
	private int hours3;
	private int hours4;
	private int hours5;
	private int hours6;
	private int hours7;

	private String approvedBy;
	private Date approvedOn;
	private String comments;
	private String onsiteFlag;
	
	
	public String getTimeSheetId1() {
		return timeSheetId1;
	}
	public void setTimeSheetId1(String timeSheetId1) {
		this.timeSheetId1 = timeSheetId1;
	}
	public String getTimeSheetId2() {
		return timeSheetId2;
	}
	public void setTimeSheetId2(String timeSheetId2) {
		this.timeSheetId2 = timeSheetId2;
	}
	public String getTimeSheetId3() {
		return timeSheetId3;
	}
	public void setTimeSheetId3(String timeSheetId3) {
		this.timeSheetId3 = timeSheetId3;
	}
	public String getTimeSheetId4() {
		return timeSheetId4;
	}
	public void setTimeSheetId4(String timeSheetId4) {
		this.timeSheetId4 = timeSheetId4;
	}
	public String getTimeSheetId5() {
		return timeSheetId5;
	}
	public void setTimeSheetId5(String timeSheetId5) {
		this.timeSheetId5 = timeSheetId5;
	}
	public String getTimeSheetId6() {
		return timeSheetId6;
	}
	public void setTimeSheetId6(String timeSheetId6) {
		this.timeSheetId6 = timeSheetId6;
	}
	public String getTimeSheetId7() {
		return timeSheetId7;
	}
	public void setTimeSheetId7(String timeSheetId7) {
		this.timeSheetId7 = timeSheetId7;
	}
	public Date getDate1() {
		return date1;
	}
	public void setDate1(Date date1) {
		this.date1 = date1;
	}
	public Date getDate2() {
		return date2;
	}
	public void setDate2(Date date2) {
		this.date2 = date2;
	}
	public Date getDate3() {
		return date3;
	}
	public void setDate3(Date date3) {
		this.date3 = date3;
	}
	public Date getDate4() {
		return date4;
	}
	public void setDate4(Date date4) {
		this.date4 = date4;
	}
	public Date getDate5() {
		return date5;
	}
	public void setDate5(Date date5) {
		this.date5 = date5;
	}
	public Date getDate6() {
		return date6;
	}
	public void setDate6(Date date6) {
		this.date6 = date6;
	}
	public Date getDate7() {
		return date7;
	}
	public void setDate7(Date date7) {
		this.date7 = date7;
	}
	public int getHours1() {
		return hours1;
	}
	public void setHours1(int hours1) {
		this.hours1 = hours1;
	}
	public int getHours2() {
		return hours2;
	}
	public void setHours2(int hours2) {
		this.hours2 = hours2;
	}
	public int getHours3() {
		return hours3;
	}
	public void setHours3(int hours3) {
		this.hours3 = hours3;
	}
	public int getHours4() {
		return hours4;
	}
	public void setHours4(int hours4) {
		this.hours4 = hours4;
	}
	public int getHours5() {
		return hours5;
	}
	public void setHours5(int hours5) {
		this.hours5 = hours5;
	}
	public int getHours6() {
		return hours6;
	}
	public void setHours6(int hours6) {
		this.hours6 = hours6;
	}
	public int getHours7() {
		return hours7;
	}
	public void setHours7(int hours7) {
		this.hours7 = hours7;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public Date getApprovedOn() {
		return approvedOn;
	}
	public void setApprovedOn(Date approvedOn) {
		this.approvedOn = approvedOn;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getOnsiteFlag() {
		return onsiteFlag;
	}
	public void setOnsiteFlag(String onsiteFlag) {
		this.onsiteFlag = onsiteFlag;
	}

}
