package com.cg.eztrac.service.response;

public class RolePersmission {
	/** LOGIN SERVICE RESPONSE */
	Integer roleId;
	String roleName="";
	
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
}
