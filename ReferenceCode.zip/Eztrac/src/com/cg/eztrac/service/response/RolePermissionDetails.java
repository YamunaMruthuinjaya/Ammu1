package com.cg.eztrac.service.response;

import java.util.List;

public class RolePermissionDetails {
	Integer roleId;
	String roleName;
	List<SubSectionDetails> subSections;
	
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public List<SubSectionDetails> getSubSections() {
		return subSections;
	}
	public void setSubSections(List<SubSectionDetails> subSections) {
		this.subSections = subSections;
	}
	

}
