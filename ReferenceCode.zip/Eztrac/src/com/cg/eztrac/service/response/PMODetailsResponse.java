package com.cg.eztrac.service.response;

import com.cg.eztrac.common.IRestServiceResponse;

public class PMODetailsResponse implements IRestServiceResponse  {

	private Integer userId;
	private String name;
	
	@Override
	public String getTokenId() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getResponseCode() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getResponseDescription() {
		// TODO Auto-generated method stub
		return null;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}