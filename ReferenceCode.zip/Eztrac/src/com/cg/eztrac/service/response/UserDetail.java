package com.cg.eztrac.service.response;

public class UserDetail {
	/** LOGIN RESPONSE USERDETAIL */
	private String eventDate;
	private String username;
	private String emailId;
	//private String location;
	private String employeeCode;
	private String unitAssigned;
	private String gdcName;
	private String accountName;
	private String subAccountName;
	private String sbu;
	private int userId;
	private String clientReportingFlag;
	private Integer clientSsoId;
	private String inductionFlag;
	private String telOfficeNum;
	private String telMobileNum;
	private int subAccountId;
	/**
	 * @return the eventDate
	 */
	

	public String getEventDate() {
		return eventDate;
	}
	/**
	 * @param eventDate the eventDate to set
	 */
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmailId() {
		return emailId;
	}
	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * @return the location
	 */
	/**
	 * @return the employeeCode
	 */
	public String getEmployeeCode() {
		return employeeCode;
	}
	/**
	 * @param employeeCode the employeeCode to set
	 */
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	/**
	 * @return the unitAssigned
	 */
	public String getUnitAssigned() {
		return unitAssigned;
	}
	/**
	 * @param unitAssigned the unitAssigned to set
	 */
	public void setUnitAssigned(String unitAssigned) {
		this.unitAssigned = unitAssigned;
	}
	/**
	 * @return the gdcName
	 */
	public String getGdcName() {
		return gdcName;
	}
	/**
	 * @param gdcName the gdcName to set
	 */
	public void setGdcName(String gdcName) {
		this.gdcName = gdcName;
	}
	/**
	 * @return the accountName
	 */
	public String getAccountName() {
		return accountName;
	}
	/**
	 * @param accountName the accountName to set
	 */
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	/**
	 * @return the subAccountName
	 */
	public String getSubAccountName() {
		return subAccountName;
	}
	/**
	 * @param subAccountName the subAccountName to set
	 */
	public void setSubAccountName(String subAccountName) {
		this.subAccountName = subAccountName;
	}
	/**
	 * @return the sbu
	 */
	public String getSbu() {
		return sbu;
	}
	/**
	 * @param sbu the sbu to set
	 */
	public void setSbu(String sbu) {
		this.sbu = sbu;
	}
	/**
	 * @return the userId
	 */
	public int getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}
	/**
	 * @return the clientReportingFlag
	 */
	public String getClientReportingFlag() {
		return clientReportingFlag;
	}
	/**
	 * @param clientReportingFlag the clientReportingFlag to set
	 */
	public void setClientReportingFlag(String clientReportingFlag) {
		this.clientReportingFlag = clientReportingFlag;
	}
	/**
	 * @return the clientSsoId
	 */
	public Integer getClientSsoId() {
		return clientSsoId;
	}
	/**
	 * @param clientSsoId the clientSsoId to set
	 */
	public void setClientSsoId(Integer clientSsoId) {
		this.clientSsoId = clientSsoId;
	}
	/**
	 * @return the inductionFlag
	 */
	public String getInductionFlag() {
		return inductionFlag;
	}
	/**
	 * @param inductionFlag the inductionFlag to set
	 */
	public void setInductionFlag(String inductionFlag) {
		this.inductionFlag = inductionFlag;
	}
	/**
	 * @return the telOfficeNum
	 */
	public String getTelOfficeNum() {
		return telOfficeNum;
	}
	/**
	 * @param telOfficeNum the telOfficeNum to set
	 */
	public void setTelOfficeNum(String telOfficeNum) {
		this.telOfficeNum = telOfficeNum;
	}
	/**
	 * @return the telMobileNum
	 */
	public String getTelMobileNum() {
		return telMobileNum;
	}
	/**
	 * @param telMobileNum the telMobileNum to set
	 */
	public void setTelMobileNum(String telMobileNum) {
		this.telMobileNum = telMobileNum;
	}
	/**
	 * @return the subAccountId
	 */
	public int getSubAccountId() {
		return subAccountId;
	}
	/**
	 * @param subAccountId the subAccountId to set
	 */
	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}


}
