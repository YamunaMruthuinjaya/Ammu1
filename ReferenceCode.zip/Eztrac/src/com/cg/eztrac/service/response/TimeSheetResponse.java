package com.cg.eztrac.service.response;

import java.util.List;

import com.cg.eztrac.common.IRestServiceResponse;

public class TimeSheetResponse implements IRestServiceResponse {
	
	private List<TimeSheetDetailResponse> timeSheet;
	private String tokenId;
	private String responseCode;
	private String responseDescription;	
	
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
	 * @return the timeSheetList
	 */
	public List<TimeSheetDetailResponse> getTimeSheetList() {
		return timeSheet;
	}
	/**
	 * @param timeSheetList the timeSheetList to set
	 */
	public void setTimeSheetList(List<TimeSheetDetailResponse> timeSheet) {
		this.timeSheet = timeSheet;
	}

	public class TimeSheetDetailResponse{
				
		private	int timeSheetId;
		private	int userId;
		private	String workDate;
		private int	buildId;
		private int	taskId;
		private int	subTaskId;
		private int	hoursWorked;
		private int	approvedBy;
		private String	approvedOn;
		private	String comments;
		private	int createdBy;
		private	String createdOn;
		private	int lastModifiedBy;
		private String lastModidfiedOn;
		private	int subSytemId;
		private	String perNumber;
		private	int perId;
		private	int loe_Onsite;
		private	int loe_Offshore;
		private	int loe_OnsiteConsumed;
		private	int loe_OffshoreConsumed;
		private	boolean onsiteFlag;
		private	boolean favouriteFlag;
		private String perDesc;
		private String statusCode;
		
		/**
		 * @return the timeSheetId
		 */
		public int getTimeSheetId() {
			return timeSheetId;
		}
		/**
		 * @param timeSheetId the timeSheetId to set
		 */
		public void setTimeSheetId(int timeSheetId) {
			this.timeSheetId = timeSheetId;
		}
		/**
		 * @return the userId
		 */
		public int getUserId() {
			return userId;
		}
		/**
		 * @param userId the userId to set
		 */
		public void setUserId(int userId) {
			this.userId = userId;
		}
		/**
		 * @return the workDate
		 */
		public String getWorkDate() {
			return workDate;
		}
		/**
		 * @param workDate the workDate to set
		 */
		public void setWorkDate(String workDate) {
			this.workDate = workDate;
		}
		/**
		 * @return the buildId
		 */
		public int getBuildId() {
			return buildId;
		}
		/**
		 * @param buildId the buildId to set
		 */
		public void setBuildId(int buildId) {
			this.buildId = buildId;
		}
		/**
		 * @return the taskId
		 */
		public int getTaskId() {
			return taskId;
		}
		/**
		 * @param taskId the taskId to set
		 */
		public void setTaskId(int taskId) {
			this.taskId = taskId;
		}
		/**
		 * @return the subTaskId
		 */
		public int getSubTaskId() {
			return subTaskId;
		}
		/**
		 * @param subTaskId the subTaskId to set
		 */
		public void setSubTaskId(int subTaskId) {
			this.subTaskId = subTaskId;
		}
		/**
		 * @return the hoursWorked
		 */
		public int getHoursWorked() {
			return hoursWorked;
		}
		/**
		 * @param hoursWorked the hoursWorked to set
		 */
		public void setHoursWorked(int hoursWorked) {
			this.hoursWorked = hoursWorked;
		}
		/**
		 * @return the approvedBy
		 */
		public int getApprovedBy() {
			return approvedBy;
		}
		/**
		 * @param approvedBy the approvedBy to set
		 */
		public void setApprovedBy(int approvedBy) {
			this.approvedBy = approvedBy;
		}
		/**
		 * @return the approvedOn
		 */
		public String getApprovedOn() {
			return approvedOn;
		}
		/**
		 * @param approvedOn the approvedOn to set
		 */
		public void setApprovedOn(String approvedOn) {
			this.approvedOn = approvedOn;
		}
		/**
		 * @return the comments
		 */
		public String getComments() {
			return comments;
		}
		/**
		 * @param comments the comments to set
		 */
		public void setComments(String comments) {
			this.comments = comments;
		}
		/**
		 * @return the createdBy
		 */
		public int getCreatedBy() {
			return createdBy;
		}
		/**
		 * @param createdBy the createdBy to set
		 */
		public void setCreatedBy(int createdBy) {
			this.createdBy = createdBy;
		}
		/**
		 * @return the createdOn
		 */
		public String getCreatedOn() {
			return createdOn;
		}
		/**
		 * @param createdOn the createdOn to set
		 */
		public void setCreatedOn(String createdOn) {
			this.createdOn = createdOn;
		}
		/**
		 * @return the lastModifiedBy
		 */
		public int getLastModifiedBy() {
			return lastModifiedBy;
		}
		/**
		 * @param lastModifiedBy the lastModifiedBy to set
		 */
		public void setLastModifiedBy(int lastModifiedBy) {
			this.lastModifiedBy = lastModifiedBy;
		}
		/**
		 * @return the lastModidfiedOn
		 */
		public String getLastModidfiedOn() {
			return lastModidfiedOn;
		}
		/**
		 * @param lastModidfiedOn the lastModidfiedOn to set
		 */
		public void setLastModidfiedOn(String lastModidfiedOn) {
			this.lastModidfiedOn = lastModidfiedOn;
		}
		/**
		 * @return the subSytemId
		 */
		public int getSubSytemId() {
			return subSytemId;
		}
		/**
		 * @param subSytemId the subSytemId to set
		 */
		public void setSubSytemId(int subSytemId) {
			this.subSytemId = subSytemId;
		}
		/**
		 * @return the perNumber
		 */
		public String getPerNumber() {
			return perNumber;
		}
		/**
		 * @param perNumber the perNumber to set
		 */
		public void setPerNumber(String perNumber) {
			this.perNumber = perNumber;
		}
		/**
		 * @return the perId
		 */
		public int getPerId() {
			return perId;
		}
		/**
		 * @param perId the perId to set
		 */
		public void setPerId(int perId) {
			this.perId = perId;
		}
		/**
		 * @return the loe_Onsite
		 */
		public int getLoe_Onsite() {
			return loe_Onsite;
		}
		/**
		 * @param loe_Onsite the loe_Onsite to set
		 */
		public void setLoe_Onsite(int loe_Onsite) {
			this.loe_Onsite = loe_Onsite;
		}
		/**
		 * @return the loe_Offshore
		 */
		public int getLoe_Offshore() {
			return loe_Offshore;
		}
		/**
		 * @param loe_Offshore the loe_Offshore to set
		 */
		public void setLoe_Offshore(int loe_Offshore) {
			this.loe_Offshore = loe_Offshore;
		}
		/**
		 * @return the loe_OnsiteConsumed
		 */
		public int getLoe_OnsiteConsumed() {
			return loe_OnsiteConsumed;
		}
		/**
		 * @param loe_OnsiteConsumed the loe_OnsiteConsumed to set
		 */
		public void setLoe_OnsiteConsumed(int loe_OnsiteConsumed) {
			this.loe_OnsiteConsumed = loe_OnsiteConsumed;
		}
		/**
		 * @return the loe_OffshoreConsumed
		 */
		public int getLoe_OffshoreConsumed() {
			return loe_OffshoreConsumed;
		}
		/**
		 * @param loe_OffshoreConsumed the loe_OffshoreConsumed to set
		 */
		public void setLoe_OffshoreConsumed(int loe_OffshoreConsumed) {
			this.loe_OffshoreConsumed = loe_OffshoreConsumed;
		}
		/**
		 * @return the onsiteFlag
		 */
		public boolean isOnsiteFlag() {
			return onsiteFlag;
		}
		/**
		 * @param onsiteFlag the onsiteFlag to set
		 */
		public void setOnsiteFlag(boolean onsiteFlag) {
			this.onsiteFlag = onsiteFlag;
		}
		/**
		 * @return the favouriteFlag
		 */
		public boolean isFavouriteFlag() {
			return favouriteFlag;
		}
		/**
		 * @param favouriteFlag the favouriteFlag to set
		 */
		public void setFavouriteFlag(boolean favouriteFlag) {
			this.favouriteFlag = favouriteFlag;
		}
		/**
		 * @return the perDesc
		 */
		public String getPerDesc() {
			return perDesc;
		}
		/**
		 * @param perDesc the perDesc to set
		 */
		public void setPerDesc(String perDesc) {
			this.perDesc = perDesc;
		}
		/**
		 * @return the statusCode
		 */
		public String getStatusCode() {
			return statusCode;
		}
		/**
		 * @param statusCode the statusCode to set
		 */
		public void setStatusCode(String statusCode) {
			this.statusCode = statusCode;
		}
	}
}