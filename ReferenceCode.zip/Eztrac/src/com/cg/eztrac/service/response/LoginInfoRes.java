package com.cg.eztrac.service.response;

import java.util.List;

import com.cg.eztrac.common.IRestServiceResponse;

public class LoginInfoRes implements IRestServiceResponse{
	
	private UserDetail userDedail;
	private List<RolePersmission> rolepermission;
	private List<UserLocations> userlocations;
	private String responseCode;
	private String responseDescription;


	public List<UserLocations> getUserlocations() {
		return userlocations;
	}
	public void setUserlocations(List<UserLocations> userlocations) {
		this.userlocations = userlocations;
	}
	public UserDetail getUserDedail() {
		return userDedail;
	}
	public void setUserDedail(UserDetail userDedail) {
		this.userDedail = userDedail;
	}
	public List<RolePersmission> getRolepermission() {
		return rolepermission;
	}
	public void setRolepermission(List<RolePersmission> rolepermission) {
		this.rolepermission = rolepermission;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	@Override
	public String getResponseCode() {
		return responseCode;
	}
	@Override
	public String getResponseDescription() {
		return responseDescription;
	}
	@Override
	public String getTokenId() {
		return null;
	}
	@Override
	public String getChannelId() {
		return null;
	}

}
