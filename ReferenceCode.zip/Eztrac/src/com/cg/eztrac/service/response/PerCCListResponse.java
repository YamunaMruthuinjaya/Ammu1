package com.cg.eztrac.service.response;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.domain.PerChangeControlDO;

@Component(value="perCCListResponse")
public class PerCCListResponse implements IRestServiceResponse {
	
	private List<PerChangeControlDO> perChangeControlList;
	private String tokenId;
	private String responseCode;
	private String responseDescription;
	
	public List<PerChangeControlDO> getPerChangeControlList() {
		return perChangeControlList;
	}
	public void setPerChangeControlList(List<PerChangeControlDO> perChangeControlList) {
		this.perChangeControlList = perChangeControlList;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String toString() {
		return "PerCCListResponse [perChangeControlList=" + perChangeControlList + ", tokenId=" + tokenId
				+ ", responseCode=" + responseCode + ", responseDescription=" + responseDescription + "]";
	}
	
}
