package com.cg.eztrac.service.response;

import java.util.List;

import com.cg.eztrac.common.IRestServiceResponse;

public class SystemDetailsResponse implements IRestServiceResponse  {

	private int subAccountId;
	private int systemID;
	private String systemName;
	private List<SubSystemResponse> subsystemDetails;
	
	@Override
	public String getTokenId() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getResponseCode() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getResponseDescription() {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * @return the subAccountId
	 */
	public int getSubAccountId() {
		return subAccountId;
	}
	/**
	 * @param subAccountId the subAccountId to set
	 */
	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}
	/**
	 * @return the systemID
	 */
	public int getSystemID() {
		return systemID;
	}
	/**
	 * @param systemID the systemID to set
	 */
	public void setSystemID(int systemID) {
		this.systemID = systemID;
	}
	/**
	 * @return the systemName
	 */
	public String getSystemName() {
		return systemName;
	}
	/**
	 * @param systemName the systemName to set
	 */
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	
	/**
	 * @return the subsystemDetails
	 */
	public List<SubSystemResponse> getSubsystemDetails() {
		return subsystemDetails;
	}
	/**
	 * @param subsystemDetails the subsystemDetails to set
	 */
	public void setSubsystemDetails(List<SubSystemResponse> subsystemDetails) {
		this.subsystemDetails = subsystemDetails;
	}

	public class SubSystemResponse{
		private int subSystemID;
		private String subSystemName;
		private String subSystemTech;
		private String subSystemEmail;
		
		/**
		 * @return the subSystemID
		 */
		public int getSubSystemID() {
			return subSystemID;
		}
		/**
		 * @param subSystemID the subSystemID to set
		 */
		public void setSubSystemID(int subSystemID) {
			this.subSystemID = subSystemID;
		}
		/**
		 * @return the subSystemName
		 */
		public String getSubSystemName() {
			return subSystemName;
		}
		/**
		 * @param subSystemName the subSystemName to set
		 */
		public void setSubSystemName(String subSystemName) {
			this.subSystemName = subSystemName;
		}
		/**
		 * @return the subSystemTech
		 */
		public String getSubSystemTech() {
			return subSystemTech;
		}
		/**
		 * @param subSystemTech the subSystemTech to set
		 */
		public void setSubSystemTech(String subSystemTech) {
			this.subSystemTech = subSystemTech;
		}
		/**
		 * @return the subSystemEmail
		 */
		public String getSubSystemEmail() {
			return subSystemEmail;
		}
		/**
		 * @param subSystemEmail the subSystemEmail to set
		 */
		public void setSubSystemEmail(String subSystemEmail) {
			this.subSystemEmail = subSystemEmail;
		}
	}
}