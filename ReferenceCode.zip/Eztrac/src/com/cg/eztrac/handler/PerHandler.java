package com.cg.eztrac.handler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.PMDetailsDO;
import com.cg.eztrac.domain.PerChangeControlDO;
import com.cg.eztrac.domain.PerDO;
import com.cg.eztrac.domain.PerListDO;
import com.cg.eztrac.domain.PurchaseOrderDO;
import com.cg.eztrac.domain.RoleDO;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.service.domainobject.SystemDetailsDO;
import com.cg.eztrac.vo.PMDetailsVO;
import com.cg.eztrac.vo.PerChangeControlVO;
import com.cg.eztrac.vo.PerListVO;
import com.cg.eztrac.vo.PerVO;
import com.cg.eztrac.vo.PurchaseOrderVO;
import com.cg.eztrac.vo.SystemDetailsVO;

@Component(value="perHandler")
public class PerHandler {
	
	private static final String CLASS_NAME = PerHandler.class.getSimpleName();
	
	private static final String DATE_FORMAT_YYYY_MM_DD = ICommonConstants.DATE_FORMAT_YYYY_MM_DD;
	
	/*@Autowired
	PerDO perDO;*/
	
	public void convertStringToDateFields(PerVO perVo) {
		
		String METHOD_NAME = "convertStringToDateFields";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.convertStringToDateFields()", "");
		
		if(!StringUtils.isEmpty(perVo.getPerReceiptDateString())) {
			perVo.setPerReceiptDate(getDateFromString(perVo.getPerReceiptDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getScheduleCallDateString())) {
			perVo.setScheduleCallDate(getDateFromString(perVo.getScheduleCallDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getCancellationDateString())) {
			perVo.setCancellationDate(getDateFromString(perVo.getCancellationDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getCurrentScheduleStartDateString())) {
			perVo.setCurrentScheduleStartDate(getDateFromString(perVo.getCurrentScheduleStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getCurrentScheduleEndDateString())) {
			perVo.setCurrentScheduleEndDate(getDateFromString(perVo.getCurrentScheduleEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getStopDateString())) {
			perVo.setStopDate(getDateFromString(perVo.getStopDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getRestartDateString())) {
			perVo.setRestartDate(getDateFromString(perVo.getRestartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReqStartDateString())) {
			perVo.getPhaseTimelines().setActualReqStartDate(getDateFromString(perVo.getPhaseTimelines().getActualReqStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReqEndDateString())) {
			perVo.getPhaseTimelines().setActualReqEndDate(getDateFromString(perVo.getPhaseTimelines().getActualReqEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualDesignStartDateString())) {
			perVo.getPhaseTimelines().setActualDesignStartDate(getDateFromString(perVo.getPhaseTimelines().getActualDesignStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualDesignEndDateString())) {
			perVo.getPhaseTimelines().setActualDesignEndDate(getDateFromString(perVo.getPhaseTimelines().getActualDesignEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualConStartDateString())) {
			perVo.getPhaseTimelines().setActualConStartDate(getDateFromString(perVo.getPhaseTimelines().getActualConStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualConEndDateString())) {
			perVo.getPhaseTimelines().setActualConEndDate(getDateFromString(perVo.getPhaseTimelines().getActualConEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualTestingStartDateString())) {
			perVo.getPhaseTimelines().setActualTestingStartDate(getDateFromString(perVo.getPhaseTimelines().getActualTestingStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualTestingEndDateString())) {
			perVo.getPhaseTimelines().setActualTestingEndDate(getDateFromString(perVo.getPhaseTimelines().getActualTestingEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReleaseStartDateString())) {
			perVo.getPhaseTimelines().setActualReleaseStartDate(getDateFromString(perVo.getPhaseTimelines().getActualReleaseStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReleaseEndDateString())) {
			perVo.getPhaseTimelines().setActualReleaseEndDate(getDateFromString(perVo.getPhaseTimelines().getActualReleaseEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
	}
	
	private Date getDateFromString(String dateString, String dateFormat) {
		String METHOD_NAME = "getDateFromString";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.getDateFromString()", "");
		return CommonUtility.getDateFromString(dateString, dateFormat);
	}
	
	private String getStringFromDate(Date date,String format) {
		String METHOD_NAME = "getStringFromDate";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.getStringFromDate()", "");
		return CommonUtility.getStringFromDate(date, format);
	}
	
	private String formatDate(String stringDate) {
		String METHOD_NAME = "formatDate";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.formatDate()", "");
		return getStringFromDate(getDateFromString(stringDate,ICommonConstants.DATE_FORMAT_YYYY_MM_DD),ICommonConstants.DATE_FORMAT_MM_DD_YYYY);
	}
	
	public void getPerList(PerListVO perListVO, HttpSession httpSession) throws CustomException {
		final String METHOD_NAME = "getPerList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.getPerList()","");
		
		PerListDO perListDO = new PerListDO();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying PerListVO to PerListDO","Dozer Bean Copy");
		CommonUtility.copyBeanProperties(perListVO,perListDO);
		
		//TODO - getting current roleDO of User
		UserDO userDO = null;
		RoleDO roleDO = null;
		if(null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching current roleDO from session","");
			userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
			roleDO = userDO.getCurrentRoleDO();
		}
		else {
			throw new CustomException("", "Session Failure... Kindly Login Again");
		}
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling roleDO.getPerList()", "Start");
			roleDO.getPerList(perListDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from roleDO.getPerList()", "End");
		} 
		catch(CustomException e){
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Per List  Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		if(null!=perListDO) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying perListDO to perListVO","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(perListDO, perListVO);
			
			//setting the date fields for Formatting the date display
			if(null!=perListVO.getPerList() && !perListVO.getPerList().isEmpty()){
				for (PerVO per : perListVO.getPerList()) {
					if(null!=per.getPhaseTimelines().getPlannedReqStartDateString()){
						per.getPhaseTimelines().setPlannedReqStartDateString(formatDate(per.getPhaseTimelines().getPlannedReqStartDateString()));
					}
					if(null!=per.getPhaseTimelines().getPlannedReleaseEndDateString()){
						per.getPhaseTimelines().setPlannedReleaseEndDateString(formatDate(per.getPhaseTimelines().getPlannedReleaseEndDateString()));
					}
					if(null!=per.getCurrentPhaseEndDateString()){
						per.setCurrentPhaseEndDateString(formatDate(per.getCurrentPhaseEndDateString()));
					}
				}
			}
			
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Return from PerHandler.getPerList::", "");
	}
	
	public void insertPerDetails(PerVO perVO,HttpSession httpSession) throws CustomException {
		final String METHOD_NAME = "insertPerDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.insertPerDetails()","");
		
		//Setting UserId for insertion
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting UserId","");
		perVO.setUserId(((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getUserId());
		
		//TODO - To avoid multiple copies of managers
		/*if(null!=perDO.getItpmManagerList()) {
			perDO.getItpmManagerList().clear();
		}*/
		//TODO
		/*if(null!=perVO.getItpmManagerList()) {
			perVO.getItpmManagerList().clear();
		}*/
		
		//TODO
		PerDO perDO = new PerDO();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying PerVO to PerDO","Dozer Bean Copy");
		CommonUtility.copyBeanProperties(perVO, perDO);
		
		//getting current roleDO of User
		UserDO userDO = null;
		RoleDO roleDO = null;
		if(null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching current roleDO from session","");
			userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
			roleDO = userDO.getCurrentRoleDO();
		}
		else {
			throw new CustomException("", "Session Failure... Kindly Login Again");
		}
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling roleDO.insertPerDetails()", "Start");
			roleDO.insertPerDetails(perDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from roleDO.insertPerDetails()", "End");
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Updating the Per details in Session", "");
			userDO.setCurrentRoleDO(roleDO);
			httpSession.setAttribute(ICommonConstants.USER_DETAILS, userDO);
		}catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Per Insert  Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}

		PerDO responsePerDO = null;
		if(null!=((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()){
			responsePerDO = ((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO();
			if(null!=responsePerDO) {
				//TODO - To avoid multiple copies of managers
				if(null!=perVO.getItpmManagerList()) {
					perVO.getItpmManagerList().clear();
				}
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying ResponsePerDO to perVO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(responsePerDO, perVO);
			}
		}
	}
	
	
	public PerVO getPerDetails(PerVO perVO,HttpSession httpSession) throws CustomException {
		final String METHOD_NAME = "getPerDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.getPerDetails:",perVO.getPerId()+"");
		
		//TODO
		PerDO perDO = new PerDO();
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying perVO to perDO","Dozer Bean Copy");
		CommonUtility.copyBeanProperties(perVO, perDO);
		
		//getting current roleDO of User
		UserDO userDO = null;
		RoleDO roleDO = null;
		if(null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching current roleDO from session","");
			userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
			roleDO = userDO.getCurrentRoleDO();
		}
		else {
			throw new CustomException("", "Session Failure... Kindly Login Again");
		}
			
		try{
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling roleDO.getPerDetails()", "Start");
			roleDO.getPerDetails(perDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from roleDO.getPerDetails()", "End");
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Updating the Per details in Session", "");
			userDO.setCurrentRoleDO(roleDO);
			httpSession.setAttribute(ICommonConstants.USER_DETAILS, userDO);
			
		}
		catch(CustomException e){
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Per Details  Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		PerDO responsePerDO = null;
		if(null!=((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()){
			responsePerDO = ((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO();
			if(null!=responsePerDO) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying ResponsePerDO to perVO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(responsePerDO, perVO);
			}
		}
		
		return perVO;
	}

	public void deletePer(PerVO perVO, HttpSession httpSession) throws CustomException {
		final String METHOD_NAME = "deletePer";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.deletePer:",perVO.getPerId()+"");
		
		//TODO
		PerDO perDO = new PerDO();
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying perVO to perDO","Dozer Bean Copy");
		CommonUtility.copyBeanProperties(perVO, perDO);
		
		//getting current roleDO of User
		UserDO userDO = null;
		RoleDO roleDO = null;
		if(null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching current roleDO from session","");
			userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
			roleDO = userDO.getCurrentRoleDO();
		}
		try{
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling roleDO.deletePer()", "Start");
			roleDO.deletePer(perDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from roleDO.deletePer()", "End");
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Updating the Per details in Session", "");
			userDO.setCurrentRoleDO(roleDO);
			httpSession.setAttribute(ICommonConstants.USER_DETAILS, userDO);
		}
		catch(CustomException e){
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Per Delete  Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		PerDO responsePerDO = null;
		if(null!=((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()){
			responsePerDO = ((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO();
			if(null!=responsePerDO) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying ResponsePerDO to perVO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(responsePerDO, perVO);
			}
		}
	}
	
	public boolean compareArrays(Integer[] newArray, Integer[] oldArray) {
		final String METHOD_NAME = "compareArrays";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside perHandler.compareArrays","");
		
		Arrays.sort(newArray);
	    Arrays.sort(oldArray);
	    
	    LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Comparing 2 arrays","");
		if (Arrays.equals(newArray, oldArray)) {
			System.out.println("Same");
			return true;
		}
		else{
			System.out.println("Not same");
			return false;
		}
	}
	
	//TODO -  TO construct the Managers to notify list for insertion
	public List<PMDetailsVO> constructManagersToNotifyList(Integer[] managersToNotifyArray, HttpSession httpSession) {
		final String METHOD_NAME = "constructManagersToNotifyList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside perHandler.constructManagersToNotifyList","");
		
		List<PMDetailsVO> notifiedManagersList = new ArrayList<PMDetailsVO>();
		
		if(null!=((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()){
			//TODO
			PerDO perDO = ((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO();
			
			//TODO - Constructing ManagersToNotifyArray, taken from session 
			Integer[] OldManagersToNotifyArray = null;
			List<PMDetailsDO> oldManagersToNotifyList = perDO.getItpmManagerList();
			if(null!=oldManagersToNotifyList) {
				List<Integer> OldManagersToNotifyArray1 = new ArrayList<Integer>();
				for (PMDetailsDO pmDetailsDO : oldManagersToNotifyList) {
					OldManagersToNotifyArray1.add(pmDetailsDO.getUserId());
				}
				int[] array = OldManagersToNotifyArray1.stream().mapToInt(i->i).toArray();
				OldManagersToNotifyArray = ArrayUtils.toObject(array);
			}
			
			//If all the resources are terminated
			if(null==managersToNotifyArray && null!=OldManagersToNotifyArray){
				for (Integer resourceId : OldManagersToNotifyArray) {
					PMDetailsVO pmDetailsVO = new PMDetailsVO();
					pmDetailsVO.setUserId(resourceId);
					pmDetailsVO.setPmStatus("T");
					notifiedManagersList.add(pmDetailsVO);
				}
			}
			
			else if(null!=managersToNotifyArray && null!=OldManagersToNotifyArray){
				if(compareArrays(managersToNotifyArray,OldManagersToNotifyArray)){
					//If same 
					notifiedManagersList = null;
				}
				else{
					//set status to A or T accordingly
					for (Integer newUserId : managersToNotifyArray) {
						
						if(Arrays.asList(OldManagersToNotifyArray).contains(newUserId)) {
							continue;
						}
						else {
							PMDetailsVO pmDetailsVO = new PMDetailsVO();
							pmDetailsVO.setUserId(newUserId);
							pmDetailsVO.setPmStatus("A");
							notifiedManagersList.add(pmDetailsVO);
						}
					}
					for (Integer oldUserId : OldManagersToNotifyArray) {
						
						if(Arrays.asList(managersToNotifyArray).contains(oldUserId)) {
							continue;
						}
						else {
							PMDetailsVO pmDetailsVO = new PMDetailsVO();
							pmDetailsVO.setUserId(oldUserId);
							pmDetailsVO.setPmStatus("T");
							notifiedManagersList.add(pmDetailsVO);
						}
					}
				}
			}
			
			//If the resources are newly added
			else if(null!=managersToNotifyArray && null==OldManagersToNotifyArray){
				for (Integer resourceId : managersToNotifyArray) {
					PMDetailsVO pmDetailsVO = new PMDetailsVO();
					pmDetailsVO.setUserId(resourceId);
					pmDetailsVO.setPmStatus("A");
					notifiedManagersList.add(pmDetailsVO);
				}
			}
			else{
				notifiedManagersList = null;
			}
		}
		else{
			//If session is empty and resources are added newly
			if(null!=managersToNotifyArray){
				for (Integer resourceId : managersToNotifyArray) {
					PMDetailsVO pmDetailsVO = new PMDetailsVO();
					pmDetailsVO.setUserId(resourceId);
					pmDetailsVO.setPmStatus("A");
					notifiedManagersList.add(pmDetailsVO);
				}
			}
			else{
				notifiedManagersList = null;
			}
		}
		
		return notifiedManagersList;
	}

	public PurchaseOrderVO formPurchaseOrder(PurchaseOrderVO purchaseOrder, HttpSession httpSession) {
		final String METHOD_NAME = "formPurchaseOrder";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside perHandler.formPurchaseOrder","");
		
		//TODO
		PerDO perDO = new PerDO();
		
		if(null!=((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()){
			perDO = ((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO();
			List<PurchaseOrderDO> purchaseOrderList = perDO.getPurchaseOrderList();
			if(null!=purchaseOrderList) {
				for (PurchaseOrderDO existingPO : purchaseOrderList) {
					if(purchaseOrder.getPoNumber().equals(existingPO.getPoNumber())) {
						purchaseOrder=null;
						break;
					}
				}
			}
		}
		return purchaseOrder;
	}
	
	public void getPerCCList(PerVO perVO, HttpSession httpSession) throws CustomException {
		final String METHOD_NAME = "getPerCCList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.getPerCCList()","");
		
		PerDO perDO = new PerDO();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying PerVO to PerDO","Dozer Bean Copy");
		CommonUtility.copyBeanProperties(perVO,perDO);
		
		//TODO - getting current roleDO of User
		UserDO userDO = null;
		RoleDO roleDO = null;
		if(null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching current roleDO from session","");
			userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
			roleDO = userDO.getCurrentRoleDO();
		}
		else {
			throw new CustomException("", "Session Failure... Kindly Login Again");
		}
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling roleDO.getPerCCList()", "Start");
			roleDO.getPerCCList(perDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from roleDO.getPerCCList()", "End");
		} 
		catch(CustomException e){
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Per CC List  Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		if(null!=perDO) {
			System.out.println(perDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying perDO to perVO","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(perDO, perVO);
			
			//setting the date fields for Formatting the date display
			if(null!=perVO.getPerChangeControlList() && !perVO.getPerChangeControlList().isEmpty()){
				for (PerChangeControlVO perCC : perVO.getPerChangeControlList()) {
					if(null!=perCC.getCcLastModifiedOnString()){
						perCC.setCcLastModifiedOnString(formatDate(perCC.getCcLastModifiedOnString()));
					}
					if(null!=perCC.getCcCreatedOnString()){
						perCC.setCcCreatedOnString(formatDate(perCC.getCcCreatedOnString()));
					}
					if(null!=perCC.getCcStartDateString()){
						perCC.setCcStartDateString(formatDate(perCC.getCcStartDateString()));
					}
					if(null!=perCC.getCcEndDateString()){
						perCC.setCcEndDateString(formatDate(perCC.getCcEndDateString()));
					}
				}
			}
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Return from PerHandler.getPerCCList::", "");
	}
	
	
	public PerVO getPerCCDetails(PerVO perVO,HttpSession httpSession) throws CustomException {
		final String METHOD_NAME = "getPerCCDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.getPerCCDetails:","");
		
		//TODO
		PerDO perDO = new PerDO();
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying perVO to perDO","Dozer Bean Copy");
		CommonUtility.copyBeanProperties(perVO, perDO);
		
		//getting current roleDO of User
		UserDO userDO = null;
		RoleDO roleDO = null;
		if(null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching current roleDO from session","");
			userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
			roleDO = userDO.getCurrentRoleDO();
		}
		else {
			throw new CustomException("", "Session Failure... Kindly Login Again");
		}
			
		try{
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling roleDO.getPerCCDetails()", "Start");
			roleDO.getPerCCDetails(perDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from roleDO.getPerCCDetails()", "End");
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Updating the Per details in Session", "");
			userDO.setCurrentRoleDO(roleDO);
			httpSession.setAttribute(ICommonConstants.USER_DETAILS, userDO);
			
		}
		catch(CustomException e){
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Per CC Details  Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		PerDO responsePerDO = null;
		if(null!=((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()){
			responsePerDO = ((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO();
			if(null!=responsePerDO) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying ResponsePerDO to perVO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(responsePerDO, perVO);
			}
		}
		
		return perVO;
	}
	
	public void insertPerCCDetails(PerVO perVO,HttpSession httpSession) throws CustomException {
		final String METHOD_NAME = "insertPerCCDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.insertPerCCDetails()","");
		
		//Setting UserId for insertion
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting UserId","");
		perVO.setUserId(((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getUserId());
		
		//TODO
		PerDO perDO = new PerDO();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying PerVO to PerDO","Dozer Bean Copy");
		CommonUtility.copyBeanProperties(perVO, perDO);
		
		//getting current roleDO of User
		UserDO userDO = null;
		RoleDO roleDO = null;
		if(null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching current roleDO from session","");
			userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
			roleDO = userDO.getCurrentRoleDO();
		}
		else {
			throw new CustomException("", "Session Failure... Kindly Login Again");
		}
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling roleDO.insertPerCCDetails()", "Start");
			roleDO.insertPerCCDetails(perDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from roleDO.insertPerCCDetails()", "End");
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Updating the Per CC details in Session", "");
			userDO.setCurrentRoleDO(roleDO);
			httpSession.setAttribute(ICommonConstants.USER_DETAILS, userDO);
		}catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Per Insert CC Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}

		PerDO responsePerDO = null;
		if(null!=((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()){
			responsePerDO = ((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO();
			if(null!=responsePerDO) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying ResponsePerDO to perVO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(responsePerDO, perVO);
			}
		}
	}

	//TODO -  TO construct the Teams Involved list for insertion
		public List<SystemDetailsVO> constructPerCCTeamsInvolvedList(Integer[] teamsInvolvedArray, HttpSession httpSession) {
			final String METHOD_NAME = "constructPerCCTeamsInvolvedList";
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside perHandler.constructPerCCTeamsInvolvedList","");
			
			List<SystemDetailsVO> involvedTeamList = new ArrayList<SystemDetailsVO>();
			
			if(null!=((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()){
				//TODO
				PerDO perDO = ((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO();
				
				if(null!=perDO.getPerChangeControl()){
					PerChangeControlDO perCC = perDO.getPerChangeControl();
					
					//TODO - Constructing teamsInvolvedArray, taken from session 
					Integer[] OldTeamsInvolvedArray = null;
					List<SystemDetailsDO> OldTeamsInvolvedList = perCC.getPerCCteamsInvolved();
					if(null!=OldTeamsInvolvedList && !OldTeamsInvolvedList.isEmpty()) {
						List<Integer> teamsInvolvedArray1 = new ArrayList<Integer>();
						for (SystemDetailsDO systemDetailsDO : OldTeamsInvolvedList) {
							teamsInvolvedArray1.add(systemDetailsDO.getSystemID());
						}
						int[] array = teamsInvolvedArray1.stream().mapToInt(i->i).toArray();
						OldTeamsInvolvedArray = ArrayUtils.toObject(array);
					}
					
					//If all the resources are terminated
					if(null==teamsInvolvedArray && null!=OldTeamsInvolvedArray){
						for (Integer systemId : OldTeamsInvolvedArray) {
							SystemDetailsVO systemDetailsVO = new SystemDetailsVO();
							systemDetailsVO.setSystemID(systemId);
							systemDetailsVO.setSystemStatus("T");
							involvedTeamList.add(systemDetailsVO);
						}
					}
					
					else if(null!=teamsInvolvedArray && null!=OldTeamsInvolvedArray){
						if(compareArrays(teamsInvolvedArray,OldTeamsInvolvedArray)){
							//If same 
							involvedTeamList = null;
						}
						else{
							//set status to A or T accordingly
							for (Integer newSystemId : teamsInvolvedArray) {
								
								if(Arrays.asList(OldTeamsInvolvedArray).contains(newSystemId)) {
									continue;
								}
								else {
									SystemDetailsVO systemDetailsVO = new SystemDetailsVO();
									systemDetailsVO.setSystemID(newSystemId);
									systemDetailsVO.setSystemStatus("A");
									involvedTeamList.add(systemDetailsVO);
								}
							}
							for (Integer oldSystemId : OldTeamsInvolvedArray) {
								
								if(Arrays.asList(teamsInvolvedArray).contains(oldSystemId)) {
									continue;
								}
								else {
									SystemDetailsVO systemDetailsVO = new SystemDetailsVO();
									systemDetailsVO.setSystemID(oldSystemId);
									systemDetailsVO.setSystemStatus("T");
									involvedTeamList.add(systemDetailsVO);
								}
							}
						}
					}
					
					//If the resources are newly added
					else if(null!=teamsInvolvedArray && null==OldTeamsInvolvedArray){
						for (Integer systemId : teamsInvolvedArray) {
							SystemDetailsVO systemDetailsVO = new SystemDetailsVO();
							systemDetailsVO.setSystemID(systemId);
							systemDetailsVO.setSystemStatus("A");
							involvedTeamList.add(systemDetailsVO);
						}
					}
					else{
						involvedTeamList = null;
					}
				}
				else{
					if(null!=teamsInvolvedArray){
						for (Integer systemId : teamsInvolvedArray) {
							SystemDetailsVO systemDetailsVO = new SystemDetailsVO();
							systemDetailsVO.setSystemID(systemId);
							systemDetailsVO.setSystemStatus("A");
							involvedTeamList.add(systemDetailsVO);
						}
					}
					else{
						involvedTeamList = null;
					}
				}
				
			}
			else{
				//If session is empty and resources are added newly
				if(null!=teamsInvolvedArray){
					for (Integer systemId : teamsInvolvedArray) {
						SystemDetailsVO systemDetailsVO = new SystemDetailsVO();
						systemDetailsVO.setSystemID(systemId);
						systemDetailsVO.setSystemStatus("A");
						involvedTeamList.add(systemDetailsVO);
					}
				}
				else{
					involvedTeamList = null;
				}
			}
			
			return involvedTeamList;
		}
	
	
}
