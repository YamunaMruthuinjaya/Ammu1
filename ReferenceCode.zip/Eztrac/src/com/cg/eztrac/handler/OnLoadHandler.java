package com.cg.eztrac.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.PMDetailsDO;
import com.cg.eztrac.domain.PMODetailsDO;
import com.cg.eztrac.domain.ParamDO;
import com.cg.eztrac.domain.ParamDetailsDO;
import com.cg.eztrac.domain.ResourceDetailsDO;
import com.cg.eztrac.domain.RolePermissionDO;
import com.cg.eztrac.domain.SectionDetailDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.service.domainobject.SystemDetailsDO;
import com.cg.eztrac.vo.ParamVO;

@Component
public class OnLoadHandler {
	private static final String className = OnLoadHandler.class.getSimpleName();
	

	
	public Map<String, List<ParamVO>> loadParamDetails() throws CustomException{
		String METHOD_NAME = "loadParamDetails";
		ParamDetailsDO paramDetailsDO = new ParamDetailsDO();
		paramDetailsDO.setSubAccountId(ICommonConstants.SUB_ACCOUN_ID);
		paramDetailsDO.setStatus_CD("Y");
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.APPLICATION_CONTEXT+ "In onload handler", "Before calling the callParamDetailsService() from onloadhandler class");
		List<ParamDetailsDO> paramDetailsDOList = paramDetailsDO.callParamDetailsService(paramDetailsDO);
		Map<String, List<ParamVO>> mapOfParamVOList = getMapOfParamDetailsList(paramDetailsDOList);
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.APPLICATION_CONTEXT+ "In onload handler", "After calling the callParamDetailsService() from onloadhandler class");
		return mapOfParamVOList;
	}
	
	private Map<String, List<ParamVO>> getMapOfParamDetailsList(List<ParamDetailsDO> paramDetailsDOList) throws CustomException{
		String METHOD_NAME = "getMapOfParamDetailsList";
		Map<String, List<ParamVO>> mapOfParamVOList = new HashMap<String, List<ParamVO>>();
		try {
			if(null != paramDetailsDOList && !paramDetailsDOList.isEmpty()) {
				for(ParamDetailsDO paramDetailsDO : paramDetailsDOList) {
					List<ParamDO> paramDOList = paramDetailsDO.getParamValue();
					List<ParamVO> paramVOList = new ArrayList<ParamVO>();
					LoggerManager.writeInfoLog(className, METHOD_NAME,  "In onload handler:paramDetailsDO:"+paramDetailsDO.toString(), "Before calling the callParamDetailsService() from onloadhandler class");
					for(ParamDO paramDO : paramDOList) {
						ParamVO paramVO = new ParamVO();
						CommonUtility.copyBeanProperties(paramDO, paramVO);
						LoggerManager.writeInfoLog(className, METHOD_NAME, "In onload handler:paramVO:"+paramVO.toString(), "Before calling the callParamDetailsService() from onloadhandler class");
						paramVOList.add(paramVO);
					}
					mapOfParamVOList.put(paramDetailsDO.getParamTypeName(), paramVOList);
					LoggerManager.writeInfoLog(className, METHOD_NAME,  "In onload handler:mapOfParamVOList:"+mapOfParamVOList.toString(), "Before calling the callParamDetailsService() from onloadhandler class");
				}
			}
		} catch (CustomException ex) {
			ex.printStackTrace();
			LoggerManager.writeErrorLog(className, METHOD_NAME,  "In onload handler", ex, "After calling the callParamDetailsService() from onloadhandler class");
		}
		return mapOfParamVOList;
	}
	
	public List<SectionDetailDO> loadSectionDetails()  throws CustomException{
		String METHOD_NAME = "loadSectionDetails";
		SectionDetailDO sectionDetailDO = new SectionDetailDO();
		sectionDetailDO.setSubAccounId(ICommonConstants.SUB_ACCOUN_ID);
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.APPLICATION_CONTEXT+"In onload handler", ICommonConstants.SECTION_DETAILS_SERVICES_FLOW+"Before calling the callSectionDetailService() from onloadhandler class");
		List<SectionDetailDO> sectionDetailResponse=null;
		try {
			sectionDetailResponse = sectionDetailDO.callSectionDetailService(sectionDetailDO);
		} catch (CustomException e) {
			e.printStackTrace();
		}
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.APPLICATION_CONTEXT+ "In onload handler", ICommonConstants.SECTION_DETAILS_SERVICES_FLOW+"After calling the callSectionDetailService() from onloadhandler class");
		return sectionDetailResponse;
	}
	
	public List<RolePermissionDO> loadRolePermissionDetails() throws CustomException{
		String METHOD_NAME = "loadRolePermissionDetails";
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.APPLICATION_CONTEXT +"In onload handler", ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+"Before calling the callRolePermissionService() from onloadhandler class");
		List<RolePermissionDO> rolePermissionReponse=null;
		try {
			rolePermissionReponse = new RolePermissionDO().callRolePermissionService();
		} catch (CustomException e) {
			e.printStackTrace();
		}
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.APPLICATION_CONTEXT+"In onload handler",ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+ "After calling the callRolePermissionService() from onloadhandler class");
		return rolePermissionReponse;
	}
	
	public List<SystemDetailsDO> loadSystemDetails() throws CustomException{
		String METHOD_NAME = "loadSystemDetails";
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.LOGIN_SERVICE_LOG_KEY +"In onload handler", "Before calling the callSectionDetailService() from onloadhandler class");
		SystemDetailsDO systemDetailsDO = new SystemDetailsDO();
		List<SystemDetailsDO> systemDetailsDOList = systemDetailsDO.callSystemDetailService(systemDetailsDO);
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.LOGIN_SERVICE_LOG_KEY +"In onload handler", "Before calling the callSectionDetailService() from onloadhandler class");
		return systemDetailsDOList;
	}

	public List<PMODetailsDO> loadPMODetails() throws CustomException{
		String METHOD_NAME = "loadPMODetails";
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.LOGIN_SERVICE_LOG_KEY +"In onload handler", "Before calling the callPMODetailService() from onloadhandler class");
		PMODetailsDO pmoDetailsDO = new PMODetailsDO(); 
		List<PMODetailsDO> pmoDetailsDOList = pmoDetailsDO.callPMODetailService(pmoDetailsDO);
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.LOGIN_SERVICE_LOG_KEY +"In onload handler", "After calling the callPMODetailService() from onloadhandler class");
		return pmoDetailsDOList;
	}

	public List<PMDetailsDO> loadPMDetails() throws CustomException{
		String METHOD_NAME = "loadPMDetails";
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.LOGIN_SERVICE_LOG_KEY +"In onload handler", "Before calling the callPMDetailService() from onloadhandler class");
		PMDetailsDO pmDetailsDO = new PMDetailsDO(); 
		List<PMDetailsDO> pmDetailsDOList = pmDetailsDO.callPMDetailService(pmDetailsDO);
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.LOGIN_SERVICE_LOG_KEY +"In onload handler", "After calling the callPMDetailService() from onloadhandler class");
		return pmDetailsDOList;
	}

	public List<ResourceDetailsDO> loadResourceDetails() {
		String METHOD_NAME = "loadResourceDetails";
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.LOGIN_SERVICE_LOG_KEY +"In onload handler", "Before calling the callResourceDetailService() from onloadhandler class");
		ResourceDetailsDO resourceDetailsDO = new ResourceDetailsDO(); 
		List<ResourceDetailsDO> resourceDetailsDOList = resourceDetailsDO.callResourceDetailService(resourceDetailsDO);
		LoggerManager.writeInfoLog(className, METHOD_NAME, ICommonConstants.LOGIN_SERVICE_LOG_KEY +"In onload handler", "After calling the callResourceDetailService() from onloadhandler class");
		return resourceDetailsDOList;
	}
	
	
}
