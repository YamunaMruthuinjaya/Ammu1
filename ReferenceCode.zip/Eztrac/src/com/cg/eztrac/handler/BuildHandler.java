package com.cg.eztrac.handler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.thymeleaf.processor.ICommentNodeProcessorMatcher;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.BuildChangeControlDO;
import com.cg.eztrac.domain.BuildDO;
import com.cg.eztrac.domain.BuildListDO;
import com.cg.eztrac.domain.PerDO;
import com.cg.eztrac.domain.PerListDO;
import com.cg.eztrac.domain.ResourceDetailsDO;
import com.cg.eztrac.domain.RoleDO;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.vo.BuildChangeControlVO;
import com.cg.eztrac.vo.BuildListVO;
import com.cg.eztrac.vo.BuildVO;
import com.cg.eztrac.vo.ResourceDetailsVO;

@Component(value="buildHandler")
public class BuildHandler {
	
	private static final String CLASS_NAME = BuildHandler.class.getSimpleName();
	
	/*@Autowired
	BuildDO buildDO;*/
	
	
	public void getBuildList(BuildListVO buildListVO, HttpSession httpSession) throws CustomException {
		final String METHOD_NAME = "getBuildList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildHandler.getBuildList()", "");
		
		PerDO perDO = new PerDO();
		BuildListDO buildListDO = new BuildListDO();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildListVO to buildListDO","Dozer Bean Copy");
		CommonUtility.copyBeanProperties(buildListVO, buildListDO);

		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling perDO.getBuildList()", "Start");
			perDO.getBuildList(buildListDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perDO.getBuildList()", "End");
		}
		catch (CustomException e) {
			System.out.println("BuildHandler-buildlist catch block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildListResponse Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		if(null != buildListDO) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildListDO to buildListVO","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(buildListDO, buildListVO);
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Return from BuildHandler.getBuildList()", "");
	}
	
	public void getBuildDetails(BuildVO buildVO, HttpSession httpSession) throws CustomException {
		final String METHOD_NAME = "getBuildDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildHandler.getBuildDetails()", "");
		//TODO
		BuildDO buildDO = new BuildDO();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildVO to buildDO","Dozer Bean Copy");
		CommonUtility.copyBeanProperties(buildVO, buildDO);
		
		//getting current roleDO of User
		UserDO userDO = null;
		RoleDO roleDO = null;
		PerDO perDO = null;
		
		if(null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching current RoleDO from session","");
			userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
			roleDO = userDO.getCurrentRoleDO();
			perDO=new PerDO();
		}
		else {
			throw new CustomException("", "Session Failure... Kindly Login Again");
		}
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling perDO.getBuildDetails()", "Start");
			perDO.getBuildDetails(buildDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perDO.getBuildDetails()", "End");
			
			//Forming the PerDO with basic information, to add it in session - To sync with build
			perDO.setPerId(perDO.getBuildDO().getPerId());
			perDO.setPerNumber(perDO.getBuildDO().getPerNumber());
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Updating the Build details in Session", "");
			roleDO.setPerDO(perDO);
			userDO.setCurrentRoleDO(roleDO);
			httpSession.setAttribute(ICommonConstants.USER_DETAILS, userDO);
		}
		
		catch (CustomException e) {
			System.out.println("BuildHandler - builddetails catch block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildDetailsResponse Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		if(null != ((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()) {
			BuildDO buildDODetails = ((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO().getBuildDO();
			if(null!=buildDODetails) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildDODetails to buildVO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(buildDODetails, buildVO);
			}
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Return from BuildHandler.getBuildDetails()", "");
	}
	
	public void insertBuildDetails(BuildVO buildVO, HttpSession httpSession) throws CustomException {
		final String METHOD_NAME = "insertBuildDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildHandler.insertBuildDetails()","");
		
		BuildDO buildDO = new BuildDO();
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting UserId","");
		buildVO.setUserId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getUserId());
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildVO to buildDO","Dozer Bean Copy");
		CommonUtility.copyBeanProperties(buildVO, buildDO);
		
		//getting current roleDO of User
		UserDO userDO = null;
		RoleDO roleDO = null;
		PerDO perDO = null;
		
		if(null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching current RoleDO from session","");
			userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
			roleDO = userDO.getCurrentRoleDO();
			perDO=new PerDO();
		}
		else {
			throw new CustomException("", "Session Failure... Kindly Login Again");
		}
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling perDO.insertBuildDetails()", "Start");
			perDO.insertBuildDetails(buildDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perDO.insertBuildDetails()", "End");
			
			//Forming the PerDO with basic information, to add it in session - To sync with build
			perDO.setPerId(perDO.getBuildDO().getPerId());
			perDO.setPerNumber(perDO.getBuildDO().getPerNumber());
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Updating the Build details in Session", "");
			roleDO.setPerDO(perDO);
			userDO.setCurrentRoleDO(roleDO);
			httpSession.setAttribute(ICommonConstants.USER_DETAILS, userDO);
		}
		catch (CustomException e) {
			System.out.println("BuildHandler - insertBuildDetails Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildInsertResponse Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		if(null != ((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()) {
			BuildDO buildDODetails = ((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO().getBuildDO();
			if(null!=buildDODetails) {
				//TODO - To avoid multiple copies of resources
				if(null!=buildVO.getAssignedResourcesList()) {
					buildVO.getAssignedResourcesList().clear();
				}
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildDODetails to buildVO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(buildDODetails, buildVO);
			}
		}
	}

	public void deleteBuild(BuildVO buildVO, HttpSession httpSession) throws CustomException {
		final String METHOD_NAME = "deleteBuild";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildHandler.deleteBuild()","");
		//TODO
		BuildDO buildDO = new BuildDO();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildVO to buildDO","Dozer Bean Copy");
		CommonUtility.copyBeanProperties(buildVO, buildDO);
		
		
		//getting current roleDO of User
		UserDO userDO = null;
		RoleDO roleDO = null;
		PerDO perDO = null;
		if(null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching current RoleDO from session","");
			userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
			roleDO = userDO.getCurrentRoleDO();
			perDO = new PerDO();
		}
		else {
			throw new CustomException("", "Session Failure... Kindly Login Again");
		}
		
		try{
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling perDO.deleteBuild()", "Start");
			perDO.deleteBuild(buildDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perDO.deleteBuild()", "End");
			
			//Forming the PerDO with basic information, to add it in session - To sync with build
			if(null!=perDO.getBuildDO().getPerId() && null!=perDO.getBuildDO().getPerNumber()) {
				perDO.setPerId(perDO.getBuildDO().getPerId());
				perDO.setPerNumber(perDO.getBuildDO().getPerNumber());
			}
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Updating the Build details in Session", "");
			roleDO.setPerDO(perDO);
			userDO.setCurrentRoleDO(roleDO);
			httpSession.setAttribute(ICommonConstants.USER_DETAILS, userDO);
			
		}catch(CustomException e){
			System.out.println("BuildHandler - deleteBuild Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildDeleteResponse Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		if(null != ((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()) {
			BuildDO buildDODetails = ((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO().getBuildDO();
			if(null!=buildDODetails) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildDODetails to buildVO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(buildDODetails, buildVO);
			}
		}
	}
	
	public Map<Integer, String> getPerList(HttpSession httpSession) throws CustomException {
		final String METHOD_NAME = "getPerList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildHandler.getPerList()","");
		
		//TODO - getting current roleDO of User
		UserDO userDO = null;
		RoleDO roleDO = null;
		if(null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching current roleDO from session","");
			userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
			roleDO = userDO.getCurrentRoleDO();
		}
		else {
			throw new CustomException("", "Session Failure... Kindly Login Again");
		}
		
		PerDO perDO = new PerDO();
		PerListDO perListDO = new PerListDO();
		perListDO.setPer(perDO);
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling roleDO.getPerList()", "Start");
			roleDO.getPerList(perListDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from roleDO.getPerList()", "End");
		} catch(CustomException e){
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Per List  Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "forming perNumbers Map", "");
		Map<Integer,String> perNumbersMap = new HashMap<Integer, String>();
		if(null != perListDO) {
			List<PerDO> perDOList = perListDO.getPerList();
			for (PerDO perDO1 : perDOList) {
				perNumbersMap.put(perDO1.getPerId(), perDO1.getPerNumber());
			}
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Return from BuildHandler.getPerList()","");
		return perNumbersMap;
	}

	public boolean compareAssignedTo(Integer[] assignedToArray, Integer[] oldAssignedToArray) {
		final String METHOD_NAME = "compareAssignedTo";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildHandler.compareAssignedTo","");
		
		Arrays.sort(assignedToArray);
	    Arrays.sort(oldAssignedToArray);
	    
	    LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Comparing 2 arrays","");
		if (Arrays.equals(assignedToArray, oldAssignedToArray)) {
			System.out.println("Same");
			return true;
		}
		else{
			System.out.println("Not same");
			return false;
		}
	}

	//TODO -  TO construct the Assigned To list for insertion
	public List<ResourceDetailsVO> constructAssignedToList(Integer[] assignedToArray,HttpSession httpSession) {
		final String METHOD_NAME = "constructAssignedToList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildHandler.constructAssignedToList","");
		
		List<ResourceDetailsVO> assignedResourcesList = new ArrayList<ResourceDetailsVO>();
		
		if(null!=((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO() && null!=((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO().getBuildDO()){
			//TODO
			BuildDO buildDO = ((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO().getBuildDO();
			
			//TODO - Constructing AssignedToArray, taken from session 
			Integer[] oldAssignedToArray = null;
			List<ResourceDetailsDO> oldAssignedResourcesList = buildDO.getAssignedResourcesList();
			if(null!=oldAssignedResourcesList) {
				List<Integer> oldAssignedToArray1 = new ArrayList<Integer>();
				for (ResourceDetailsDO resourceDetailsDO : oldAssignedResourcesList) {
					oldAssignedToArray1.add(resourceDetailsDO.getUserId());
				}
				int[] array = oldAssignedToArray1.stream().mapToInt(i->i).toArray();
				oldAssignedToArray=ArrayUtils.toObject(array);
			}
			
			//If all the resources are terminated
			if(null==assignedToArray && null!=oldAssignedToArray){
				for (Integer resourceId : oldAssignedToArray) {
					ResourceDetailsVO resourceDetailsVO = new ResourceDetailsVO();
					resourceDetailsVO.setUserId(resourceId);
					resourceDetailsVO.setResourceStatus("T");
					assignedResourcesList.add(resourceDetailsVO);
				}
			}
			
			else if(null!=assignedToArray && null!=oldAssignedToArray){
				if(compareAssignedTo(assignedToArray,oldAssignedToArray)){
					//if same
					assignedResourcesList = null;
				}
				else{
					//set status to A or T accordingly
					for (Integer newResourceId : assignedToArray) {
						if(Arrays.asList(oldAssignedToArray).contains(newResourceId)) {
							continue;
						}
						else {
							ResourceDetailsVO resourceDetailsVO = new ResourceDetailsVO();
							resourceDetailsVO.setUserId(newResourceId);
							resourceDetailsVO.setResourceStatus("A");
							assignedResourcesList.add(resourceDetailsVO);
						}
						
					}
					for (Integer oldResourceId : oldAssignedToArray) {
						if(Arrays.asList(assignedToArray).contains(oldResourceId)) {
							continue;
						}
						else {
							ResourceDetailsVO resourceDetailsVO = new ResourceDetailsVO();
							resourceDetailsVO.setUserId(oldResourceId);
							resourceDetailsVO.setResourceStatus("T");
							assignedResourcesList.add(resourceDetailsVO);
						}
					}
				}
			}
			
			//If the resources are newly added
			else if(null!=assignedToArray && null==oldAssignedToArray){
				for (Integer resourceId : assignedToArray) {
					ResourceDetailsVO resourceDetailsVO = new ResourceDetailsVO();
					resourceDetailsVO.setUserId(resourceId);
					resourceDetailsVO.setResourceStatus("A");
					assignedResourcesList.add(resourceDetailsVO);
				}
			}
			else{
				assignedResourcesList = null;
			}
		}
		else{
			//If session is empty and resources are added newly
			if(null!=assignedToArray){
				for (Integer resourceId : assignedToArray) {
					ResourceDetailsVO resourceDetailsVO = new ResourceDetailsVO();
					resourceDetailsVO.setUserId(resourceId);
					resourceDetailsVO.setResourceStatus("A");
					assignedResourcesList.add(resourceDetailsVO);
				}
			}
			else{
				assignedResourcesList = null;
			}
		}
		
		return assignedResourcesList;
	}
	
	public void populateBuildCcDetails(BuildVO buildVO, HttpSession httpSession) {
		String methodName = "populateBuildCcDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, "", "START");

		if (null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)) {

			UserDO userDO = (UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS);

			if (null != userDO.getCurrentRoleDO() && null != userDO.getCurrentRoleDO().getPerDO()
					&& null != userDO.getCurrentRoleDO().getPerDO().getBuildDO()) {
				PerDO perDO = userDO.getCurrentRoleDO().getPerDO();
				BuildDO buildDO = userDO.getCurrentRoleDO().getPerDO().getBuildDO();
				if (null == userDO.getCurrentRoleDO().getPerDO().getBuildDO().getBuildChangeControlList()
						|| userDO.getCurrentRoleDO().getPerDO().getBuildDO().getBuildChangeControlList().isEmpty()) {

					buildDO = new BuildDO();
					buildDO.setBuildId(buildVO.getBuildId());
					perDO.getAndSetBuildCcList(buildDO);
					CommonUtility.copyBeanProperties(buildDO, buildVO);

				} else {

					if (null == buildVO.getBuildChangeControlList()) {
						List<BuildChangeControlVO> buildChangeControlLists = new ArrayList<BuildChangeControlVO>();
						buildVO.setBuildChangeControlList(buildChangeControlLists);
					} else {
						buildVO.getBuildChangeControlList().clear();
					}
					CommonUtility.copyBeanProperties(buildDO.getBuildChangeControlList(),
							buildVO.getBuildChangeControlList());
				}
			}
		} else {
			throw new CustomException("SESFXX1", "Session Failure... Kindly Login Again");
		}

		LoggerManager.writeInfoLog(CLASS_NAME, methodName, "", "END");
	}
	
	public void populateBuildCcIdDetail(BuildVO buildVO, HttpSession httpSession, int buildCCId) throws Exception {

		if (null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)) {

			UserDO userDO = (UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS);

			if (null != userDO.getCurrentRoleDO() && null != userDO.getCurrentRoleDO().getPerDO()
					&& null != userDO.getCurrentRoleDO().getPerDO().getBuildDO()) {
				PerDO perDO = userDO.getCurrentRoleDO().getPerDO();
				BuildDO buildDO = userDO.getCurrentRoleDO().getPerDO().getBuildDO();

				perDO.getAndSetBuildCcId(buildDO, buildCCId);
				CommonUtility.copyBeanProperties(perDO.getBuildDO(), buildVO);

			}
		} else {
			throw new CustomException("SESFXX1", "Session Failure... Kindly Login Again");
		}
	}
	
	public boolean saveBuildCcDetails(BuildVO buildVO, HttpSession httpSession) throws CustomException {
		String methodName = "saveBuildCcDetails";
		boolean status = false;
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, "", "START");
		buildVO.getBuildChangeControl().setBuildId(buildVO.getBuildId());
		if (null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)) {

			UserDO userDO = (UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS);

			if (null != userDO.getCurrentRoleDO() && null != userDO.getCurrentRoleDO().getPerDO()
					&& null != userDO.getCurrentRoleDO().getPerDO().getBuildDO()) {

				PerDO perDO = userDO.getCurrentRoleDO().getPerDO();
				BuildDO buildDO = perDO.getBuildDO();

				CommonUtility.copyBeanProperties(buildVO, buildDO);
				
				if (null != buildDO.getBuildChangeControl()) {
					buildDO.getBuildChangeControl().setUserId(userDO.getUserId());
				} else {
					BuildChangeControlDO buildChangeControlDO = new BuildChangeControlDO();
					buildChangeControlDO.setUserId(userDO.getUserId());
					buildDO.setBuildChangeControl(buildChangeControlDO);

				}

				buildDO = perDO.saveBuildCC(buildDO);

				Map<String, String> resMaps = buildDO.getResponseMap();
				Map.Entry<String, String> entry = resMaps.entrySet().iterator().next();
				if (entry.getKey().trim().equalsIgnoreCase(ICommonConstants.SERVICESTATUS_SB1000)) {
					status = true;
				}
				CommonUtility.copyBeanProperties(buildDO,buildVO);

			} else {
				PerDO perDO = new PerDO();
				BuildDO buildDO = new BuildDO();
				CommonUtility.copyBeanProperties(buildVO, buildDO);

				if (null != buildDO.getBuildChangeControl()) {
					buildDO.getBuildChangeControl().setUserId(userDO.getUserId());
				} else {
					BuildChangeControlDO buildChangeControlDO = new BuildChangeControlDO();
					buildChangeControlDO.setUserId(userDO.getUserId());
					buildDO.setBuildChangeControl(buildChangeControlDO);

				}
				
				buildDO = perDO.saveBuildCC(buildDO);
				buildDO.getBuildChangeControl().setUserId(userDO.getUserId());
				
				userDO.getCurrentRoleDO().setPerDO(perDO);

				Map<String, String> resMaps = buildDO.getResponseMap();
				Map.Entry<String, String> entry = resMaps.entrySet().iterator().next();
				if (entry.getKey().equalsIgnoreCase(ICommonConstants.SERVICESTATUS_SB1000)) {
					status = true;
				}
				
				CommonUtility.copyBeanProperties(buildDO,buildVO);

			}
		}

		LoggerManager.writeInfoLog(CLASS_NAME, methodName, "", "END");
		return status;
	}

}
