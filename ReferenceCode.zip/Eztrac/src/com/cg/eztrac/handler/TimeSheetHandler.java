package com.cg.eztrac.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.domain.PerDO;
import com.cg.eztrac.domain.PerListDO;
import com.cg.eztrac.domain.RoleDO;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.service.domainobject.SubSystemDO;
import com.cg.eztrac.service.domainobject.SystemDetailsDO;
import com.cg.eztrac.service.domainobject.TimeSheetDO;
import com.cg.eztrac.service.domainobject.TimeSheetDetailDO;
import com.cg.eztrac.service.request.InsertTimeSheetRequest;
import com.cg.eztrac.vo.InvoiceVO;
import com.cg.eztrac.vo.TimeSheetDetailVO;
import com.cg.eztrac.vo.TimeSheetVO;

@Component(value="timeSheetHandler")
public class TimeSheetHandler {

	@Autowired
	ServletContextImpl servletContextImpl;
	
	private static final String CLASS_NAME = "TimeSheetHandler";

	
	public TimeSheetVO getTimeSheetList(HttpSession session, TimeSheetVO timeSheetVO) {
		final String METHOD_NAME="getTimeSheetList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered getTimeSheetList Handler method", "getTimeSheetList - Start");
		
		TimeSheetDO timeSheetDO = new TimeSheetDO();
		try {
			
			if(null!=timeSheetVO.getResourceId()){
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "setting the userId","");
				timeSheetVO.setUserId(timeSheetVO.getResourceId());
			}
			else{
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching UserDo and setting it to VO","");
				UserDO userDO=(UserDO) session.getAttribute(ICommonConstants.USER_DETAILS);
				timeSheetVO.setUserId(userDO.getUserId());
			}
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying timeSheetVO to timeSheetDO","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(timeSheetVO, timeSheetDO);
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching SystemDetails","");
			List<SystemDetailsDO> systemDetailsDOList=timeSheetVO.getSystemDetailsDOList();
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching latest invoice date","");
			InvoiceVO invoiceVO=(InvoiceVO)session.getAttribute(ICommonConstants.LATESTINVOICEDATE);
			//TODO - Hardcoded - Bcoz data not available for invoice in DB
			/*InvoiceVO invoiceVO=new InvoiceVO();
			invoiceVO.setInvoiceDt(11);
			invoiceVO.setInvoiceMonth(4);
			invoiceVO.setInvoiceYear(2018);*/
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling timeSheetDO.getTimeSheetDetails()", "Start");
			timeSheetDO.getTimeSheetDetails(timeSheetDO,systemDetailsDOList,invoiceVO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from timeSheetDO.getTimeSheetDetails()", "End");
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying timeSheetDO to timeSheetVO","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(timeSheetDO, timeSheetVO);
			
			if(null!=timeSheetDO.getTimeSheetDetailMap()) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting TimesheetDOMap to TimeSheetVOMap ","");
				HashMap<String, HashMap<Integer, List<TimeSheetDetailDO>>> timeSheetDetailVOMap = new HashMap<String, HashMap<Integer, List<TimeSheetDetailDO>>>();
				HashMap<String, HashMap<Integer, List<TimeSheetDetailDO>>> timeSheetDetailDOMap = timeSheetDO.getTimeSheetDetailMap();
				timeSheetDetailVOMap.putAll(timeSheetDetailDOMap);
				timeSheetVO.setTimeSheetDetailMap(timeSheetDetailVOMap);
			}
			
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME,METHOD_NAME, "getTimeSheetList exception - In TimeSheetHandler", e, "");
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		
		return timeSheetVO;
	}

	public String getSubSystemName(int subSytemId, List<SystemDetailsDO> systemDetailsDOList) {
		final String METHOD_NAME="getSubSystemName";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered getSubSystemName Handler method", "getSubSystemName - Start");
		
		try {
			for(SystemDetailsDO systemDetailsDO: systemDetailsDOList){
				for(SubSystemDO subSystemDO : systemDetailsDO.getSubsystemDetails()) {
					if (subSystemDO.getSubSystemID() == subSytemId) {
						return subSystemDO.getSubSystemName();
					}
				}
			}
		} catch (CustomException e) {
			e.printStackTrace();
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning from getSubSystemName Handler method", "getSubSystemName - END");
		return null;
	}
	
	public TimeSheetVO insertTimeSheet(TimeSheetVO timeSheetVO,HttpSession session) {
		final String METHOD_NAME="insertTimeSheet";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered insertTimeSheet Handler method", "insertTimeSheet - Start");
		
		TimeSheetDO timeSheetDO = new TimeSheetDO();
		try {
			
			boolean validation;
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Validating Timesheet Insertion Map", "");
			validation = validateTimeSheetInsertRequest(timeSheetVO.getTimeSheetInsertionMap());
			
			if(validation){
				
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching UserDO from session","");
				UserDO userDO=(UserDO)session.getAttribute(ICommonConstants.USER_DETAILS);
				/*timeSheetVO.setUserId(userDO.getUserId());
				
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying timeSheetVO to timeSheetDO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(timeSheetVO, timeSheetDO);*/
				
				InsertTimeSheetRequest insertTimeSheetRequest = timeSheetDO.populateInsertTimeSheetRequest(timeSheetVO, userDO);
				if(null==insertTimeSheetRequest || insertTimeSheetRequest.getTimesheetList().isEmpty()) {
					return timeSheetVO;
				}
				else {
					LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling timeSheetDO.deleteTimeSheetDetails()", "");
					timeSheetDO = timeSheetDO.insertTimeSheetDetails(insertTimeSheetRequest);
					LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from timeSheetDO.deleteTimeSheetDetails()", "");
					
					LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying timeSheetDO to timeSheetVO","Dozer Bean Copy");
					CommonUtility.copyBeanProperties(timeSheetDO, timeSheetVO);
					for (Map.Entry<String,String> entry : timeSheetVO.getResponseMap().entrySet()) 
					timeSheetVO.setInsertStatus(entry.getValue());
				}
			}
			else {
				timeSheetVO.setInsertStatus(ICommonConstants.EXCEEDING_24_HRS);
			}
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME,METHOD_NAME, "Timesheet Insert Exception - In handler", e, "");
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning from insertTimeSheet Handler method", "insertTimeSheet - End");
		return timeSheetVO;
	}

	private boolean validateTimeSheetInsertRequest(Map<Integer, Map<Integer, List<TimeSheetDetailVO>>> userInputMap) {
		
		final String METHOD_NAME="validateTimeSheetInsertRequest";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered validateTimeSheetInsertRequest Handler method", "Start");
		
		boolean validationFlag=true;
		
		Map<String, Integer> dateMap = new HashMap<String, Integer>();
		try {
			
			String workDate;
			for (Entry<Integer, Map<Integer, List<TimeSheetDetailVO>>> entry : userInputMap.entrySet()) {
			    for (Entry<Integer, List<TimeSheetDetailVO>> entry1 : entry.getValue().entrySet()) {
			    	for(TimeSheetDetailVO timeSheetDetailVO : entry1.getValue()){
			    		workDate = timeSheetDetailVO.getWorkDate();
			    		if(dateMap.containsKey(workDate)){
			    			dateMap.put(workDate, dateMap.get(workDate) + timeSheetDetailVO.getHoursWorked());
			    		}else{
			    			dateMap.put(workDate, timeSheetDetailVO.getHoursWorked());
			    		}
			    	}
			    }
			}
			
			for(Entry<String, Integer> entry: dateMap.entrySet()){
				if(entry.getValue()>24) {
	    			validationFlag=false;
	    		}
			}
		} catch (CustomException e) {
			e.printStackTrace();
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning from validateTimeSheetInsertRequest Handler method", "END");
		return validationFlag;
	}

	public TimeSheetVO deleteTimeSheet(TimeSheetVO timeSheetVO, HttpSession session) {
		final String METHOD_NAME = "deleteTimeSheet";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered timesheetHandler.deleteTimeSheet()","deleteTimeSheet -Start");

		if(null!=timeSheetVO.getResourceId()){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "setting the userId","");
			timeSheetVO.setUserId(timeSheetVO.getResourceId());
		}
		else{
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching UserDo and setting it to VO","");
			UserDO userDO=(UserDO) session.getAttribute(ICommonConstants.USER_DETAILS);
			timeSheetVO.setUserId(userDO.getUserId());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting token Id","");
		timeSheetVO.setTokenId(CommonUtility.getTokenId());
		
		TimeSheetDO timeSheetDO = new TimeSheetDO();
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying timeSheetVO to timeSheetDO","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(timeSheetVO, timeSheetDO);
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling timeSheetDO.deleteTimeSheetDetails()", "");
			timeSheetDO.deleteTimeSheetDetails(timeSheetDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from timeSheetDO.deleteTimeSheetDetails()", "");
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying timeSheetDO to timeSheetVO","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(timeSheetDO, timeSheetVO);
			
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME,METHOD_NAME, "Timesheet Delete Exception - In handler", e, "");
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning from timesheetHandler.deleteTimeSheet()","deleteTimeSheet -End");
		return timeSheetVO;
	}
	
	public ArrayList<String> getPerList(HttpSession session,TimeSheetVO timeSheetVO) throws CustomException {
		final String METHOD_NAME = "getPerList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside timesheetHandler.getPerList()","");
		
		//getting current roleDO of User
		UserDO userDO = null;
		RoleDO roleDO = null;
		if(null != session.getAttribute(ICommonConstants.USER_DETAILS)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching current roleDO from session","");
			userDO = (UserDO)session.getAttribute(ICommonConstants.USER_DETAILS);
			roleDO = userDO.getCurrentRoleDO();
		}
		else {
			throw new CustomException("", "Session Failure... Kindly Login Again");
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming the PerlistDO to fetch PerList", "");
		PerDO perDO = new PerDO();
		perDO.setPerNumber(timeSheetVO.getProjectName());
		perDO.setSystemId(timeSheetVO.getSystemId());
		perDO.setSubSystemId(timeSheetVO.getSubSystemId());
		PerListDO perListDO = new PerListDO();
		perListDO.setPer(perDO);
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling roleDO.getPerList()", "Start");
			roleDO.getPerList(perListDO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from roleDO.getPerList()", "End");
		} catch(CustomException e){
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Per List  Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "forming perLsit", "");
		ArrayList<String> perNumberList = new ArrayList<String>();
		if(null != perListDO) {
			List<PerDO> perDOList = perListDO.getPerList();
			for(PerDO per : perDOList){
				perNumberList.add(per.getPerNumber());
			}
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Return from timesheetHandler.getPerList()","");
		return perNumberList;
	}

}