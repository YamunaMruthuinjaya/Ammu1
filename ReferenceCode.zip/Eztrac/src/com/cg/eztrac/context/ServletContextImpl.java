package com.cg.eztrac.context;

import javax.servlet.ServletContext;

import org.springframework.stereotype.Component;
import org.springframework.web.context.ServletContextAware;

import com.cg.eztrac.common.LoggerManager;

@Component(value="servletContextImpl")
public class ServletContextImpl implements ServletContextAware {
	String className=ServletContextImpl.class.getSimpleName();
	private ServletContext servletContext;

	@Override
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public boolean addObjectToServletContext(String addAttribute, Object attribute) {
		servletContext.setAttribute(addAttribute, attribute);
		return true;
	}

	public Object getObjectFromServletContext(String getAttribute) {
		String methodName="getObjectFromServletContext";
		Object attribute = null;
		try {
			attribute = servletContext.getAttribute(getAttribute);
		} catch (Exception e) {
			LoggerManager.writeErrorLog(className,methodName,e.getMessage(), e,"exception while getting Object from application context");
			attribute = null;
		}	
		return attribute;
	}
}
