package com.cg.eztrac.vo;

import java.util.List;

import org.springframework.stereotype.Component;

@Component(value = "systemDetailsVO")
public class SystemDetailsVO {
	
	private int subAccountId;
	private int systemID;
	private String systemName;
	private List<SubSystemVO> subsystemDetails;
	private String systemStatus;
	public int getSubAccountId() {
		return subAccountId;
	}
	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}
	public int getSystemID() {
		return systemID;
	}
	public void setSystemID(int systemID) {
		this.systemID = systemID;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public List<SubSystemVO> getSubsystemDetails() {
		return subsystemDetails;
	}
	public void setSubsystemDetails(List<SubSystemVO> subsystemDetails) {
		this.subsystemDetails = subsystemDetails;
	}
	public String getSystemStatus() {
		return systemStatus;
	}
	public void setSystemStatus(String systemStatus) {
		this.systemStatus = systemStatus;
	}
	
}