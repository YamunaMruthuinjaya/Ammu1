package com.cg.eztrac.vo;

public class HomePageVO extends BaseVO {
	
	
	private String resultPage="";
	private String errorMsg="";
	private String field="";
	

	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getResultPage() {
		return resultPage;
	}
	public void setResultPage(String resultPage) {
		this.resultPage = resultPage;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	
	
}
