package com.cg.eztrac.vo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class PerChangeControlVO extends ChangeControlVO {
	
	private String perCCCancellationDateString;
	private Date perCCCancellationDate;
	private String perCCCompletionDateString;
	private Date perCCCompletionDate;
	private List<SystemDetailsVO> perCCteams;
	private List<SystemDetailsVO> perCCteamsInvolved;
	private String teamsInvolved;
	private Integer[] perCCTeamsInvolvedArray;
	private boolean perCCSendMailFlag;
	private boolean perCCOnsiteOnlyFlag;
	private boolean perCCMarkAllCCClosedFlag;
	private AttachmentVO perCCAttachment;
	private List<AttachmentVO> attachmentList;

	public String getPerCCCancellationDateString() {
		return perCCCancellationDateString;
	}
	public void setPerCCCancellationDateString(String perCCCancellationDateString) {
		this.perCCCancellationDateString = perCCCancellationDateString;
	}
	public Date getPerCCCancellationDate() {
		return perCCCancellationDate;
	}
	public void setPerCCCancellationDate(Date perCCCancellationDate) {
		this.perCCCancellationDate = perCCCancellationDate;
	}
	public String getPerCCCompletionDateString() {
		return perCCCompletionDateString;
	}
	public void setPerCCCompletionDateString(String perCCCompletionDateString) {
		this.perCCCompletionDateString = perCCCompletionDateString;
	}
	public Date getPerCCCompletionDate() {
		return perCCCompletionDate;
	}
	public void setPerCCCompletionDate(Date perCCCompletionDate) {
		this.perCCCompletionDate = perCCCompletionDate;
	}
	public List<SystemDetailsVO> getPerCCteams() {
		return perCCteams;
	}
	public void setPerCCteams(List<SystemDetailsVO> perCCteams) {
		this.perCCteams = perCCteams;
	}
	public List<SystemDetailsVO> getPerCCteamsInvolved() {
		return perCCteamsInvolved;
	}
	public void setPerCCteamsInvolved(List<SystemDetailsVO> perCCteamsInvolved) {
		this.perCCteamsInvolved = perCCteamsInvolved;
	}
	public String getTeamsInvolved() {
		return teamsInvolved;
	}
	public void setTeamsInvolved(String teamsInvolved) {
		this.teamsInvolved = teamsInvolved;
	}
	public Integer[] getPerCCTeamsInvolvedArray() {
		return perCCTeamsInvolvedArray;
	}
	public void setPerCCTeamsInvolvedArray(Integer[] perCCTeamsInvolvedArray) {
		this.perCCTeamsInvolvedArray = perCCTeamsInvolvedArray;
	}
	public boolean isPerCCSendMailFlag() {
		return perCCSendMailFlag;
	}
	public void setPerCCSendMailFlag(boolean perCCSendMailFlag) {
		this.perCCSendMailFlag = perCCSendMailFlag;
	}
	public boolean isPerCCOnsiteOnlyFlag() {
		return perCCOnsiteOnlyFlag;
	}
	public void setPerCCOnsiteOnlyFlag(boolean perCCOnsiteOnlyFlag) {
		this.perCCOnsiteOnlyFlag = perCCOnsiteOnlyFlag;
	}
	public boolean isPerCCMarkAllCCClosedFlag() {
		return perCCMarkAllCCClosedFlag;
	}
	public void setPerCCMarkAllCCClosedFlag(boolean perCCMarkAllCCClosedFlag) {
		this.perCCMarkAllCCClosedFlag = perCCMarkAllCCClosedFlag;
	}
	public AttachmentVO getPerCCAttachment() {
		return perCCAttachment;
	}
	public void setPerCCAttachment(AttachmentVO perCCAttachment) {
		this.perCCAttachment = perCCAttachment;
	}
	public List<AttachmentVO> getAttachmentList() {
		return attachmentList;
	}
	public void setAttachmentList(List<AttachmentVO> attachmentList) {
		this.attachmentList = attachmentList;
	}
	@Override
	public String toString() {
		return "PerChangeControlVO [perCCCancellationDateString=" + perCCCancellationDateString
				+ ", perCCCancellationDate=" + perCCCancellationDate + ", perCCCompletionDateString="
				+ perCCCompletionDateString + ", perCCCompletionDate=" + perCCCompletionDate + ", perCCteams="
				+ perCCteams + ", perCCteamsInvolved=" + perCCteamsInvolved + ", perCCTeamsInvolvedArray="
				+ Arrays.toString(perCCTeamsInvolvedArray) + ", perCCSendMailFlag=" + perCCSendMailFlag
				+ ", perCCOnsiteOnlyFlag=" + perCCOnsiteOnlyFlag + ", perCCMarkAllCCClosedFlag="
				+ perCCMarkAllCCClosedFlag + ", perCCAttachment=" + perCCAttachment + ", attachmentList="
				+ attachmentList + "]";
	}

}
