package com.cg.eztrac.vo;

import java.util.List;

public class RoleVO {
	private Integer id;
	private String rolename;
	private List<UserVO> user;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getRolename() {
		return rolename;
	}
	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
	public List<UserVO> getUser() {
		return user;
	}
	public void setUser(List<UserVO> user) {
		this.user = user;
	}
	@Override
	public String toString() {
		return "Role [id=" + id + ", rolename=" + rolename + ", user=" + user + "]";
	}
	
	public RoleVO() {
		System.out.println("Hi I am in Role Bean");
	}
}
