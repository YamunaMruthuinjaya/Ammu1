package com.cg.eztrac.vo;

public class EventsVO {
	private String setInvoiceDate;

	public String getSetInvoiceDate() {
		return setInvoiceDate;
	}

	public void setSetInvoiceDate(String setInvoiceDate) {
		this.setInvoiceDate = setInvoiceDate;
	}

}
