package com.cg.eztrac.vo;

public class PMDetailsVO {
	
	private static final String CLASS_NAME = PMDetailsVO.class.getSimpleName();
	
	private Integer userId;
	private String name;
	private String pmStatus;
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPmStatus() {
		return pmStatus;
	}
	public void setPmStatus(String pmStatus) {
		this.pmStatus = pmStatus;
	}
	@Override
	public String toString() {
		return "PMDetailsVO [userId=" + userId + ", name=" + name + ", pmStatus=" + pmStatus + "]";
	}
	
}
