package com.cg.eztrac.vo;

import java.util.List;

import org.springframework.stereotype.Component;

@Component(value="buildListVO")
public class BuildListVO extends EstimationListVO{
	
	private BuildVO build;
	private List<BuildVO> buildList;
	public BuildVO getBuild() {
		return build;
	}
	public void setBuild(BuildVO build) {
		this.build = build;
	}
	public List<BuildVO> getBuildList() {
		return buildList;
	}
	public void setBuildList(List<BuildVO> buildList) {
		this.buildList = buildList;
	}
	
	
	
}