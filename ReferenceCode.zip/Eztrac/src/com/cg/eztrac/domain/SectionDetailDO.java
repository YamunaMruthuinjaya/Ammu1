package com.cg.eztrac.domain;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.IRestServiceRequest;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.service.IServiceMandates;
import com.cg.eztrac.service.impl.OnLoadSectionServicesImpl;

public class SectionDetailDO implements IRestServiceRequest{
	String className=SectionDetailDO.class.getSimpleName();
	private String tokenId = "";
	private String channelId = "";
	private int subAccounId;
	private int sectionID;
	private String sectionName = "";
	private Integer sectionType ;
	private List<SubSectionDO> subSection = new ArrayList<SubSectionDO>();
	
	public int getSectionID() {
		return sectionID;
	}
	public void setSectionID(int sectionID) {
		this.sectionID = sectionID;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	
	
	public List<SubSectionDO> getSubSection() {
		return subSection;
	}
	public void setSubSection(List<SubSectionDO> subSection) {
		this.subSection = subSection;
	}
	public String getTokenId() {
		return tokenId;
	}
	public int getSubAccounId() {
		return subAccounId;
	}
	public void setSubAccounId(int subAccounId) {
		this.subAccounId = subAccounId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	
	public List<SectionDetailDO> callSectionDetailService(SectionDetailDO sectionDetailDO) throws CustomException {
		String methodName="callSectionDetailService";
		IServiceMandates sectionImpl=new OnLoadSectionServicesImpl();
		List<SectionDetailDO> sectionDetails =(List<SectionDetailDO>) sectionImpl.serviceProcessor(sectionDetailDO,null);
		return sectionDetails;
	}
	public Integer getSectionType() {
		return sectionType;
	}
	public void setSectionType(Integer sectionType) {
		this.sectionType = sectionType;
	}
	
/*	public List<SectionDetailDO> callSectionDetailService(SectionDetailDO sectionDetailDO) {
		String methodName="callSectionDetailService";
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"In sectionDetailDO",ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+ "Before populating the sectionRequest from DO");
		SectionDetailRequest sectionDetailRequest  = populateSectionRequestFromDO( sectionDetailDO );
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"In sectionDetailDO", ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+"Details are populated into sectionDetailRequest");
		OnLoadCommonService sectionDetailService = new OnLoadCommonServiceImpl();
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"In sectionDetailDO", ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+"Before calling the getAllSectionDetails() to get sectionDetailResponseList ");
		SectionsRes sectionDetailResponse = sectionDetailService.getAllSectionDetails(sectionDetailRequest);
		List<SectionDetail> sectionDetailResponseList = sectionDetailResponse.getSectionDetails();
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"In sectionDetailDO",ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+ " getAllSectionDetails() is called and  got sectionDetailResponseList");
		List<SectionDetailDO> sectionDetails = populateResponseToDO(sectionDetailResponseList);
		return sectionDetails;
	}*/
	
	
	
	
/*	*//** forming sectionDetailDO(response->DO)*//*
	private List<SectionDetailDO> populateResponseToDO(List<SectionDetail> sectionDetailResponseList) {
		String methodName="populateResponseToDO";
		List<SectionDetailDO> sectionDetails = new ArrayList<SectionDetailDO>(sectionDetailResponseList.size());
		try {
			SectionDetailDO sectionDetailDO = null;
			Gson gson = new Gson();
			for (int i=0;i<sectionDetailResponseList.size();i++){
				sectionDetailDO = new SectionDetailDO();
				String sectionDetailDOJson = gson.toJson( sectionDetailResponseList.get(i));
				sectionDetailDO = gson.fromJson(sectionDetailDOJson, SectionDetailDO.class);
				sectionDetails.add(sectionDetailDO);
			}
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"In sectionDetailDO", ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+"Setting SectionDetailDo from SectoinDetailResponse");
		} catch (Exception e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(className,methodName,e.getMessage(), e,"exception while populating the sectionDetailResponse to SectionDetailDO");
		}
		return sectionDetails;
	}
	
	*//** forming sectionDetailRequest(DO->request)*//*
	private SectionDetailRequest populateSectionRequestFromDO(SectionDetailDO sectionDetailDO) {
		
		String methodName="populateSectionRequestFromDO";
		SectionDetailRequest sectionDetailRequest = new SectionDetailRequest();
		sectionDetailRequest.setSubAccountId(sectionDetailDO.getSubAccounId());
		sectionDetailRequest.setTokenId(CommonUtility.getTokenId());
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"In sectionDetailDO", ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+"Setting SectionDetail Request from SectionDetailDO");
		return sectionDetailRequest;
	}*/
	
}
