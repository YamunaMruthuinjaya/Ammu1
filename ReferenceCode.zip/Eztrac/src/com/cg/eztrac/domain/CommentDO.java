package com.cg.eztrac.domain;

public class CommentDO {
	
	private String comment;
	private String commentBy;
	private String commentOnString;
	
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public String getCommentBy() {
		return commentBy;
	}
	public void setCommentBy(String commentBy) {
		this.commentBy = commentBy;
	}
	public String getCommentOnString() {
		return commentOnString;
	}
	public void setCommentOnString(String commentOnString) {
		this.commentOnString = commentOnString;
	}
	@Override
	public String toString() {
		return "CommentDO [comment=" + comment + ", commentBy=" + commentBy + ", commentOnString=" + commentOnString
				+ "]";
	}
	
}
