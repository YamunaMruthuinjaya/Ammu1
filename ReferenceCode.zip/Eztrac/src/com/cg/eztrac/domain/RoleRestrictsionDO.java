package com.cg.eztrac.domain;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.IRestServiceResponse;

public class RoleRestrictsionDO implements IRestServiceResponse{
	String className=RoleRestrictsionDO.class.getSimpleName();
	private int roleId;
	private String roleName;
	
	List<SubSectionDO> subSection = new ArrayList<SubSectionDO>();
	private String tokenId = "";
	private String responseCode = "";
	private String responseDescription = "";
	private String channelId;
	
	@Override
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	/**
	 * @return the responseCode
	 */
	public String getResponseCode() {
		return responseCode;
	}
	/**
	 * @param responseCode the responseCode to set
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	/**
	 * @return the responseDescription
	 */
	public String getResponseDescription() {
		return responseDescription;
	}
	/**
	 * @param responseDescription the responseDescription to set
	 */
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}

	public List<SubSectionDO> getSubSection() {
		return subSection;
	}
	public void setSubSection(List<SubSectionDO> subSection) {
		this.subSection = subSection;
	}
	
	@Override
	public String toString() {
		return "RoleRestrictsionDO [className=" + className + ", roleId=" + roleId + ", roleName=" + roleName
				+ ", subSection=" + subSection + ", tokenId=" + tokenId + ", responseCode=" + responseCode
				+ ", responseDescription=" + responseDescription + ", channelId=" + channelId + "]";
	}

}
