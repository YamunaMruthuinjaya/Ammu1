package com.cg.eztrac.domain;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.OnLoadCommonService;
import com.cg.eztrac.service.impl.OnLoadCommonServiceImpl;
import com.cg.eztrac.service.request.PMDetailsRequest;
import com.cg.eztrac.service.request.PMODetailsRequest;
import com.cg.eztrac.service.request.ResourceDetailsRequest;
import com.cg.eztrac.service.request.SystemDetailsRequest;
import com.cg.eztrac.service.response.PMDetailsResponse;
import com.cg.eztrac.service.response.PMODetailsResponse;
import com.cg.eztrac.service.response.PMResponse;
import com.cg.eztrac.service.response.ResourceDetailsResponse;
import com.cg.eztrac.service.response.ResourceResponse;
import com.cg.eztrac.service.response.SystemDetailsResponse;
import com.cg.eztrac.service.response.SystemRes;
import com.google.gson.Gson;

public class ResourceDetailsDO {

	String className = ResourceDetailsDO.class.getSimpleName();
	private Integer userId;
	private String name;
	private String resourceStatus;


	public List<ResourceDetailsDO> callResourceDetailService(ResourceDetailsDO resourceDetailsDO) {
		String methodName="callResourceDetailService";
		
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.ALL_RESOURCE_DETAILS_SERVICE_LOG_KEY+"In callResourceDetailService", "Before populating the resourceDetailsRequest from DO");
		ResourceDetailsRequest resourceDetailsRequest = populateResourceRequestFromDO(resourceDetailsDO);
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.ALL_RESOURCE_DETAILS_SERVICE_LOG_KEY+"In callResourceDetailService", "Details are populated into resourceDetailsRequest");
		
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.ALL_RESOURCE_DETAILS_SERVICE_LOG_KEY+"In callResourceDetailService", "Before calling the getResourceDetails() to get resourceDetailResponseList ");
		OnLoadCommonService onLoadCommonServcie = new OnLoadCommonServiceImpl();
		ResourceResponse resourceResponse = onLoadCommonServcie.getResourceDetails(resourceDetailsRequest);
		List<ResourceDetailsResponse> resourceDetailsListResponse = resourceResponse.getPm();
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.ALL_RESOURCE_DETAILS_SERVICE_LOG_KEY+"In callResourceDetailService", "getResourceDetails() is called and got resourceDetailServiceResponseList");
		List<ResourceDetailsDO> resourceDetailsDOList = populateResponseToDO(resourceDetailsListResponse);
		return resourceDetailsDOList;
	}
	
	

	private ResourceDetailsRequest populateResourceRequestFromDO(ResourceDetailsDO resourceDetailsDO) {
		String methodName = "populateResourceRequestFromDO";
		ResourceDetailsRequest resourceDetailsRequest = new ResourceDetailsRequest();
		resourceDetailsRequest.setSubAccountId(1);
		LoggerManager.writeInfoLog(className, methodName, ICommonConstants.ALL_RESOURCE_DETAILS_SERVICE_LOG_KEY + "In populateResourceRequestFromDO", "resourceDetailsRequest populated from DO");
		return resourceDetailsRequest;
	}
	
	

	private List<ResourceDetailsDO> populateResponseToDO(List<ResourceDetailsResponse> resourceDetailResponseList) {
		String methodName="populateResponseToDO";
		List<ResourceDetailsDO> resourceDetailsDOList = new ArrayList<ResourceDetailsDO>();
		
		try {
			ResourceDetailsDO resourceDetailsDO = null;
			Gson gson = new Gson();
			for (int i = 0; i < resourceDetailResponseList.size(); i++) {
				resourceDetailsDO = new ResourceDetailsDO();
				String resourceDetailDOJson = gson.toJson(resourceDetailResponseList.get(i));
				resourceDetailsDO = gson.fromJson(resourceDetailDOJson, ResourceDetailsDO.class);
				resourceDetailsDOList.add(resourceDetailsDO);
			}
			LoggerManager.writeInfoLog(className, methodName,"In populateResponseToDO", "Setting ResourceDetailsDO from ResourceDetailsResponse");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resourceDetailsDOList;
	}
	
	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getResourceStatus() {
		return resourceStatus;
	}

	public void setResourceStatus(String resourceStatus) {
		this.resourceStatus = resourceStatus;
	}

	
}