package com.cg.eztrac.domain;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.eztrac.service.domainobject.SystemDetailsDO;
import com.cg.eztrac.vo.AttachmentVO;

@Component(value="perChangeControlDO")
public class PerChangeControlDO extends ChangeControlDO {
	
	private String perCCCancellationDateString;
	private String perCCCompletionDateString;
	//private List<SystemDetailsVO> perCCteams;
	private List<SystemDetailsDO> perCCteamsInvolved;
	//private String[] perCCTeamsInvolvedArray;
	private boolean perCCSendMailFlag;
	private boolean perCCOnsiteOnlyFlag;
	private boolean perCCMarkAllCCClosedFlag;
	private AttachmentVO perCCAttachment;
	private List<AttachmentVO> attachmentList;
	public String getPerCCCancellationDateString() {
		return perCCCancellationDateString;
	}
	public void setPerCCCancellationDateString(String perCCCancellationDateString) {
		this.perCCCancellationDateString = perCCCancellationDateString;
	}
	public String getPerCCCompletionDateString() {
		return perCCCompletionDateString;
	}
	public void setPerCCCompletionDateString(String perCCCompletionDateString) {
		this.perCCCompletionDateString = perCCCompletionDateString;
	}
	/*public List<SystemDetailsVO> getPerCCteams() {
		return perCCteams;
	}
	public void setPerCCteams(List<SystemDetailsVO> perCCteams) {
		this.perCCteams = perCCteams;
	}*/
	public List<SystemDetailsDO> getPerCCteamsInvolved() {
		return perCCteamsInvolved;
	}
	public void setPerCCteamsInvolved(List<SystemDetailsDO> perCCteamsInvolved) {
		this.perCCteamsInvolved = perCCteamsInvolved;
	}
	/*public String[] getPerCCTeamsInvolvedArray() {
		return perCCTeamsInvolvedArray;
	}
	public void setPerCCTeamsInvolvedArray(String[] perCCTeamsInvolvedArray) {
		this.perCCTeamsInvolvedArray = perCCTeamsInvolvedArray;
	}*/
	public boolean isPerCCSendMailFlag() {
		return perCCSendMailFlag;
	}
	public void setPerCCSendMailFlag(boolean perCCSendMailFlag) {
		this.perCCSendMailFlag = perCCSendMailFlag;
	}
	public boolean isPerCCOnsiteOnlyFlag() {
		return perCCOnsiteOnlyFlag;
	}
	public void setPerCCOnsiteOnlyFlag(boolean perCCOnsiteOnlyFlag) {
		this.perCCOnsiteOnlyFlag = perCCOnsiteOnlyFlag;
	}
	public boolean isPerCCMarkAllCCClosedFlag() {
		return perCCMarkAllCCClosedFlag;
	}
	public void setPerCCMarkAllCCClosedFlag(boolean perCCMarkAllCCClosedFlag) {
		this.perCCMarkAllCCClosedFlag = perCCMarkAllCCClosedFlag;
	}
	public AttachmentVO getPerCCAttachment() {
		return perCCAttachment;
	}
	public void setPerCCAttachment(AttachmentVO perCCAttachment) {
		this.perCCAttachment = perCCAttachment;
	}
	public List<AttachmentVO> getAttachmentList() {
		return attachmentList;
	}
	public void setAttachmentList(List<AttachmentVO> attachmentList) {
		this.attachmentList = attachmentList;
	}
/*	@Override
	public String toString() {
		return "PerChangeControlDO [perCCCancellationDateString=" + perCCCancellationDateString
				+ ", perCCCompletionDateString=" + perCCCompletionDateString + ", perCCteams=" + perCCteams
				+ ", perCCteamsInvolved=" + perCCteamsInvolved + ", perCCTeamsInvolvedArray="
				+ Arrays.toString(perCCTeamsInvolvedArray) + ", perCCSendMailFlag=" + perCCSendMailFlag
				+ ", perCCOnsiteOnlyFlag=" + perCCOnsiteOnlyFlag + ", perCCMarkAllCCClosedFlag="
				+ perCCMarkAllCCClosedFlag + ", perCCAttachment=" + perCCAttachment + ", attachmentList="
				+ attachmentList + "]";
	}*/

}
