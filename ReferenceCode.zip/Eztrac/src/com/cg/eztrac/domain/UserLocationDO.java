package com.cg.eztrac.domain;

public class UserLocationDO {
	private int locationId;
	private String onsiteFlag;
	private String startDate;
	private String endDate;
	private String location;
	public int getLocationId() {
		return locationId;
	}
	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}
	public String getOnsiteFlag() {
		return onsiteFlag;
	}
	public void setOnsiteFlag(String onsiteFlag) {
		this.onsiteFlag = onsiteFlag;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	

}
