package com.cg.eztrac.domain;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.eztrac.service.impl.BuildServiceImpl;

@Component(value="buildDO")
public class BuildDO extends EstimationDO {
	
	@Autowired
	BuildServiceImpl buildServiceImpl;
	
	/*@Autowired
	BuildDetailsRequest buildDetailsRequest;*/
	/*
	@Autowired
	BuildDetailsResponse buildDetailsResponse;*/
	
/*	@Autowired
	BuildInsertRequest buildInsertRequest; 
	*/
	/*@Autowired
	BuildInsertResponse buildInsertResponse; */
	
	//General - Fields - Build Module
	private Integer buildId;
	private Integer currentBuildPhase;
	private String currentBuildPhaseName;
	private String perPhaseName;
	private Integer onsiteLeverage;
	private Integer onsiteTimesheetLeverage;
	private Double phaseCompletion;
	private String cancelDateString;
	private Integer[] assignedToArray;
	private String[] assignedToArrayName;
	private Boolean isAssigned;
	private List<ResourceDetailsDO> assignedResourcesList;
	private String comments;
	
	private BuildChangeControlDO buildChangeControl;
	private BuildLoeDO buildLoe;
	
	private List<BuildChangeControlDO> buildChangeControlList;
	
	
	public Integer getBuildId() {
		return buildId;
	}

	public void setBuildId(Integer buildId) {
		this.buildId = buildId;
	}

	public Integer getCurrentBuildPhase() {
		return currentBuildPhase;
	}

	public void setCurrentBuildPhase(Integer currentBuildPhase) {
		this.currentBuildPhase = currentBuildPhase;
	}

	public String getCurrentBuildPhaseName() {
		return currentBuildPhaseName;
	}

	public void setCurrentBuildPhaseName(String currentBuildPhaseName) {
		this.currentBuildPhaseName = currentBuildPhaseName;
	}

	public String getPerPhaseName() {
		return perPhaseName;
	}

	public void setPerPhaseName(String perPhaseName) {
		this.perPhaseName = perPhaseName;
	}

	public Integer getOnsiteLeverage() {
		return onsiteLeverage;
	}

	public void setOnsiteLeverage(Integer onsiteLeverage) {
		this.onsiteLeverage = onsiteLeverage;
	}

	public Integer getOnsiteTimesheetLeverage() {
		return onsiteTimesheetLeverage;
	}

	public void setOnsiteTimesheetLeverage(Integer onsiteTimesheetLeverage) {
		this.onsiteTimesheetLeverage = onsiteTimesheetLeverage;
	}

	public Double getPhaseCompletion() {
		return phaseCompletion;
	}

	public void setPhaseCompletion(Double phaseCompletion) {
		this.phaseCompletion = phaseCompletion;
	}

	public String getCancelDateString() {
		return cancelDateString;
	}

	public void setCancelDateString(String cancelDateString) {
		this.cancelDateString = cancelDateString;
	}

	public Integer[] getAssignedToArray() {
		return assignedToArray;
	}

	public void setAssignedToArray(Integer[] assignedToArray) {
		this.assignedToArray = assignedToArray;
	}

	public String[] getAssignedToArrayName() {
		return assignedToArrayName;
	}

	public void setAssignedToArrayName(String[] assignedToArrayName) {
		this.assignedToArrayName = assignedToArrayName;
	}

	public Boolean getIsAssigned() {
		return isAssigned;
	}

	public void setIsAssigned(Boolean isAssigned) {
		this.isAssigned = isAssigned;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public BuildChangeControlDO getBuildChangeControl() {
		return buildChangeControl;
	}

	public void setBuildChangeControl(BuildChangeControlDO buildChangeControl) {
		this.buildChangeControl = buildChangeControl;
	}

	public BuildLoeDO getBuildLoe() {
		return buildLoe;
	}

	public void setBuildLoe(BuildLoeDO buildLoe) {
		this.buildLoe = buildLoe;
	}

	public List<BuildChangeControlDO> getBuildChangeControlList() {
		return buildChangeControlList;
	}

	public void setBuildChangeControlList(List<BuildChangeControlDO> buildChangeControlList) {
		this.buildChangeControlList = buildChangeControlList;
	}

	public List<ResourceDetailsDO> getAssignedResourcesList() {
		return assignedResourcesList;
	}

	public void setAssignedResourcesList(List<ResourceDetailsDO> assignedResourcesList) {
		this.assignedResourcesList = assignedResourcesList;
	}


}
