package com.cg.eztrac.domain;

import java.util.Map;

import org.springframework.stereotype.Component;

@Component(value="estimationListDO")
public class EstimationListDO extends BaseDO{
	
	//Response Code and Description Map
	private Map<String,String> responseMap;

	public Map<String, String> getResponseMap() {
		return responseMap;
	}

	public void setResponseMap(Map<String, String> responseMap) {
		this.responseMap = responseMap;
	}

}

