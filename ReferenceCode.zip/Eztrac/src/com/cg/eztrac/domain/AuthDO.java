package com.cg.eztrac.domain;

public class AuthDO {

	boolean elligbleFlag = false;
	private Integer sectionId;
	private String sectionName;
	private Integer sectionType;

	private Integer subSectionId;
	private String subSectionName;
	private Integer subSectionType;

	private Integer roleId;
	private String isUrl;
	private String roleName;

	public AuthDO(Integer roleId, String roleName, Integer sectionId, String sectionName, Integer sectionType,
			Integer subSectionId, String subSectionName, Integer subSectionType, boolean elligbleFlag, String isUrl) {

		this.setRoleId(roleId);
		this.setRoleName(roleName);

		this.setSectionId(sectionId);
		this.setSectionName(sectionName);
		this.setSectionType(sectionType);

		this.setSubSectionId(subSectionId);
		this.setSubSectionName(subSectionName);
		this.setSubSectionType(subSectionType);

		this.setElligbleFlag(elligbleFlag);
		this.setIsUrl(isUrl);

	}

	public boolean isElligbleFlag() {
		return elligbleFlag;
	}

	public void setElligbleFlag(boolean elligbleFlag) {
		this.elligbleFlag = elligbleFlag;
	}

	public Integer getSectionId() {
		return sectionId;
	}

	public void setSectionId(Integer sectionId) {
		this.sectionId = sectionId;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getIsUrl() {
		return isUrl;
	}

	public void setIsUrl(String isUrl) {
		this.isUrl = isUrl;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Integer getSectionType() {
		return sectionType;
	}

	public void setSectionType(Integer sectionType) {
		this.sectionType = sectionType;
	}

	public Integer getSubSectionId() {
		return subSectionId;
	}

	public void setSubSectionId(Integer subSectionId) {
		this.subSectionId = subSectionId;
	}

	public String getSubSectionName() {
		return subSectionName;
	}

	public void setSubSectionName(String subSectionName) {
		this.subSectionName = subSectionName;
	}

	public Integer getSubSectionType() {
		return subSectionType;
	}

	public void setSubSectionType(Integer subSectionType) {
		this.subSectionType = subSectionType;
	}

}
