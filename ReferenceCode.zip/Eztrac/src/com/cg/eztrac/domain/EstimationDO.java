package com.cg.eztrac.domain;

import java.util.List;
import java.util.Map;

public class EstimationDO extends BaseDO{

	// General - Fields - Common for Per and Build Modules
	private Integer perId;
	private String perNumber;
	private String perDescription;
	private Integer currentPerPhase;
	private String currentPerPhaseName;
	private Integer projectHealth;
	private String projectHealthName;
	private Integer projectCoordinator;
	private String projectCoordinatorName;
	private Integer systemId;
	private String systemName; 
	private Integer subSystemId;
	private String subSystemName;
	private Integer subAccountId;

	private String createdBy;
	private String createdOnString;
	private String lastModifiedBy;
	private String lastModifiedOnString;
	
	private Integer userId;
	private String statusCode;

	private PhaseTimelinesDO phaseTimelines;
	private PurchaseOrderDO purchaseOrder;
	private String poNumbers;

	private AttachmentDO attachment;
	private CommentDO comment;
	private NotificationDO notification;

	private List<AttachmentDO> attachmentList;
	private List<CommentDO> commentList;
	private List<NotificationDO> notificationList;
	
	//Response Code and Description Map
	private Map<String,String> responseMap;

	
	public Integer getSubAccountId() {
		return subAccountId;
	}

	public void setSubAccountId(Integer subAccountId) {
		this.subAccountId = subAccountId;
	}

	public Integer getPerId() {
		return perId;
	}

	public void setPerId(Integer perId) {
		this.perId = perId;
	}

	public String getPerNumber() {
		return perNumber;
	}

	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}

	public String getPerDescription() {
		return perDescription;
	}

	public void setPerDescription(String perDescription) {
		this.perDescription = perDescription;
	}

	public Integer getCurrentPerPhase() {
		return currentPerPhase;
	}

	public void setCurrentPerPhase(Integer currentPerPhase) {
		this.currentPerPhase = currentPerPhase;
	}

	public String getCurrentPerPhaseName() {
		return currentPerPhaseName;
	}

	public void setCurrentPerPhaseName(String currentPerPhaseName) {
		this.currentPerPhaseName = currentPerPhaseName;
	}

	public Integer getProjectHealth() {
		return projectHealth;
	}

	public void setProjectHealth(Integer projectHealth) {
		this.projectHealth = projectHealth;
	}

	public String getProjectHealthName() {
		return projectHealthName;
	}

	public void setProjectHealthName(String projectHealthName) {
		this.projectHealthName = projectHealthName;
	}

	public Integer getProjectCoordinator() {
		return projectCoordinator;
	}

	public void setProjectCoordinator(Integer projectCoordinator) {
		this.projectCoordinator = projectCoordinator;
	}

	public String getProjectCoordinatorName() {
		return projectCoordinatorName;
	}

	public void setProjectCoordinatorName(String projectCoordinatorName) {
		this.projectCoordinatorName = projectCoordinatorName;
	}

	public Integer getSystemId() {
		return systemId;
	}

	public void setSystemId(Integer systemId) {
		this.systemId = systemId;
	}

	public String getSystemName() {
		return systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	public Integer getSubSystemId() {
		return subSystemId;
	}

	public void setSubSystemId(Integer subSystemId) {
		this.subSystemId = subSystemId;
	}

	public String getSubSystemName() {
		return subSystemName;
	}

	public void setSubSystemName(String subSystemName) {
		this.subSystemName = subSystemName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getCreatedOnString() {
		return createdOnString;
	}

	public void setCreatedOnString(String createdOnString) {
		this.createdOnString = createdOnString;
	}

	public String getLastModifiedOnString() {
		return lastModifiedOnString;
	}

	public void setLastModifiedOnString(String lastModifiedOnString) {
		this.lastModifiedOnString = lastModifiedOnString;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public PhaseTimelinesDO getPhaseTimelines() {
		return phaseTimelines;
	}

	public void setPhaseTimelines(PhaseTimelinesDO phaseTimelines) {
		this.phaseTimelines = phaseTimelines;
	}

	public PurchaseOrderDO getPurchaseOrder() {
		return purchaseOrder;
	}

	public void setPurchaseOrder(PurchaseOrderDO purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	public String getPoNumbers() {
		return poNumbers;
	}

	public void setPoNumbers(String poNumbers) {
		this.poNumbers = poNumbers;
	}

	public AttachmentDO getAttachment() {
		return attachment;
	}

	public void setAttachment(AttachmentDO attachment) {
		this.attachment = attachment;
	}

	public CommentDO getComment() {
		return comment;
	}

	public void setComment(CommentDO comment) {
		this.comment = comment;
	}

	public NotificationDO getNotification() {
		return notification;
	}

	public void setNotification(NotificationDO notification) {
		this.notification = notification;
	}

	public List<AttachmentDO> getAttachmentList() {
		return attachmentList;
	}

	public void setAttachmentList(List<AttachmentDO> attachmentList) {
		this.attachmentList = attachmentList;
	}

	public List<CommentDO> getCommentList() {
		return commentList;
	}

	public void setCommentList(List<CommentDO> commentList) {
		this.commentList = commentList;
	}

	public List<NotificationDO> getNotificationList() {
		return notificationList;
	}

	public void setNotificationList(List<NotificationDO> notificationList) {
		this.notificationList = notificationList;
	}

	public Map<String, String> getResponseMap() {
		return responseMap;
	}

	public void setResponseMap(Map<String, String> responseMap) {
		this.responseMap = responseMap;
	}

	@Override
	public String toString() {
		return "EstimationDO [perId=" + perId + ", perNumber=" + perNumber + ", perDescription=" + perDescription
				+ ", currentPerPhase=" + currentPerPhase + ", currentPerPhaseName=" + currentPerPhaseName
				+ ", projectHealth=" + projectHealth + ", projectHealthName=" + projectHealthName
				+ ", projectCoordinator=" + projectCoordinator + ", projectCoordinatorName=" + projectCoordinatorName
				+ ", systemId=" + systemId + ", systemName=" + systemName + ", subSystemId=" + subSystemId
				+ ", subSystemName=" + subSystemName + ", subAccountId=" + subAccountId + ", createdBy=" + createdBy
				+ ", createdOnString=" + createdOnString + ", lastModifiedBy=" + lastModifiedBy
				+ ", lastModifiedOnString=" + lastModifiedOnString + ", userId=" + userId + ", statusCode=" + statusCode
				+ ", phaseTimelines=" + phaseTimelines + ", purchaseOrder=" + purchaseOrder + ", attachment="
				+ attachment + ", comment=" + comment + ", notification=" + notification + ", attachmentList="
				+ attachmentList + ", commentList=" + commentList + ", notificationList=" + notificationList
				+ ", responseMap=" + responseMap + "]";
	}

}
