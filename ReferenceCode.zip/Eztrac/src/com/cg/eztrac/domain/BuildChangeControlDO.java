package com.cg.eztrac.domain;

import java.util.Date;

public class BuildChangeControlDO extends ChangeControlDO {

	private int buildCCId;
	private Integer buildId;
	private String buildCCDescription;
	private String buildCCComments;
	private float buildCCReqLoe;
	private float buildCCDesignLoe;
	private float buildCCConLoe;
	private float buildCCTestingLoe;
	private float buildCCReleaseLoe;
	private Date buildCCEstimationDate;
	private String buildCCEstimationDateString;
	private Integer buildPhaseIdWhenAdded;
	private String buildPhaseNameWhenAdded;

	public int getBuildCCId() {
		return buildCCId;
	}

	public void setBuildCCId(int buildCCId) {
		this.buildCCId = buildCCId;
	}

	public String getBuildCCDescription() {
		return buildCCDescription;
	}

	public void setBuildCCDescription(String buildCCDescription) {
		this.buildCCDescription = buildCCDescription;
	}

	public String getBuildCCComments() {
		return buildCCComments;
	}

	public void setBuildCCComments(String buildCCComments) {
		this.buildCCComments = buildCCComments;
	}

	public Date getBuildCCEstimationDate() {
		return buildCCEstimationDate;
	}

	public void setBuildCCEstimationDate(Date buildCCEstimationDate) {
		this.buildCCEstimationDate = buildCCEstimationDate;
	}

	public float getBuildCCReqLoe() {
		return buildCCReqLoe;
	}

	public void setBuildCCReqLoe(float buildCCReqLoe) {
		this.buildCCReqLoe = buildCCReqLoe;
	}

	public float getBuildCCDesignLoe() {
		return buildCCDesignLoe;
	}

	public void setBuildCCDesignLoe(float buildCCDesignLoe) {
		this.buildCCDesignLoe = buildCCDesignLoe;
	}

	public float getBuildCCConLoe() {
		return buildCCConLoe;
	}

	public void setBuildCCConLoe(float buildCCConLoe) {
		this.buildCCConLoe = buildCCConLoe;
	}

	public float getBuildCCTestingLoe() {
		return buildCCTestingLoe;
	}

	public void setBuildCCTestingLoe(float buildCCTestingLoe) {
		this.buildCCTestingLoe = buildCCTestingLoe;
	}

	public float getBuildCCReleaseLoe() {
		return buildCCReleaseLoe;
	}

	public void setBuildCCReleaseLoe(float buildCCReleaseLoe) {
		this.buildCCReleaseLoe = buildCCReleaseLoe;
	}

	@Override
	public String toString() {
		return "BuildChangeControlDO [buildCCId=" + buildCCId + ", buildCCDescription=" + buildCCDescription
				+ ", buildCCComments=" + buildCCComments + ", buildCCReqLoe=" + buildCCReqLoe + ", buildCCDesignLoe="
				+ buildCCDesignLoe + ", buildCCConLoe=" + buildCCConLoe + ", buildCCTestingLoe=" + buildCCTestingLoe
				+ ", buildCCReleaseLoe=" + buildCCReleaseLoe + ", buildCCEstimationDate=" + buildCCEstimationDate + "]";
	}

	public String getBuildCCEstimationDateString() {
		return buildCCEstimationDateString;
	}

	public void setBuildCCEstimationDateString(String buildCCEstimationDateString) {
		this.buildCCEstimationDateString = buildCCEstimationDateString;
	}

	public Integer getBuildId() {
		return buildId;
	}

	public void setBuildId(Integer buildId) {
		this.buildId = buildId;
	}

	public Integer getBuildPhaseIdWhenAdded() {
		return buildPhaseIdWhenAdded;
	}

	public void setBuildPhaseIdWhenAdded(Integer buildPhaseIdWhenAdded) {
		this.buildPhaseIdWhenAdded = buildPhaseIdWhenAdded;
	}

	public String getBuildPhaseNameWhenAdded() {
		return buildPhaseNameWhenAdded;
	}

	public void setBuildPhaseNameWhenAdded(String buildPhaseNameWhenAdded) {
		this.buildPhaseNameWhenAdded = buildPhaseNameWhenAdded;
	}

}
