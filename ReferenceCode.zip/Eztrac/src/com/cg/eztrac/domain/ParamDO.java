package com.cg.eztrac.domain;

public class ParamDO {
	
	private static final String CLASS_NAME = ParamDO.class.getSimpleName();
	
	private Integer paramvalueID;
	private String paramName;
	private String paramValue;
	public Integer getParamvalueID() {
		return paramvalueID;
	}
	public void setParamvalueID(Integer paramvalueID) {
		this.paramvalueID = paramvalueID;
	}
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getParamValue() {
		return paramValue;
	}
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	
	@Override
	public String toString() {
		return "ParamDO [paramvalueID=" + paramvalueID + ", paramName=" + paramName + ", paramValue=" + paramValue
				+ "]";
	}
	
}
