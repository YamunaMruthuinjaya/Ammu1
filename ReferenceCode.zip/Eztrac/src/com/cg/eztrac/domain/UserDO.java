package com.cg.eztrac.domain;

import java.util.List;

import com.cg.eztrac.common.UserStatus;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.service.IServiceMandates;
import com.cg.eztrac.service.impl.SignInImpl;


public class UserDO extends BaseDO {
	String className=UserDO.class.getSimpleName();
	private MenuDO menuDO = new MenuDO();
	
	private boolean success = false;
	private boolean invalidUsername = false;
	private boolean invalidPassword = false;
	private String username;
	private String password;
	private String eventDate;
	private String emailId;
	private List<UserLocationDO> userlocations;
	private String employeeCode;
	private String unitAssigned;
	private String gdcName;
	private String accountName;
	private String subAccountName;
	private String sbu;
	private int userId;
	private String clientReportingFlag;
	private Integer clientSsoId;
	private String inductionFlag;
	private String telOfficeNum;
	private String telMobileNum;
	private int subAccountId;
	private List<RoleDO> roles;
	private UserStatus status;
	private HomePageDataDO homePageDataDO;
	private RoleDO currentRoleDO;
	private String currentRoleId;
	
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public boolean isInvalidUsername() {
		return invalidUsername;
	}
	public void setInvalidUsername(boolean invalidUsername) {
		this.invalidUsername = invalidUsername;
	}
	public boolean isInvalidPassword() {
		return invalidPassword;
	}
	public void setInvalidPassword(boolean invalidPassword) {
		this.invalidPassword = invalidPassword;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	

	
	public MenuDO getMenuDO() {
		return menuDO;
	}
	public void setMenuDO(MenuDO menuDO) {
		this.menuDO = menuDO;
	}

	public RoleDO getCurrentRoleDO() {
		return currentRoleDO;
	}
	public void setCurrentRoleDO(RoleDO currentRoleDO) {
		this.currentRoleDO = currentRoleDO;
	}
	public HomePageDataDO getHomePageDataDO() {
		return homePageDataDO;
	}
	public void setHomePageDataDO(HomePageDataDO homePageDataDO) {
		this.homePageDataDO = homePageDataDO;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getUnitAssigned() {
		return unitAssigned;
	}
	public void setUnitAssigned(String unitAssigned) {
		this.unitAssigned = unitAssigned;
	}
	public String getGdcName() {
		return gdcName;
	}
	public void setGdcName(String gdcName) {
		this.gdcName = gdcName;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getSubAccountName() {
		return subAccountName;
	}
	public void setSubAccountName(String subAccountName) {
		this.subAccountName = subAccountName;
	}
	public String getSbu() {
		return sbu;
	}
	public void setSbu(String sbu) {
		this.sbu = sbu;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getClientReportingFlag() {
		return clientReportingFlag;
	}
	public void setClientReportingFlag(String clientReportingFlag) {
		this.clientReportingFlag = clientReportingFlag;
	}
	public Integer getClientSsoId() {
		return clientSsoId;
	}
	public void setClientSsoId(Integer clientSsoId) {
		this.clientSsoId = clientSsoId;
	}
	public String getInductionFlag() {
		return inductionFlag;
	}
	public void setInductionFlag(String inductionFlag) {
		this.inductionFlag = inductionFlag;
	}
	public String getTelOfficeNum() {
		return telOfficeNum;
	}
	public void setTelOfficeNum(String telOfficeNum) {
		this.telOfficeNum = telOfficeNum;
	}
	public String getTelMobileNum() {
		return telMobileNum;
	}
	public void setTelMobileNum(String telMobileNum) {
		this.telMobileNum = telMobileNum;
	}
	public int getSubAccountId() {
		return subAccountId;
	}
	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}
	public List<RoleDO> getRoles() {
		return roles;
	}
	public void setRoles(List<RoleDO> roles) {
		this.roles = roles;
	}
	public UserStatus getStatus() {
		return status;
	}
	public void setStatus(UserStatus status) {
		this.status = status;
	}

	
	public String getCurrentRoleId() {
		return currentRoleId;
	}
	public void setCurrentRoleId(String currentRoleId) {
		this.currentRoleId = currentRoleId;
	}
	public void authenticateUser() throws CustomException {
		IServiceMandates signInImpl=new SignInImpl();
		signInImpl.serviceProcessor(this,null);
	}
	public List<UserLocationDO> getUserlocations() {
		return userlocations;
	}
	public void setUserlocations(List<UserLocationDO> userlocations) {
		this.userlocations = userlocations;
	}


}
