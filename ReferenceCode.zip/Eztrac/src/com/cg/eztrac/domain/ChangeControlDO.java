package com.cg.eztrac.domain;

import org.springframework.stereotype.Component;

@Component(value="changeControlDO")
public class ChangeControlDO {
	
	private int ccId;
	private String ccNumber;
	private String ccCategoryName;
	private Integer ccCategoryId; 
	private String ccPhase;
	private Integer ccPhaseId;
	private String perPhase;
	private Integer perPhaseId;
	private String ccStartDateString;
	private String ccEndDateString;
	private String ccDescription;
	private String ccCreatedBy;
	private String ccCreatedOnString;
	private String ccLastModifiedBy;
	private String ccLastModifiedOnString;
	private Integer userId;
	
	public int getCcId() {
		return ccId;
	}
	public void setCcId(int ccId) {
		this.ccId = ccId;
	}
	public String getCcNumber() {
		return ccNumber;
	}
	public void setCcNumber(String ccNumber) {
		this.ccNumber = ccNumber;
	}
	public String getCcCategoryName() {
		return ccCategoryName;
	}
	public void setCcCategoryName(String ccCategoryName) {
		this.ccCategoryName = ccCategoryName;
	}
	public Integer getCcCategoryId() {
		return ccCategoryId;
	}
	public void setCcCategoryId(Integer ccCategoryId) {
		this.ccCategoryId = ccCategoryId;
	}
	public String getCcPhase() {
		return ccPhase;
	}
	public void setCcPhase(String ccPhase) {
		this.ccPhase = ccPhase;
	}
	public Integer getCcPhaseId() {
		return ccPhaseId;
	}
	public void setCcPhaseId(Integer ccPhaseId) {
		this.ccPhaseId = ccPhaseId;
	}
	public String getPerPhase() {
		return perPhase;
	}
	public void setPerPhase(String perPhase) {
		this.perPhase = perPhase;
	}
	public Integer getPerPhaseId() {
		return perPhaseId;
	}
	public void setPerPhaseId(Integer perPhaseId) {
		this.perPhaseId = perPhaseId;
	}
	public String getCcStartDateString() {
		return ccStartDateString;
	}
	public void setCcStartDateString(String ccStartDateString) {
		this.ccStartDateString = ccStartDateString;
	}
	public String getCcEndDateString() {
		return ccEndDateString;
	}
	public void setCcEndDateString(String ccEndDateString) {
		this.ccEndDateString = ccEndDateString;
	}
	public String getCcDescription() {
		return ccDescription;
	}
	public void setCcDescription(String ccDescription) {
		this.ccDescription = ccDescription;
	}
	public String getCcCreatedBy() {
		return ccCreatedBy;
	}
	public void setCcCreatedBy(String ccCreatedBy) {
		this.ccCreatedBy = ccCreatedBy;
	}
	public String getCcCreatedOnString() {
		return ccCreatedOnString;
	}
	public void setCcCreatedOnString(String ccCreatedOnString) {
		this.ccCreatedOnString = ccCreatedOnString;
	}
	public String getCcLastModifiedBy() {
		return ccLastModifiedBy;
	}
	public void setCcLastModifiedBy(String ccLastModifiedBy) {
		this.ccLastModifiedBy = ccLastModifiedBy;
	}
	public String getCcLastModifiedOnString() {
		return ccLastModifiedOnString;
	}
	public void setCcLastModifiedOnString(String ccLastModifiedOnString) {
		this.ccLastModifiedOnString = ccLastModifiedOnString;
	}
	@Override
	public String toString() {
		return "ChangeControlDO [ccId=" + ccId + ", ccNumber=" + ccNumber + ", ccCategoryName=" + ccCategoryName
				+ ", ccCategoryId=" + ccCategoryId + ", ccPhase=" + ccPhase + ", perPhase=" + perPhase + ", perPhaseId="
				+ perPhaseId + ", ccStartDateString=" + ccStartDateString + ", ccEndDateString=" + ccEndDateString
				+ ", ccDescription=" + ccDescription + ", ccCreatedBy=" + ccCreatedBy + ", ccCreatedOnString="
				+ ccCreatedOnString + ", ccLastModifiedBy=" + ccLastModifiedBy + ", ccLastModifiedOnString="
				+ ccLastModifiedOnString + "]";
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
}
