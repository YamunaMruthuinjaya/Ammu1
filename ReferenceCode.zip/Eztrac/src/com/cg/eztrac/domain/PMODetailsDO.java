package com.cg.eztrac.domain;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.OnLoadCommonService;
import com.cg.eztrac.service.impl.OnLoadCommonServiceImpl;
import com.cg.eztrac.service.request.PMODetailsRequest;
import com.cg.eztrac.service.request.SystemDetailsRequest;
import com.cg.eztrac.service.response.PMODetailsResponse;
import com.cg.eztrac.service.response.PMOResponse;
import com.cg.eztrac.service.response.ResourceResponse;
import com.cg.eztrac.service.response.SystemDetailsResponse;
import com.cg.eztrac.service.response.SystemRes;
import com.google.gson.Gson;

public class PMODetailsDO {

	String className = PMODetailsDO.class.getSimpleName();
	private Integer userId;
	private String name;
	
	public List<PMODetailsDO> callPMODetailService(PMODetailsDO pmoDetailsDO) {
		
		String methodName="callPMODetailService";
		
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.PMO_DETAILS_SERVICE_LOG_KEY+"In callPMODetailService", "Before populating the pmoDetailsRequest from DO");
		PMODetailsRequest pmoDetailsRequest = populatePMORequestFromDO(pmoDetailsDO);
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.PMO_DETAILS_SERVICE_LOG_KEY+"In callPMODetailService", "Details are populated into pmoDetailsRequest");
		
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.PMO_DETAILS_SERVICE_LOG_KEY+"In callPMODetailService", "Before calling the getPMODetails() to get pmoDetailResponseList ");
		OnLoadCommonService onLoadCommonServcie = new OnLoadCommonServiceImpl();
		PMOResponse pmoResponse = onLoadCommonServcie.getPMODetails(pmoDetailsRequest);
		List<PMODetailsResponse> pmoDetailsListResponse = pmoResponse.getPm();
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.PMO_DETAILS_SERVICE_LOG_KEY+"In callPMODetailService", "getPMODetails() is called and got pmoDetailServiceResponseList");
		List<PMODetailsDO> pmoDetailsDOList = populateResponseToDO(pmoDetailsListResponse);
		return pmoDetailsDOList;
	}
	private PMODetailsRequest populatePMORequestFromDO(PMODetailsDO pmoDetailsDO) {
		String methodName = "populatePMORequestFromDO";
		PMODetailsRequest pmoDetailsRequest = new PMODetailsRequest();
		pmoDetailsRequest.setSubAccountId(1);
		LoggerManager.writeInfoLog(className, methodName, ICommonConstants.PMO_DETAILS_SERVICE_LOG_KEY + "In populatePMORequestFromDO", "pmoDetailsRequest populated from DO");
		
		return pmoDetailsRequest;
	}

	private List<PMODetailsDO> populateResponseToDO(List<PMODetailsResponse> pmoDetailResponseList) {
		String methodName="populateResponseToDO";
		List<PMODetailsDO> pmoDetailsDOList = new ArrayList<PMODetailsDO>();
		
		try {
			PMODetailsDO pmoDetailsDO = null;
			Gson gson = new Gson();
			for (int i = 0; i < pmoDetailResponseList.size(); i++) {
				pmoDetailsDO = new PMODetailsDO();
				String pmoDetailDOJson = gson.toJson(pmoDetailResponseList.get(i));
				pmoDetailsDO = gson.fromJson(pmoDetailDOJson, PMODetailsDO.class);
				pmoDetailsDOList.add(pmoDetailsDO);
			}
			LoggerManager.writeInfoLog(className, methodName,"In populateResponseToDO", "Setting PMODetailsDO from pmoDetailsResponse");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pmoDetailsDOList;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


}