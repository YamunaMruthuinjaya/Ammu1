package com.cg.eztrac.domain;

import java.util.List;

import org.springframework.stereotype.Component;

@Component(value="buildListDO")
public class BuildListDO extends EstimationListDO{
	
	private BuildDO build;
	private List<BuildDO> buildList;
	
	public BuildDO getBuild() {
		return build;
	}
	public void setBuild(BuildDO build) {
		this.build = build;
	}
	public List<BuildDO> getBuildList() {
		return buildList;
	}
	public void setBuildList(List<BuildDO> buildList) {
		this.buildList = buildList;
	}
	
}