package com.cg.eztrac.domain;

import java.util.HashMap;
import java.util.Map;

public class MenuDO {
	private Integer roleId;
	private String roleName = "";
	private String customizeJsonMap = "";
	private Map<Integer,String> switchRoles=new HashMap<Integer,String>();
	

	public Map<Integer, String> getSwitchRoles() {
		return switchRoles;
	}

	public void setSwitchRoles(Map<Integer, String> switchRoles) {
		this.switchRoles = switchRoles;
	}

	public String getCustomizeJsonMap() {
		return customizeJsonMap;
	}

	public void setCustomizeJsonMap(String customizeJsonMap) {
		this.customizeJsonMap = customizeJsonMap;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
}
