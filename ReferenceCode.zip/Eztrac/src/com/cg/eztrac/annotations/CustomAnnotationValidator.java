package com.cg.eztrac.annotations;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CustomAnnotationValidator implements ConstraintValidator<YourAnnotation, String>{

	@Override
	public void initialize(YourAnnotation arg0) {
		
	}

	@Override
	public boolean isValid(String eId, ConstraintValidatorContext arg1) {
		if(eId.matches("[0-9]{1,5}_FS")){
			return true;
		}
		else
		{
			return false;
		}
	}


}
