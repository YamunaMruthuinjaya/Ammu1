package com.cg.eztrac.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.handler.BuildHandler;
import com.cg.eztrac.validator.BuildValidator;
import com.cg.eztrac.vo.BuildListVO;
import com.cg.eztrac.vo.BuildVO;
import com.cg.eztrac.vo.ResourceDetailsVO;
import com.cg.eztrac.vo.SubSystemVO;
import com.cg.eztrac.vo.SystemDetailsVO;
import com.google.gson.Gson;


@Controller
@PropertySource("classpath:appurlcontroller.properties")
public class BuildController {
	
	private static final String CLASS_NAME = "BuildController";
	
	@Autowired
	BuildHandler buildHandler;
	
	@Autowired
	HttpSession httpSession;
	
	@RequestMapping(value = "${eztrack.postlogin.build.new.url}", method = RequestMethod.POST)
	public ModelAndView buildNew() throws CustomException {
		final String METHOD_NAME = "buildNew";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Build New Controller Method", "Build New Start");

		//TODO - clearing the session attribute
		if(null!=((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Clearing Build Session", "Start");
			((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO().setBuildDO(null);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Clearing Build Session", "End");
		}
		
		BuildVO buildVO = new BuildVO();

		// Role Restriction Matrix
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting RoleRestriction Matrix", "");
		buildVO.setRoleRestrictionMatrixPattern(ICommonConstants.BUILD_NEW_RESTRICTION_PATTERN);
		
		//TODO - PerNumber Dropdown Population
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Populating Pernumber Dropdown", "");
		Map<Integer,String> perNumbersMap = new HashMap<Integer,String>();
		try {
			perNumbersMap = buildHandler.getPerList(httpSession);
			if(null!=perNumbersMap) {
				buildVO.setPerNumbersMap(perNumbersMap);
			}
		} catch(CustomException e) {
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		//TODO - assignedTo Picklist population
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "AssignedTo Picklist population", "");
		List<ResourceDetailsVO> resourcesList = new ArrayList<ResourceDetailsVO>();
		resourcesList = buildVO.getResourceDetailsDropdown();
		buildVO.setResourcesList(resourcesList);
		
		//TODO - Setting userDetails
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting userDetails", "");
		buildVO.setCurrentRoleId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getRoleId());
		buildVO.setEmailId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getEmailId());
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model & View Object", "Build New End");
		ModelAndView mav = new ModelAndView("build");
		mav.addObject("buildVO", buildVO);
		return mav;
	}
	
	@RequestMapping(value =  "${eztrack.postlogin.build.ajaxInsert.url}", method=RequestMethod.POST)
    public @ResponseBody String  ajaxInsert(@RequestBody BuildVO buildVOUI, BindingResult result ) {
		String METHOD_NAME = "ajaxInsert";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Build Insert Ajax Controller Method", "Build Insert-Ajax Start");
		
		BuildValidator buildValidator = new BuildValidator();
		
		if(null!=buildVOUI) {
			
			//TODO - Forming AssignedToArray - from the string received from UI
			if(null!=buildVOUI.getAssignedTo() && !buildVOUI.getAssignedTo().equals("")) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming AssignedToArray from UI input", "Start");
				String[] assignedToString= buildVOUI.getAssignedTo().split(",");
				Integer[] assignedToArray = ArrayUtils.toObject(Arrays.stream(assignedToString).mapToInt(Integer::parseInt).toArray());
				buildVOUI.setAssignedToArray(assignedToArray);
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming AssignedToArray from UI input", "End");
			}
			
			//TODO - hardcoding notification type - Has to be fetched from common services
			if(null!=buildVOUI.getNotification()) {
				buildVOUI.getNotification().setNotifyTypeId(1);
			}
		  
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling BuildValidator", "BuildValidator");
				buildValidator.validate(buildVOUI, result);
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from BuildValidator", "BuildValidator");
			}
			catch (CustomException e) {
				// TODO: handle exception
				LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Exception occured in BuildValidator", e, "");
				System.out.println("Server Side Validator Exception");
				e.printStackTrace();
			}
		
			if(result.hasErrors())
			{
				//TODO - To be handled
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Server side error occured during Build Ajax Insert", "");
				return "error";
			}
			else {
				
				//TODO - forming the Assigned to list for insertion
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Assigned to list for insertion", "Start");
				List<ResourceDetailsVO> assignedResourcesList1 = new ArrayList<ResourceDetailsVO>();
				assignedResourcesList1 = buildHandler.constructAssignedToList(buildVOUI.getAssignedToArray(),httpSession);
				buildVOUI.setAssignedResourcesList(assignedResourcesList1);
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Assigned to list for insertion", "End");
				
				try {
					LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling buildHandler.insertBuildDetails()", "");
					buildHandler.insertBuildDetails(buildVOUI,httpSession);
					LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from buildHandler.insertBuildDetails()", "");
				}
				catch (CustomException e) {
					System.out.println("BuildController - Insert Build Catch Block");
					e.printStackTrace();
					LoggerManager.writeErrorLog(CLASS_NAME,METHOD_NAME, "BuildInsertResponse Exception", e, "Redirecting to custom exception");
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
		  	}
		}
		   
	   //Building JSON Object from the response
	   LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Building JSON Object from the Build Insert Response", "");
	   String json_n = new Gson().toJson(buildVOUI);
		
	   LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning back the Build Ajax Response", "Build Insert-Ajax End");  
	   return json_n;
    }

	
	@RequestMapping(value = "${eztrack.postlogin.build.submit.url}", method=RequestMethod.POST)
	public ModelAndView buildSubmit(ModelAndView mv,@ModelAttribute("buildVO") @Valid BuildVO buildVO,BindingResult result ) throws CustomException{
		final String METHOD_NAME = "buildSubmit";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Build Insert Controller Method", "Build Insert - Start");
		
		BuildValidator buildValidator = new BuildValidator();
		ModelAndView mav = new ModelAndView("build");
		
		//TODO - Forming AssignedToArray - from the string recieved frm UI
		 if(null!=buildVO.getAssignedTo() && !buildVO.getAssignedTo().equals("")) {
			 LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming AssignedToArray from UI input", "Start");
			 String[] assignedToString= buildVO.getAssignedTo().split(",");
			 Integer[] assignedToArray = ArrayUtils.toObject(Arrays.stream(assignedToString).mapToInt(Integer::parseInt).toArray());
      	  	 buildVO.setAssignedToArray(assignedToArray);
      	  	LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming AssignedToArray from UI input", "End");
		 }
		 
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling BuildValidator", "BuildValidator");
			buildValidator.validate(buildVO, result);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from BuildValidator", "BuildValidator");
		}
		catch (CustomException e) {
			// TODO: handle exception
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Exception occured in BuildValidator", e, "");
			System.out.println("Server Side Validator Exception");
			e.printStackTrace();
		}
		
		if(result.hasErrors())
		{
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Server side error occured", "");
			return new ModelAndView("build");
		}
		else
		{
			//TODO - forming the Assigned to list for insertion
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Assigned to notify list for insertion", "Start");
  			List<ResourceDetailsVO> assignedResourcesList1 = new ArrayList<ResourceDetailsVO>();
  			assignedResourcesList1 = buildHandler.constructAssignedToList(buildVO.getAssignedToArray(),httpSession);
  			buildVO.setAssignedResourcesList(assignedResourcesList1);
  			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Assigned to notify list for insertion", "End");
  			
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling buildHandler.insertBuildDetails()", "");
				buildHandler.insertBuildDetails(buildVO,httpSession);
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from buildHandler.insertBuildDetails()", "");
			}
			catch (CustomException e) {
				System.out.println("BuildController - Insert Build Catch Block");
				e.printStackTrace();
				LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildInsertResponse Exception", e, "Redirecting to custom exception");
				throw new CustomException(e.getErrCode(),e.getErrMsg());
			}
			
			//TODO - Role restriction matrix
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting RoleRestriction Matrix", "");
			if(null!=buildVO.getStatusCode()) {
				if(buildVO.getStatusCode().equals("S")){
					buildVO.setRoleRestrictionMatrixPattern(ICommonConstants.BUILD_NEW_RESTRICTION_PATTERN);
				}
				else if (buildVO.getStatusCode().equals("A")) {
					buildVO.setRoleRestrictionMatrixPattern(ICommonConstants.BUILD_EDIT_RESTRICTION_PATTERN);
				}
			}
			
			//TODO - PerNumber DropDown Population
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Populating Pernumber Dropdown", "");
			Map<Integer,String> perNumbersMap = new HashMap<Integer,String>();
			try {
				perNumbersMap = buildHandler.getPerList(httpSession);
				if(null!=perNumbersMap) {
					buildVO.setPerNumbersMap(perNumbersMap);
				}
			} catch(CustomException e) {
				throw new CustomException(e.getErrCode(),e.getErrMsg());
			}
			
			
			//TODO -assignedTo Picklist population
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "assignedTo Picklist population", "Start");
			List<ResourceDetailsVO> resourcesList = new ArrayList<ResourceDetailsVO>();
			resourcesList = buildVO.getResourceDetailsDropdown();
			if(null!=buildVO.getAssignedResourcesList()){
				for (ResourceDetailsVO assignedResource : buildVO.getAssignedResourcesList()) {
					ResourceDetailsVO toBeRemoved = new ResourceDetailsVO();
					for (ResourceDetailsVO resource : resourcesList) {
						if(assignedResource.getUserId().equals(resource.getUserId())) {
							toBeRemoved=resource;
							break;
						}
					}
					resourcesList.remove(toBeRemoved);
				}
			}
			buildVO.setResourcesList(resourcesList);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "assignedTo Picklist population", "End");
			
			//TODO - TO display subsystem list
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "To display subsystem list", "Start");
			Integer systemId = buildVO.getSystemId();
			List<SubSystemVO> subSystemList = new ArrayList<>();
			try {
				for (SystemDetailsVO systemDetailsVO : buildVO.getSystemDetailsDropdown()) {
					if (systemDetailsVO.getSystemID() == systemId) {
						subSystemList = systemDetailsVO.getSubsystemDetails();
					}
				}
			} catch (CustomException e) {
				System.out.println("In catch of populating subsystem for builddetails");
				e.printStackTrace();
			}
			buildVO.setSubSystemList(subSystemList);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "To display subsystem list", "End");
			
			//TODO - Setting userDetails
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting userDetails", "");
			buildVO.setCurrentRoleId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getRoleId());
			buildVO.setEmailId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getEmailId());
			
			mav.addObject("buildVO", buildVO);
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Build Insert - End");
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.build.edit.url}", method = RequestMethod.POST)
	public ModelAndView buildEdit(@ModelAttribute("buildListVO") BuildListVO buildListVO) throws CustomException {
		final String METHOD_NAME = "buildEdit";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Build Edit Controller Method", "Build Edit - Start");
		
		//clearing the session attribute
		if(null!=((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Clearing Build Session", "Start");
			((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO().setBuildDO(null);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Clearing Build Session", "End");
		}
		
		ModelAndView mav = new ModelAndView("buildList");
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Build Edit - End");
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.build.list.url}", method = RequestMethod.POST)
	public ModelAndView buildList(@ModelAttribute("buildListVO") @Valid BuildListVO buildListVO, BindingResult result) throws CustomException {
		final String METHOD_NAME = "buildList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Build List Controller Method", "Build List - Start");
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling buildHandler.getBuildList()", "Start");
			buildHandler.getBuildList(buildListVO, httpSession);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from buildHandler.getBuildList()", "End");
		}
		catch (CustomException e) {
			System.out.println("BuildController catch block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildListResponse Exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		ModelAndView mav = new ModelAndView("buildList");
		buildListVO.setBuild(null);
		mav.addObject("buildListVO", buildListVO);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Build List - End");
		return mav;
	}
	

	@RequestMapping(value = "${eztrack.postlogin.build.details.url}", method = RequestMethod.POST)
	public ModelAndView buildDetails(@ModelAttribute("buildListVO") BuildListVO buildListVO) throws CustomException {
		final String METHOD_NAME = "buildDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Build Details Controller Method", "Build Details - Start");
		
		BuildVO buildVO = new BuildVO();
		buildVO = buildListVO.getBuild();
		buildVO.setTokenId(buildListVO.getTokenId());
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling buildHandler.getBuildDetails()", "Start");
			buildHandler.getBuildDetails(buildVO, httpSession);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from buildHandler.getBuildDetails()", "End");
		}
		catch (CustomException e) {
			System.out.println("BuildController - Build Details Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildDetailsResponse Exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		//TODO - Role restriction matrix
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting RoleRestriction Matrix", "");
		if(buildVO.getStatusCode().equals("S")){
			buildVO.setRoleRestrictionMatrixPattern(ICommonConstants.BUILD_NEW_RESTRICTION_PATTERN);
		}
		else if (buildVO.getStatusCode().equals("A")) {
			buildVO.setRoleRestrictionMatrixPattern(ICommonConstants.BUILD_EDIT_RESTRICTION_PATTERN);
		}
		
		//TODO - PerNumber Dropdown population
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Populating Pernumber Dropdown", "");
		Map<Integer,String> perNumbersMap = new HashMap<Integer,String>();
		try {
			perNumbersMap = buildHandler.getPerList(httpSession);
			if(null!=perNumbersMap) {
				buildVO.setPerNumbersMap(perNumbersMap);
			}
		} catch(CustomException e) {
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		//TODO -assignedTo Picklist population
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "assignedTo Picklist population", "Start");
		List<ResourceDetailsVO> resourcesList = new ArrayList<ResourceDetailsVO>();
		resourcesList = buildVO.getResourceDetailsDropdown();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Loaded resourceList", "");
		if(null!=buildVO.getAssignedResourcesList()){
			for (ResourceDetailsVO assignedResource : buildVO.getAssignedResourcesList()) {
				ResourceDetailsVO toBeRemoved = new ResourceDetailsVO();
				for (ResourceDetailsVO resource : resourcesList) {
					if(assignedResource.getUserId().equals(resource.getUserId())) {
						toBeRemoved=resource;
						break;
					}
				}
				resourcesList.remove(toBeRemoved);
			}
		}
		buildVO.setResourcesList(resourcesList);
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "assignedTo Picklist population", "End");
		
		//TODO - TO display subsystem list
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "To display subsystem list", "Start");
		Integer systemId = buildVO.getSystemId();
		List<SubSystemVO> subSystemList = new ArrayList<>();
		try {
			for (SystemDetailsVO systemDetailsVO : buildVO.getSystemDetailsDropdown()) {
				if (systemDetailsVO.getSystemID() == systemId) {
					subSystemList = systemDetailsVO.getSubsystemDetails();
				}
			}
		} catch (CustomException e) {
			System.out.println("In catch of populating subsystem for builddetails");
			e.printStackTrace();
		}
		buildVO.setSubSystemList(subSystemList);
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "To display subsystem list", "End");

		//TODO - Setting Userdetails
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting userDetails", "");
		buildVO.setCurrentRoleId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getRoleId());
		buildVO.setEmailId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getEmailId());
		
		ModelAndView mav = new ModelAndView("build");
		mav.addObject("buildVO", buildVO);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Build Details - End");
		return mav;
	}
	
	
	@RequestMapping(value = "${eztrack.postlogin.build.delete.url}", method = RequestMethod.POST)
	public ModelAndView buildDelete(@ModelAttribute("buildVO")BuildVO buildVO) throws CustomException {
		final String METHOD_NAME = "buildDelete";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Build Delete Controller Method", "Build Delete - Start");
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling buildHandler.deleteBuild()", "Start");
			buildHandler.deleteBuild(buildVO, httpSession);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from buildHandler.deleteBuild()", "End");
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildsDeleteResponse Exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		BuildListVO buildListVO = new BuildListVO();
		buildListVO.setResponseMap(buildVO.getResponseMap());
		ModelAndView modelAndView = new ModelAndView("buildList");
		modelAndView.addObject("buildListVO", buildListVO);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning from Build Delete Controller Method", "Build Delete - END");
		return modelAndView;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.build.subSystemDropdown.url}", method=RequestMethod.POST)
	public @ResponseBody List<SubSystemVO> getSubsystemList(@RequestBody int systemIdString) {
		final String METHOD_NAME="getSubsystemList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Build - getSubsystemList Controller Method", "");
		
		BuildVO buildVO = new BuildVO();
		List<SubSystemVO> subSystemList = new ArrayList<>();
		try {
			for (SystemDetailsVO systemDetailsVO : buildVO.getSystemDetailsDropdown()) {
				if (systemDetailsVO.getSystemID() == systemIdString) {
					return systemDetailsVO.getSubsystemDetails();
				}
			}
		} catch (CustomException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Could not fetch the subsystem details", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the SubsystemList", "");
		return subSystemList;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.build.cc.accordianClick.url}", method = RequestMethod.POST)
	public ModelAndView buildCcAccordianClick(@ModelAttribute("buildVO") @Valid BuildVO buildVO, BindingResult result)
			throws Exception {
		final String methodName = "buildCcAccordianClick";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, "", "START");

		int selectedBuildCcId = (null == buildVO.getBuildChangeControl()) ? 0
				: buildVO.getBuildChangeControl().getBuildCCId();

		// populate Build CC id details whenever user select the CC id from the
		// Build CC list.
		if (selectedBuildCcId > 0) {
		//	buildHandler.populateBuildCcDetails(buildVO, httpSession);
			buildHandler.populateBuildCcIdDetail(buildVO, httpSession, selectedBuildCcId);
			buildVO.getBuildChangeControl().setShowCcIdFlag(ICommonConstants.Y_STRING);

		} else {
			// populate build CC list
			buildHandler.populateBuildCcDetails(buildVO, httpSession);

		}

		ModelAndView mav = new ModelAndView();
		mav.addObject("buildVO", buildVO);
		mav.setViewName("buildChangeControl");

		LoggerManager.writeInfoLog(CLASS_NAME, methodName, "", "END");
		return mav;
	}
	
	
	@RequestMapping(value = "${eztrack.postlogin.build.cc.save.url}", method = RequestMethod.POST)
	public ModelAndView buildCcSave(@ModelAttribute("buildVO") @Valid BuildVO buildVO, BindingResult result)
			throws CustomException{
		final String methodName = "buildCcSave";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, "", "START");

		boolean success = buildHandler.saveBuildCcDetails(buildVO, httpSession);
		
		if(!success){
			LoggerManager.writeInfoLog(CLASS_NAME, methodName, "BUildCC Save Action", "Failed");
			throw new CustomException("SVXX01","Save BUICD CC is not Sucessful");
		}

		ModelAndView mav = new ModelAndView();
		mav.addObject("buildVO", buildVO);
		mav.setViewName("buildChangeControl");

		LoggerManager.writeInfoLog(CLASS_NAME, methodName, "", "END");

		return mav;
	}

}
