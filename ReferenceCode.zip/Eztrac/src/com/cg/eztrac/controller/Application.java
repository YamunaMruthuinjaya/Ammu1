package com.cg.eztrac.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cg.eztrac.service.request.LoginInfoReq;

public class Application {

	private static final Logger log = LoggerFactory.getLogger(Application.class);

	String loginurl="http://10.147.254.11:8080/login";

	public static void main(String args[]) {
		// SpringApplication.run(Application.class);
		// Value request=new Value();
		// request.setQuote("Kumar");

		LoginInfoReq request = new LoginInfoReq();
		request.setLoginId("schitraj");
		request.setPassowrd("schitraj");
		
		
		/*LoginInfoRes response = (LoginInfoRes) EztracRestClient.invokeRestService(request, "http://10.219.13.151:8099/login",
				LoginInfoRes.class.getName());
		System.out.println(response);*/
//		System.out.println("00000000000000000000000000000" +response.getRolepermission().get(0).getSubSection().get(0).getSubSectionId());
	}

}
