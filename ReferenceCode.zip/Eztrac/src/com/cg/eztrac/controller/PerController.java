package com.cg.eztrac.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.exception.CustomException;
//import com.cg.eztrac.exception.PerListNotFoundException;
import com.cg.eztrac.handler.PerHandler;
import com.cg.eztrac.validator.PerCCValidator;
import com.cg.eztrac.validator.PerValidator;
import com.cg.eztrac.vo.AttachmentVO;
import com.cg.eztrac.vo.PMDetailsVO;
import com.cg.eztrac.vo.PMODetailsVO;
import com.cg.eztrac.vo.PerChangeControlVO;
import com.cg.eztrac.vo.PerListVO;
import com.cg.eztrac.vo.PerVO;
import com.cg.eztrac.vo.PurchaseOrderVO;
import com.cg.eztrac.vo.SystemDetailsVO;
import com.google.gson.Gson;

@Controller
@PropertySource("classpath:appurlcontroller.properties")
public class PerController {

	private static final String CLASS_NAME = "PerController";

	@Autowired
	HttpSession httpSession;

	@Autowired
	PerValidator perValidator;

	@Autowired
	PerHandler perHandler;
	
	@Autowired 
	PerCCValidator perCCValidator;

	/*@Autowired
	PerListVO perListVO;*/

	@RequestMapping(value = "${eztrack.postlogin.per.new.url}", method = RequestMethod.POST)
	public ModelAndView perNew() throws CustomException {
		final String METHOD_NAME = "perNew";

		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per New Controller Method", "Per New Start");
		
		//TODO - clearing the session attribute
		if(null!=((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Clearing PER Session", "Start");
			((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().setPerDO(null);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Clearing PER Session", "End");
		}

		PerVO perVo = new PerVO();

		// Role Restriction Matrix
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting RoleRestriction Matrix", "");
		perVo.setRoleRestrictionMatrixPattern(ICommonConstants.PER_NEW_RESTRICTION_PATTERN);

		//TODO - Managers to notify Picklist population
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Managers to notify Picklist population", "");
		List<PMDetailsVO> managersList = new ArrayList<PMDetailsVO>();
		managersList = perVo.getPMDetailsDropdown();
		perVo.setManagersList(managersList);
		
		//TODO - Setting userDetails
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting userDetails", "");
		perVo.setCurrentRoleId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getRoleId());
		perVo.setEmailId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getEmailId());
		
		//TODO - To set the default Per phase as ESTIMATION
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting Per Phase to 'ESTIMATION' - Default phase", "");
		perVo.setCurrentPerPhase(ICommonConstants.ESTIMATION_PHASE);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model & View Object", "Per New End");
		ModelAndView mav = new ModelAndView("per");
		mav.addObject("perVo", perVo);
		return mav;
	}

	@RequestMapping(value = "${eztrack.postlogin.per.ajaxInsert.url}", method = RequestMethod.POST)
	public @ResponseBody String ajaxInsert(@RequestBody PerVO perVOUI, BindingResult result) {
		String METHOD_NAME = "ajaxInsert";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per Insert Ajax Controller Method", "Per Insert-Ajax Start");
		
		if (null != perVOUI) {
			
			//TODO - Forming managersToNotifyArray - from the string received from UI
			if(null!=perVOUI.getManagersToNotify() &&  !perVOUI.getManagersToNotify().equals("")) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming managersToNotifyArray from UI input", "Start");
				String[] managersToNotifyString = perVOUI.getManagersToNotify().split(",");
	      	  	Integer[] managersToNotifyArray = ArrayUtils.toObject(Arrays.stream(managersToNotifyString).mapToInt(Integer::parseInt).toArray());
	      	  	perVOUI.setManagersToNotifyArray(managersToNotifyArray);
	      	  	LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming managersToNotifyArray from UI input", "End");
			}
			
			//TODO - hardcoding notification type - Has to be fetched from common services
			if(null!=perVOUI.getNotification()) {
				perVOUI.getNotification().setNotifyTypeId(1);
			}
			
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling PerValidator", "PerValidator");
				perValidator.validate(perVOUI, result);
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from PerValidator", "PerValidator");
			}catch(CustomException e) {
				// TODO: handle exception
				LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Exception occured in PerValidator", e, "");
      			System.out.println("Server Side Validator Exception");
				e.printStackTrace();
				throw new CustomException(e.getErrCode(),e.getErrMsg());
			}
			
			if (!result.hasErrors()) {
				
				//forming the Managers to notify list for insertion
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Managers to notify list for insertion", "Start");
	  			List<PMDetailsVO> notifiedManagersList1 = new ArrayList<PMDetailsVO>();
	  			notifiedManagersList1 = perHandler.constructManagersToNotifyList(perVOUI.getManagersToNotifyArray(),httpSession);
	  			perVOUI.setItpmManagerList(notifiedManagersList1);
	  			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Managers to notify list for insertion", "End");
      			
      			//Forming the PurchaseOrder for insertion
      			if(null!=perVOUI.getPurchaseOrder()) {
      				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming PurchaseOrder for insertion", "Start");
      				PurchaseOrderVO purchaseOrder = perHandler.formPurchaseOrder(perVOUI.getPurchaseOrder(),httpSession);
          			perVOUI.setPurchaseOrder(purchaseOrder);
          			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming PurchaseOrder for insertion", "End");
      			}
      			
				try {
					LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling perHandler.insertPerDetails()", "");
					perHandler.insertPerDetails(perVOUI, httpSession);
					LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perHandler.insertPerDetails()", "");
				} catch (CustomException e) {
					LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "PerInsertResponse Exception", e, "Redirecting to custom exception");
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			} 
			else {
				// TODO: handle exception
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Server side error occured during Per Ajax Insert", "");
				return "error";
			}
		}
		
		//Building JSON Object from the response
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Building JSON Object from the Per Insert Response", "");
		String perJson = new Gson().toJson(perVOUI);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning back the Per Ajax Response", "Per Insert-Ajax End");
		return perJson;
	}

	@RequestMapping(value = "${eztrack.postlogin.per.submit.url}", method = RequestMethod.POST)
	public ModelAndView perSubmit(@ModelAttribute("perVo") @Valid PerVO perVo, BindingResult result) throws CustomException {
		final String METHOD_NAME = "perSubmit";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per Insert Controller Method", "Per Insert - Start");
		
		ModelAndView mav = new ModelAndView("per");

		// Invoke Validator for convertStringToDateFields
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Invoking convertStringToDateFields()", "");
		perHandler.convertStringToDateFields(perVo);

		//TODO - Forming managersToNotifyArray - from the string received from UI
		if(null!=perVo.getManagersToNotify() &&  !perVo.getManagersToNotify().equals("")) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming managersToNotifyArray from UI input", "Start");
			String[] managersToNotifyString = perVo.getManagersToNotify().split(",");
      	  	Integer[] managersToNotifyArray = ArrayUtils.toObject(Arrays.stream(managersToNotifyString).mapToInt(Integer::parseInt).toArray());
      	  	perVo.setManagersToNotifyArray(managersToNotifyArray);
      	  	LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming managersToNotifyArray from UI input", "End");
		}
		
		// Invoke Validator for Server Side Validations
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling PerValidator", "PerValidator");
			perValidator.validate(perVo, result);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from PerValidator", "PerValidator");
		}
		catch (CustomException e) {
			// TODO: handle exception
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Exception occured in PerValidator", e, "");
			System.out.println("Server Side Validator Exception");
			e.printStackTrace();
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		if (!result.hasErrors()) {
			
			//forming the Managers to notify list for insertion
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Managers to notify list for insertion", "Start");
  			List<PMDetailsVO> notifiedManagersList1 = new ArrayList<PMDetailsVO>();
  			notifiedManagersList1 = perHandler.constructManagersToNotifyList(perVo.getManagersToNotifyArray(),httpSession);
  			perVo.setItpmManagerList(notifiedManagersList1);
  			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Managers to notify list for insertion", "End");
			
  			//Forming the PurchaseOrder for insertion
  			if(null!=perVo.getPurchaseOrder()) {
  				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming PurchaseOrder for insertion", "Start");
  				PurchaseOrderVO purchaseOrder = perHandler.formPurchaseOrder(perVo.getPurchaseOrder(),httpSession);
  				perVo.setPurchaseOrder(purchaseOrder);
  				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming PurchaseOrder for insertion", "End");
  			}
  			
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling perHandler.insertPerDetails()", "");
				perHandler.insertPerDetails(perVo,httpSession);
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perHandler.insertPerDetails()", "");
			}
			catch (CustomException e) {
				// TODO: handle exception
				System.out.println("PerController - Insert PER Catch Block");
				e.printStackTrace();
				LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "PerInsertResponse Exception", e, "Redirecting to custom exception");
				throw new CustomException(e.getErrCode(),e.getErrMsg());
			}
			
			//TODO - Setting Role Restriction Matrix 
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting RoleRestriction Matrix", "");
			if(null!=perVo.getStatusCode()) {
				if(perVo.getStatusCode().equals("S")) {
					perVo.setRoleRestrictionMatrixPattern(ICommonConstants.PER_NEW_RESTRICTION_PATTERN);
				}
				else {
					perVo.setRoleRestrictionMatrixPattern(ICommonConstants.PER_EDIT_RESTRICTION_PATTERN);
				}
			}
			
			//TODO - Managers to Notify Picklist population
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Managers to Notify Picklist population", "Start");
			List<PMDetailsVO> managersList = new ArrayList<PMDetailsVO>();
			System.out.println("Before method call++++++++++++++"+new Date());
			managersList = perVo.getPMDetailsDropdown();
			System.out.println("After method call++++++++++++++"+new Date());
			if(null!=perVo.getItpmManagerList()){
				for (PMDetailsVO notifiedManager : perVo.getItpmManagerList()) {
					PMDetailsVO toBeRemoved = new PMDetailsVO();
					for (PMDetailsVO manager : managersList) {
						if(notifiedManager.getUserId().equals(manager.getUserId())) {
							toBeRemoved=manager;
							break;
						}
					}
					managersList.remove(toBeRemoved);
				}
			}
			perVo.setManagersList(managersList);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Managers to Notify Picklist population", "End");
			
			//TODO - Setting userDetails
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting userDetails", "");
			perVo.setCurrentRoleId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getRoleId());
			perVo.setEmailId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getEmailId());
			
			mav.addObject("perVo", perVo);
		} 
		else {
			mav.addObject("perVo", perVo);
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Per Insert - End");
		return mav;
	}

	@RequestMapping(value = "${eztrack.postlogin.per.edit.url}", method = RequestMethod.POST)
	public ModelAndView perEdit(@ModelAttribute("perListVO") PerListVO perListVO) throws CustomException {
		final String METHOD_NAME = "perEdit";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per Edit Controller Method", "Per Edit - Start");
		
		//TODO - clearing the session attribute
		if(null!=((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getPerDO()) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Clearing PER Session", "Start");
			((UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().setPerDO(null);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Clearing PER Session", "End");
			System.out.println("cleared session");
		}
		
		PerVO perVO = new PerVO();
		perListVO.setPer(perVO);
		ModelAndView mav = new ModelAndView("perList");
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Per Edit - End");
		return mav;
	}

	@RequestMapping(value = "${eztrack.postlogin.per.perList.url}", method = RequestMethod.POST)
	public ModelAndView perList(@ModelAttribute("perListVO") @Valid PerListVO perListVO, BindingResult result) throws CustomException {
		final String METHOD_NAME = "perList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per List Controller Method", "Per List - Start");
		
		PerVO perVO = perListVO.getPer();
		perListVO.setPer(perVO);
		
		// TODO
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling perHandler.getPerList()", "Start");
			perHandler.getPerList(perListVO, httpSession);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perHandler.getPerList()", "End");
		} catch (CustomException e) {
			System.out.println("PerController - PER List Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "PerListResponse Exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		ModelAndView mav = new ModelAndView("perList");
		perListVO.setPer(null);
 		mav.addObject("perListVO", perListVO);
 		
 		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Per List - End");
		return mav;
	}

	
	@RequestMapping(value = "${eztrack.postlogin.per.perDetails.url}", method = RequestMethod.POST)
	public ModelAndView perDetails(@ModelAttribute("perListVO") PerListVO perListVO) throws CustomException {
		final String METHOD_NAME = "perDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per Details Controller Method", "Per Details - Start");
		
		PerVO perVO = new PerVO();
		perVO = perListVO.getPer();
		perVO.setTokenId(perListVO.getTokenId());
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling perHandler.getPerDetails()", "Start");
			perVO = perHandler.getPerDetails(perVO, httpSession);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perHandler.getPerDetails()", "End");
		} catch (CustomException e) {
			System.out.println("PerController - PER Details Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "PerDetailsResponse Exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		//TODO - Setting Role Restriction Matrix 
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting RoleRestriction Matrix", "");
		if(null!=perVO.getStatusCode()) {
			if(perVO.getStatusCode().equals("S")) {
				perVO.setRoleRestrictionMatrixPattern(ICommonConstants.PER_NEW_RESTRICTION_PATTERN);
			}
			else {
				perVO.setRoleRestrictionMatrixPattern(ICommonConstants.PER_EDIT_RESTRICTION_PATTERN);
			}
		}
		
		//TODO -Managers to Notify Picklist population 
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Managers to Notify Picklist population", "Start");
		List<PMDetailsVO> managersList = new ArrayList<PMDetailsVO>();
		managersList = perVO.getPMDetailsDropdown();
		if(null!=perVO.getItpmManagerList()){
			for (PMDetailsVO notifiedManager : perVO.getItpmManagerList()) {
				PMDetailsVO toBeRemoved = new PMDetailsVO();
				for (PMDetailsVO manager : managersList) {
					if(notifiedManager.getUserId().equals(manager.getUserId())) {
						toBeRemoved=manager;
						break;
					}
				}
				managersList.remove(toBeRemoved);
			}
		}
		perVO.setManagersList(managersList);
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Managers to Notify Picklist population", "End");
		
		//TODO - Setting userDetails
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting userDetails", "");
		perVO.setCurrentRoleId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getCurrentRoleDO().getRoleId());
		perVO.setEmailId(((UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS)).getEmailId());
		
		ModelAndView mav = new ModelAndView("per");
		mav.addObject("perVo", perVO);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Per Details - End");
		return mav;
	}

	
	@RequestMapping(value = "${eztrack.postlogin.per.delete.url}", method = RequestMethod.POST)
	public ModelAndView perDelete(@ModelAttribute("perVo")PerVO perVO) throws CustomException {
		final String METHOD_NAME = "perDelete";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per Delete Controller Method", "Per Delete - Start");
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling perHandler.deletePer()", "Start");
			perHandler.deletePer(perVO, httpSession);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perHandler.deletePer()", "End");
			
		} catch (CustomException e) {
			System.out.println("PerController - PER Delete Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "PerDeleteResponse Exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		PerListVO perListVO = new PerListVO();
		perListVO.setResponseMap(perVO.getResponseMap());
		ModelAndView modelAndView = new ModelAndView("perList");
		modelAndView.addObject("perListVO", perListVO);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Per Delete - End");
		return modelAndView;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.perNumAjaxAutoComplete.url}", method=RequestMethod.POST)
	public @ResponseBody List<String> perNumberAutocomplete() {
		final String METHOD_NAME="perNumberAutocomplete";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per - perAutocomplete Controller Method", "");
		
		PerListVO perListVO = new PerListVO();
		PerVO perVONew = new PerVO();
		perListVO.setPer(perVONew);
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling perHandler.getPerList()", "Start");
			perHandler.getPerList(perListVO, httpSession);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perHandler.getPerList()", "End");
		} catch (CustomException e) {
			System.out.println("PerController - PER List (Autocompletion) Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "PerListResponse Exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		List<String> perNumberList = new ArrayList<String>();
		if(null!=perListVO) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching the List of PerNumbers from response and setting it to PerList", "");
			for (PerVO perVO : perListVO.getPerList()) {
				perNumberList.add(perVO.getPerNumber());
			}
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the perNumbersListList", "");
		return perNumberList;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.pmoAjaxAutoComplete.url}", method=RequestMethod.POST)
	public @ResponseBody List<String> projectCoorninatorAutocomplete() {
		final String METHOD_NAME="projectCoorninatorAutocomplete";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Build - pmoAutocomplete Controller Method", "");
		
		PerVO perVO = new PerVO();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching the PMO list fromm application context", "");
		List<PMODetailsVO> pmoList = perVO.getPMODetailsDropdown();

		List<String> pmoResponseList = new ArrayList<String>();
		if(null!=pmoList) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching the List of PMO's to respose object", "");
			for (PMODetailsVO pmoDetailsVO : pmoList) {
				pmoResponseList.add(pmoDetailsVO.getName());
			}
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the project co-ordinator list", "");
		return pmoResponseList;
	}
	
	//Change Control Code
	
	@RequestMapping(value = "${eztrack.postlogin.per.cc.perCCList.url}", method = RequestMethod.POST)
	public ModelAndView perCCList(@ModelAttribute("perVO") @Valid PerVO perVO, BindingResult result) throws CustomException {
 		final String METHOD_NAME = "perCCList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per CC List Controller Method", "Per CC List - Start");
		
		PerChangeControlVO perCcVO = perVO.getPerChangeControl();
		perVO.setPerChangeControl(perCcVO);
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling perHandler.getPerCCList()", "Start");
			perHandler.getPerCCList(perVO, httpSession);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perHandler.getPerCCList()", "End");
		} catch (CustomException e) {
			System.out.println("PerController - PER CC List Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "PerCCListResponse Exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		ModelAndView mav = new ModelAndView("perChangeControl");
 		mav.addObject("perVO", perVO);
 		
 		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Per CC List - End");
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.per.cc.perCCNew.url}", method = RequestMethod.POST)
	public ModelAndView perCCNew(@ModelAttribute("perVO") @Valid PerVO perVO, BindingResult result) throws CustomException {
 		final String METHOD_NAME = "perCCNew";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per CC New Controller Method", "Per CC New - Start");
		
		PerChangeControlVO perCcVO = new PerChangeControlVO();
		perCcVO.setDisplayFlag("Y");
		perVO.setPerChangeControl(perCcVO);
		
		// TODO
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling perHandler.getPerCCList()", "Start");
			perHandler.getPerCCList(perVO, httpSession);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perHandler.getPerCCList()", "End");
		} catch (CustomException e) {
			System.out.println("PerController - PER CC List Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "PerCCListResponse Exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		//populating the perTeam picklist
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "perTeam Picklist population", "Start");
		perVO.getPerChangeControl().setPerCCteams(perVO.getSystemDetailsDropdown());
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "perTeam Picklist population", "End");
		
		ModelAndView mav = new ModelAndView("perChangeControl");
 		mav.addObject("perVO", perVO);
 		
 		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Per CC List - End");
		return mav;
	}

	@RequestMapping(value = "${eztrack.postlogin.per.cc.perDetails.url}", method = RequestMethod.POST)
	public ModelAndView perCCDetails(@ModelAttribute("perVO") PerVO perVO) throws CustomException {
		final String METHOD_NAME = "perCCDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per CC Details Controller Method", "Per CC Details - Start");
		
		perVO.setTokenId(perVO.getTokenId());
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling perHandler.getPerCCDetails()", "Start");
			perVO = perHandler.getPerCCDetails(perVO, httpSession);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perHandler.getPerCCDetails()", "End");
		} catch (CustomException e) {
			System.out.println("PerController - PER CC Details Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "PerCCDetailsResponse Exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		/*//TODO - Setting Role Restriction Matrix 
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting RoleRestriction Matrix", "");
		if(null!=perVO.getStatusCode()) {
			if(perVO.getStatusCode().equals("S")) {
				perVO.setRoleRestrictionMatrixPattern(ICommonConstants.PER_NEW_RESTRICTION_PATTERN);
			}
			else {
				perVO.setRoleRestrictionMatrixPattern(ICommonConstants.PER_EDIT_RESTRICTION_PATTERN);
			}
		}*/
		
		
		//populating the perTeam Involved picklist
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "perTeam Involved Picklist population", "Start");
		List<SystemDetailsVO> systemList = new ArrayList<SystemDetailsVO>();
		systemList = perVO.getSystemDetailsDropdown();
		if(null!=perVO.getPerChangeControl().getPerCCteamsInvolved() || !(perVO.getPerChangeControl().getPerCCteamsInvolved()).isEmpty()){
			for (SystemDetailsVO teamsinvolved : perVO.getPerChangeControl().getPerCCteamsInvolved()) {
				SystemDetailsVO toBeRemoved = new SystemDetailsVO();
				for (SystemDetailsVO team : systemList) {
					if(teamsinvolved.getSystemID()==team.getSystemID()) {
						toBeRemoved=team;
						break;
					}
				}
				systemList.remove(toBeRemoved);
			}
		}
		perVO.getPerChangeControl().setPerCCteams(systemList);
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "perTeam Involved Picklist population", "End");
		
		//Setting the display flag
		perVO.getPerChangeControl().setDisplayFlag("Y");
		
		ModelAndView mav = new ModelAndView("perChangeControl");
		mav.addObject("perVO", perVO);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Per CC Details - End");
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.per.cc.save.url}", method = RequestMethod.POST)
	public ModelAndView perCCInsertOrUpdate(@ModelAttribute("perVO") @Valid PerVO perVO, BindingResult result) throws CustomException {
		final String METHOD_NAME = "perCCInsertOrUpdate";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per CC Insert Controller Method", "Per CC Insert - Start");
		ModelAndView mav = new ModelAndView("perChangeControl");

		//TODO - Forming teamsInvolvedArray - from the string received from UI
		if(null!=perVO.getPerChangeControl().getTeamsInvolved() &&  !perVO.getPerChangeControl().getTeamsInvolved().equals("")) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming teamsInvolvedArray from UI input", "Start");
			String[] teamsInvolvedArrayString = perVO.getPerChangeControl().getTeamsInvolved().split(",");
      	  	Integer[] teamsInvolvedArray = ArrayUtils.toObject(Arrays.stream(teamsInvolvedArrayString).mapToInt(Integer::parseInt).toArray());
      	  	perVO.getPerChangeControl().setPerCCTeamsInvolvedArray(teamsInvolvedArray);
      	  	LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming teamsInvolvedArray from UI input", "End");
		}
		
		// Invoke Validator for Server Side Validations
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling PerCCValidator", "PerCCValidator");
			//perCCValidator.validate(perVo, result);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from PerCCValidator", "PerCCValidator");
		}
		catch (CustomException e) {
			// TODO: handle exception
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Exception occured in PerCCValidator", e, "");
			System.out.println("Server Side Validator Exception");
			e.printStackTrace();
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
		if (!result.hasErrors()) {
			
			//forming the Teams involved list for insertion
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Teams involved list for insertion", "Start");
  			List<SystemDetailsVO> involvedTeamsList1 = new ArrayList<SystemDetailsVO>();
  			involvedTeamsList1 = perHandler.constructPerCCTeamsInvolvedList(perVO.getPerChangeControl().getPerCCTeamsInvolvedArray(),httpSession);
  			perVO.getPerChangeControl().setPerCCteamsInvolved(involvedTeamsList1);
  			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Teams involved list for insertion", "End");
  			
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling perHandler.insertPerCCDetails()", "");
				perHandler.insertPerCCDetails(perVO,httpSession);
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perHandler.insertPerCCDetails()", "");
			}
			catch (CustomException e) {
				// TODO: handle exception
				System.out.println("PerController - Insert PER CC Catch Block");
				e.printStackTrace();
				LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "PerCCInsertResponse Exception", e, "Redirecting to custom exception");
				throw new CustomException(e.getErrCode(),e.getErrMsg());
			}
			
			/*//TODO - Setting Role Restriction Matrix 
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting RoleRestriction Matrix", "");
			if(null!=perVo.getStatusCode()) {
				if(perVo.getStatusCode().equals("S")) {
					perVo.setRoleRestrictionMatrixPattern(ICommonConstants.PER_NEW_RESTRICTION_PATTERN);
				}
				else {
					perVo.setRoleRestrictionMatrixPattern(ICommonConstants.PER_EDIT_RESTRICTION_PATTERN);
				}
			}*/
			
			mav.addObject("perVO", perVO);
		} 
		else {
			mav.addObject("perVO", perVO);
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the Model Object to View", "Per CC Insert - End");
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.per.cc.ajaxInsert.url}", method = RequestMethod.POST)
	public @ResponseBody String perCCAjaxInsert(@RequestBody PerVO perVOUI, BindingResult result) {
		String METHOD_NAME = "perCCAjaxInsert";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per Insert Ajax Controller Method", "Per Insert-Ajax Start");
		
		if (null != perVOUI) {

			//TODO - Forming teamsInvolvedArray - from the string received from UI
			if(null!=perVOUI.getPerChangeControl().getTeamsInvolved() &&  !perVOUI.getPerChangeControl().getTeamsInvolved().equals("")) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming teamsInvolvedArray from UI input", "Start");
				String[] teamsInvolvedArrayString = perVOUI.getPerChangeControl().getTeamsInvolved().split(",");
	      	  	Integer[] teamsInvolvedArray = ArrayUtils.toObject(Arrays.stream(teamsInvolvedArrayString).mapToInt(Integer::parseInt).toArray());
	      	  	perVOUI.getPerChangeControl().setPerCCTeamsInvolvedArray(teamsInvolvedArray);
	      	  	LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming teamsInvolvedArray from UI input", "End");
			}
			
			// Invoke Validator for Server Side Validations
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling PerCCValidator", "PerCCValidator");
				//perCCValidator.validate(perVo, result);
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from PerCCValidator", "PerCCValidator");
			}
			catch (CustomException e) {
				// TODO: handle exception
				LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Exception occured in PerCCValidator", e, "");
				System.out.println("Server Side Validator Exception");
				e.printStackTrace();
				throw new CustomException(e.getErrCode(),e.getErrMsg());
			}
			
			if (!result.hasErrors()) {
				
				//forming the Teams involved list for insertion
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Teams involved list for insertion", "Start");
	  			List<SystemDetailsVO> involvedTeamsList1 = new ArrayList<SystemDetailsVO>();
	  			involvedTeamsList1 = perHandler.constructPerCCTeamsInvolvedList(perVOUI.getPerChangeControl().getPerCCTeamsInvolvedArray(),httpSession);
	  			perVOUI.getPerChangeControl().setPerCCteamsInvolved(involvedTeamsList1);
	  			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Teams involved list for insertion", "End");
	  			
				try {
					LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling perHandler.insertPerCCDetails()", "");
					//perHandler.insertPerCCDetails(perVOUI,httpSession);
					LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perHandler.insertPerCCDetails()", "");
				}
				catch (CustomException e) {
					// TODO: handle exception
					System.out.println("PerController - Insert PER CC Catch Block");
					e.printStackTrace();
					LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "PerCCInsertResponse Exception", e, "Redirecting to custom exception");
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			} 
			else {
				// TODO: handle exception
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Server side error occured during Per Ajax Insert", "");
				return "error";
			}
		}
		
		List<AttachmentVO> attachmentList = new ArrayList<AttachmentVO>();
		attachmentList.add(perVOUI.getPerChangeControl().getPerCCAttachment());
		perVOUI.getPerChangeControl().setAttachmentList(attachmentList);
		//Building JSON Object from the response
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Building JSON Object from the PerCC Insert Response", "");
		String perJson = new Gson().toJson(perVOUI);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning back the PerCC Ajax Response", "Per Insert-Ajax End");
		return perJson;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.per.cc.cancel.url}", method = RequestMethod.POST)
	public ModelAndView perCCCancel(@RequestParam("perIdForDetails") String perId) throws CustomException {
		final String METHOD_NAME = "perCCCancel";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Per cc cancel Controller Method", "");
		ModelAndView mav = null;
		PerListVO perListVO = new PerListVO();
		perListVO.setTokenId(CommonUtility.getTokenId());
		PerVO perVO = new PerVO();
		perVO.setPerId(Integer.parseInt(perId));
		perListVO.setPer(perVO);
		try{
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling perDetails method", "");
			mav = perDetails(perListVO);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from perDetails method", "");
		}
		catch (CustomException e) {
			System.out.println("PerController - PER Details Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "PerDetailsResponse Exception in per cc cancel method", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "return from Per cc cancel Controller Method", "");
		return mav;
		
	}
}
