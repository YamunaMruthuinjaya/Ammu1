package com.cg.eztrac.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.handler.LoginHandler;
import com.cg.eztrac.validator.LoginValidator;
import com.cg.eztrac.vo.HomePageVO;
import com.cg.eztrac.vo.InvoiceVO;
import com.cg.eztrac.vo.LoginVO;

@Controller
@PropertySource("classpath:appurlcontroller.properties")
public class LoginController {

	@Autowired
	LoginValidator loginValidator;
	String className = LoginController.class.getSimpleName();
	@Autowired
	HttpSession httpSession;
	@Autowired
	private ServletContextImpl servletContextImpl;

	@RequestMapping(value = "${eztrack.postlogin.home.url}", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView loginSubmit(ModelAndView mv, @ModelAttribute @Valid LoginVO loginVO,
			BindingResult bindingResult, Model model, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) throws CustomException {

		String methodName = "loginSubmit";
		LoggerManager.writeInfoLog(className, methodName,
				ICommonConstants.LOGIN_SERVICE_LOG_KEY + "Servicing loginSubmit", "START");
		HomePageVO homePageVO = new HomePageVO();
		InvoiceVO invoiceVO = new InvoiceVO();

		LoginHandler loginHandler = new LoginHandler();

		/** passing the login credentials to sign-in service */
		try {
			LoggerManager.writeInfoLog(className, methodName,
					ICommonConstants.LOGIN_SERVICE_LOG_KEY + "callSignInHandler()",
					"Before calling (helper)-callSignInHandler()");
			homePageVO = loginHandler.callSignInHandler(loginVO, servletContextImpl, httpSession);
			invoiceVO = loginHandler.callSetInvoiceDateService(servletContextImpl, httpSession);

			LoggerManager.writeInfoLog(className, methodName,
					ICommonConstants.LOGIN_SERVICE_LOG_KEY + "callSignInHandler()",
					"After calling (helper)-callSignInHandler()");
		} catch (CustomException exe) {
			LoggerManager.writeErrorLog(className, methodName, "Error in Login Handler", exe, exe.getMessage());
			throw new CustomException(exe.getErrCode(),exe.getErrMsg());
		}
		if (homePageVO != null) {
			if (homePageVO.getResultPage().equalsIgnoreCase("login")) {
				mv = new ModelAndView(homePageVO.getResultPage());
				bindingResult.rejectValue(homePageVO.getField(), homePageVO.getErrorMsg());
				model.addAttribute(homePageVO);
			} else {
				mv = new ModelAndView(homePageVO.getResultPage());
				model.addAttribute(homePageVO);
				model.addAttribute(invoiceVO);
			}
		} else {
			mv = new ModelAndView("login");
			logoutProperly(httpServletRequest, httpServletResponse);
		}
		LoggerManager.writeInfoLog(className, methodName,
				ICommonConstants.LOGIN_SERVICE_LOG_KEY + "Servicing loginSubmit", "END");
		return mv;
	}

	@RequestMapping(value = "${eztrack.postlogin.logout.url}", method = { RequestMethod.GET, RequestMethod.POST })
	public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
		String methodName = "logoutPage";
		LoggerManager.writeInfoLog(className, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY + "logoutPage",
				"Start");
		logoutProperly(request, response);
		LoggerManager.writeInfoLog(className, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY + "logoutPage", "End");
		return "redirect:/login?logout";
	}

	@RequestMapping(value = "${eztrack.prelogin.login.url}", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView login(ModelAndView mv, @ModelAttribute @Valid LoginVO loginVO, BindingResult bindingResult,
			Model model, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestParam(value = "hasValidateErr", required = false) boolean hasValidateErr) {
		String methodName = "login()";
		LoggerManager.writeInfoLog(className, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY + "login", "Start");

		if (hasValidateErr) {
			BindingResult br = (BindingResult) httpSession.getAttribute(ICommonConstants.BINDING_RESULT_KEY);
			if (null != br && br.hasErrors()) {
				LoggerManager.writeInfoLog(className, methodName,
						ICommonConstants.LOGIN_SERVICE_LOG_KEY + "serverside validation", "Has Validation Errors");

				model.addAttribute("usrErr", "true");
				httpSession.removeAttribute(ICommonConstants.BINDING_RESULT_KEY);
			} else {
				LoggerManager.writeInfoLog(className, methodName,
						ICommonConstants.LOGIN_SERVICE_LOG_KEY + "serverside validation",
						"Has no validation errors redirecting to login");
				// loginVO.setUsername(username);
				model.addAttribute("usrErr", "true");
			}
		}

		mv = new ModelAndView("login");
		mv.addObject(loginVO);

		logoutProperly(httpServletRequest, httpServletResponse);
		LoggerManager.writeInfoLog(className, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY + "login", "END");

		return mv;
	}

	@RequestMapping(value = "${eztrack.postlogin.accessdenied.url}", method = RequestMethod.POST)
	public ModelAndView accessDenied() {
		String methodName = "accessDenied";
		LoggerManager.writeInfoLog(className, methodName, "Hi I am in access denied", "START");
		ModelAndView model = new ModelAndView();
		model.addObject("message", "Access Denied!");
		model.setViewName("access_denied");
		LoggerManager.writeInfoLog(className, methodName, "Hi I am in access denied", "END");
		return model;
	}

	@RequestMapping(value = "${eztrack.postlogin.sessionexpiry.url}", method = RequestMethod.POST)
	public ModelAndView sessionExpiry(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		LoggerManager.writeInfoLog("LoginController", "sessionExpiry", "Hi I am in Session Expiry",
				"Hi I am in Session Expiry");
		ModelAndView model = new ModelAndView();
		model.addObject("message", "Session Expiry");
		model.setViewName("sessionexpiry");

		logoutProperly(httpServletRequest, httpServletResponse);
		return model;
	}

	// Method to logout previous user level Session & Spring Security details
	public void logoutProperly(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		String methodName = "logoutProperly()";

		LoggerManager.writeInfoLog(className, methodName,
				ICommonConstants.LOGIN_SERVICE_LOG_KEY + "clearing user data in Session", "START");
		// Logout all previous sessions.
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			new SecurityContextLogoutHandler().logout(httpServletRequest, httpServletResponse, auth);
			SecurityContextHolder.getContext().setAuthentication(null);
			httpSession.invalidate();
		}

		LoggerManager.writeInfoLog(className, methodName,
				ICommonConstants.LOGIN_SERVICE_LOG_KEY + "clearing user data in Session", "END");
	}
}
