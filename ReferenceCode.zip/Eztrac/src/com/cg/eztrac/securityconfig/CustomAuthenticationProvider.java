package com.cg.eztrac.securityconfig;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.RoleDO;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.validator.LoginValidator;
import com.cg.eztrac.vo.LoginVO;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

	private static final String CLASS_NAME = CustomAuthenticationProvider.class.getSimpleName();

	@Autowired
	LoginValidator loginValidator;
	
	@Autowired
	HttpSession httpSession;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		String methodName = "authenticate";

		try {
			String name = authentication.getName();
			String password = authentication.getCredentials().toString();

			// Validation for Login Page Begin
			LoginVO loginVO = new LoginVO();
			loginVO.setUsername(name);
			loginVO.setPassword(password);

			DataBinder db = new DataBinder(loginVO);
			BindingResult br = db.getBindingResult();

			// Server side validation for Login.html
			loginValidator.validate(loginVO, br);
			// Validation for Login Page End

			if (br.hasErrors()) {

				// If Validation errors then throw BadCredentialsException ,this
				// might happen when user escapes Client side validation.
				LoggerManager.writeDebugLog(CLASS_NAME, methodName, "Authentication cannot happen",
						methodName + "Credential are wrong");
				
				httpSession.setAttribute(ICommonConstants.BINDING_RESULT_KEY, br);
				LoggerManager.writeDebugLog(CLASS_NAME, methodName, "Authentication cannot happen",
						methodName + "Binding result is set into httpSession.");
								
				return null;

			} else {

				// sign in service call

				authentication = authenticateUserSignInCallAuth(name, password, authentication);

				// use the credentials and authenticate against the third-party
				// system
				if (null != authentication && authentication.isAuthenticated()) {
					return authentication;
				} else {
					LoggerManager.writeDebugLog(CLASS_NAME, methodName, "Authentication is not true",
							methodName + "Could Not Authenticate USER");
					return null;
				}
			}
		} catch (Exception exe) {
			LoggerManager.writeErrorLog(CLASS_NAME, methodName, exe.getMessage(), exe,
					"Exception in " + methodName + " Could Not Authenticate USER");
			return null;
		}
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

	public Authentication authenticateUserSignInCallAuth(String name, String password, Authentication authentication)
			throws CustomException {

		String methodName = "authenticateUserSignInCallAuth";

		UserDO userDO = new UserDO();
		userDO.setUsername(name);
		userDO.setPassword(password);

		userDO.authenticateUser();

		// Setting value to HttpSession object
		RequestContextHolder.getRequestAttributes().setAttribute(ICommonConstants.USER_DETAILS, userDO,
				RequestAttributes.SCOPE_SESSION);

		if (null != userDO && userDO.isSuccess()) {

			// Roles Code Start
			List<RoleDO> roleDOList = userDO.getRoles();
			List<SimpleGrantedAuthority> authorities = new ArrayList<>();

			for (RoleDO roleDO : roleDOList) {

				String roleName = "";
				if (roleDO.getRoleId().equals(ICommonConstants.ADMIN_ROLE_ID)) {
					roleName = ICommonConstants.ADMIN_STRING;
				} else if (roleDO.getRoleId().equals(ICommonConstants.PMO_ROLE_ID)) {
					roleName = ICommonConstants.PMO_STRING;
				} else if (roleDO.getRoleId().equals(ICommonConstants.PM_ROLE_ID)) {
					roleName = ICommonConstants.PM_STRING;
				} else if (roleDO.getRoleId().equals(ICommonConstants.PL_ROLE_ID)) {
					roleName = ICommonConstants.PL_STRING;
				} else if (roleDO.getRoleId().equals(ICommonConstants.TM_ROLE_ID)) {
					roleName = ICommonConstants.TM_STRING;
				} else if (roleDO.getRoleId().equals(ICommonConstants.SYFITPM_ROLE_ID)) {
					roleName = ICommonConstants.SYFITPM_STRING;
				}

				authorities.add(new SimpleGrantedAuthority(ICommonConstants.ROLE_UNDER_STRING + roleName));
			}

			authentication = new UsernamePasswordAuthenticationToken(name, null, authorities);
			// Roles code end

			return authentication;

		} else {
			LoggerManager.writeDebugLog(CLASS_NAME, methodName, "UserDO is either null nor success",
					methodName + "Could Not Authenticate USER");
			return null;
		}

	}

}
