/**
 * 
 */
package com.cg.eztrac.sessionmanager;

/**
 * @author nageorge
 *
 */
public class FactoryManager {
	public FactoryManager() {
		// TODO Auto-generated constructor stub
	}

	public AbstractManager getEztracAppDetails(String planType) {
		if (planType == null) {
			return null;
		}
		
		 if(planType.equalsIgnoreCase("session")) {  
	         return new SessionManagerImpl();  
	       }
		 
		 
		return null;
	}

}
