$(document).ready(function(){
	
	$(window).on('load', function() {
		$('#extraFilterData').hide();
	});
	
	//To set the BuildVO object's buildId to the selected build from the list 
	$(".buildListLink").click(function(){
		//next() is used to fetch the hidden field value which contains buildId of selected build
		$("#buildListBuildId").val($(this).next().val());
	});
	
	/*To show and hide extra filter div in Per list page*/
	$("#showExtraFilter").click(function() {
		$("#extraFilterData").toggle();
	});
	
	/*START : PerNumber AutoComplete in BuildList page*/
	
	var perListForSelection = [];
	//perListForSelection = getPerList();
	$("#perNumber").keypress(function() {
		if(perListForSelection.length==0){
			perListForSelection = getPerList();
		}
		else{
			$("#perNumber").autocomplete(perListForSelection); 
		}
	});
	
	function getPerList(){
		var perList = [];
		$.ajax({
		      type: "POST",
		      url: "/Eztrac/ajax/perNumAutocomplete",
		      dataType: "json", 
		      contentType: "application/json; charset=utf-8",
		      async: false,
		      success :
		      function(response) {
		    	  console.log(response);
		    	  response.forEach(function(item, i){
		    		  perList.push(item);
		    	  });
		      }
		});
		return perList;
	}
	
	/*END : PerNumber AutoComplete in BuildList page*/
	
	/*START : ProjectCoordiantor AutoComplete in BuildList page*/
	var pmoListForSelection = [];
	//pmoListForSelection = getPmoList();
	$("#projectCoordinatorName").keypress(function() {
		if(pmoListForSelection.length==0){
			pmoListForSelection = getPmoList();
		}
		else{
			$("#projectCoordinatorName").autocomplete(pmoListForSelection); 
		}
	});
	
	function getPmoList() {
		var pmoList = [];
		$.ajax({
		      type: "POST",
		      url: "/Eztrac/ajax/pmoAjaxAutoComplete",
		      dataType: "json", 
		      contentType: "application/json; charset=utf-8",
		      async: false,
		      success :
		      function(response) {
		    	  console.log(response);
		    	  response.forEach(function(item, i){
		    		  pmoList.push(item);
		    	  });
		      }
		});
		return pmoList;
	}
	/*END : ProjectCoordiantor AutoComplete in BuildList page*/
});