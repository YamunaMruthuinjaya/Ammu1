var app = app || ( function() {
	globalVariable={
			PROJECTS_PER_NEW:{formName:"switchRole-form",action:"/Eztrac/per_new"},
			PROJECTS_PER_EDIT:{formName:"switchRole-form",action:"/Eztrac/per_edit"},
			PROJECTS_BUILD_NEW:{formName:"switchRole-form",action:"/Eztrac/build_new"},
			PROJECTS_BUILD_EDIT:{formName:"switchRole-form",action:"/Eztrac/build_edit"},
			PROJECTS_TIMESHEET:{formName:"switchRole-form",action:"/Eztrac/timesheet"},
			PROJECTS_TIMESHEET_SAVE:{formName:"timeSheetForm",action:"/Eztrac/saveTimeSheet"},
			PROJECTS_TIMESHEET_SUBMIT:{formName:"timeSheetForm",action:"/Eztrac/submitTimeSheet"},
			PROJECTS_TIMESHEET_DELETE:{formName:"timeSheetForm",action:"/Eztrac/deleteTimeSheet"},
			REPORTS_CARDS_SERVICES_REPORT_INVOICE_REPORTS:{formName:"",action:"/Eztrac/reportCardService"},
			BUILD_SUBMIT:{formName:"buildForm",action:"/Eztrac/build_submit"},
			BUILD_SAVE:{formName:"buildForm",action:"/Eztrac/build_submit"},
			BUILD_DELETE:{formName:"buildForm",action:"/Eztrac/build_delete"},
			BUILD_LIST:{formName:"buildListForm",action:"/Eztrac/build_list"},
			BUILD_DETAIL:{formName:"buildListForm",action:"/Eztrac/build_details"},
			BUILD_CC_SAVE:{formName:"buildCcForm",action:"/Eztrac/build_cc_save"},
			BUILD_CC_SUBMIT:{formName:"buildCcForm",action:"/Eztrac/build_cc_submit"},
			BUILD_CC_CLICK:{formName:"buildForm",action:"/Eztrac/buildCCAccordianClick"},
			BUILD_CC_FCLICK:{formName:"buildCcForm",action:"/Eztrac/buildCCAccordianClick"},
			PER_SUBMIT:{formName:"perForm",action:"/Eztrac/per_submit"},
			PER_SAVE:{formName:"perForm",action:"/Eztrac/per_submit"},
			PER_DELETE:{formName:"perForm",action:"/Eztrac/per_delete"},
			PER_LIST:{formName:"perListForm",action:"/Eztrac/per_list"},
			PER_DETAIL:{formName:"perListForm",action:"/Eztrac/per_details"},
			LOG_OUT:{formName:"switchRole-form",action:"/Eztrac/logout"},
			PER_CC_CLICK:{formName:"perForm",action:"/Eztrac/perCCAccordianClick"},
			PER_CC_SAVE:{formName:"perCcForm",action:"/Eztrac/per_cc_save"},
			PER_CC_DETAIL:{formName:"perCcForm",action:"/Eztrac/per_cc_details"},
			PER_CC_NEW:{formName:"perCcForm",action:"/Eztrac/perCCNew"},
			PER_CC_CANCEL:{formName:"cancelPerCCForm",action:"/Eztrac/per_cc_cancel"},
			BUILD_CC_CLICK:{formName:"buildForm",action:"/Eztrac/buildCCAccordianClick"},
			HOME:{formName:"switchRole-form",action:"/Eztrac/home"},
			GO_BACK_HOME:{formName:"homeForm",action:"/Eztrac/home"}
			
			
	}; 
	return globalVariable;
}());
