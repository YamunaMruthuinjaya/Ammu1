/*$(window).on('load', function() {
	//$("#perCCFormDiv").hide();
	$('#perCCForm').parsley();
});*/

$(document).ready(function(){
	
		var cancelCC = "N";
		
		//To display the CC form based on requirement
		if($("#displayFlag").val()=="Y")
		{
			$('#perCCFormDiv').show();
		}
		else{
			$("#perCCFormDiv").hide();
		}
	
		//Onsubmit validate form
		$("#perCcForm").on('submit',function(e) {
			if(cancelCC=="N"){
				return;
			}
			else{
				 return validatePerCCForm();
			}
	   }); 
	
		//To skip parsley validation
		$("#addNewPerCc").click(function() {
			/*//var instance = $('#perCcForm').parsley();
			if ($('#perCcForm').parsley().validate('mandate')){
				alert("valid");
			}
			else{
				alert("not valid");
				return;
			}*/
			var form = $('#perCcForm'); 
			form.off('submit.Parsley'); 
		});
	
	
		//To set the PerVO object's perCCId to the selected perCC from the list 
		$(".perCCListLink").click(function(){
			//next() is used to fetch the hidden field value which contains perId of selected per
			$("#perCCListperId").val($(this).next().val());
			var form = $('#perCcForm'); 
			form.off('submit.Parsley'); 
		});
	
		//On change of date fields validation method is called
	   $(".dateValidations").change(function() {
		   validatePerCCForm();
	   });

       $("#ccPhase").change(function() {
    	
    	   var ccPhase= $('#ccPhase').val();    	  
    	   var n = ccPhase.localeCompare("Cancelled");     	  
    	   if(ccPhase == '366')
    		   {
    		   $("#perCCCancellationDateString").attr("required", "true");
    		   $("#perCCCancellationDateString").prop("readonly", false);
    		   }
    	   else
    		   {
    		   $("#perCCCancellationDateString").prop("readonly", true);
    		   }
    	 
       });
      
     
       $("#markAllCcClosedId").click( function() {    	   
    	   var fullDate = new Date();    	   
    	   var formattedCompDate = getDateInyyyyDDmmFormat(fullDate);
    	   alert(formattedCompDate);
    	   $("#perCCCompletionDateString").attr("required", "true");
    	   $('#perCCCompletionDateString').val(formattedCompDate);    	  
    	});
              
     //Function to get Date in a yyyy-DD-mm format
		var getDateInyyyyDDmmFormat = function(inputDate) {			
			var convertedDate = new Date(inputDate);
			var month = convertedDate.getMonth()+1;			
			var formattedDate = month+"-"+convertedDate.getDate()+"-"+convertedDate.getFullYear();
			return formattedDate;
		};
       
       function validatePerCCForm(){    	
    	   $('.error').html('');
           var successFlag = true;
           var ccNumber = $('#ccNumber').val();
           var category= $('#category').val();
           var ccPhase= $('#ccPhase').val();
           var ccStartDateString= $('#ccStartDateString').val();
           var ccEndDateString = $('#ccEndDateString').val();
           var perCCCancellationDateString =$('#perCCCancellationDateString').val();
           var perCCCompletionDateString =$('#perCCCompletionDateString').val();
           
           
           
         /* if(ccNumber==null || ccNumber==""){
    	     	   successFlag=false;
    	   }*/
       		
          /*    if(category==null || category==""){
        	   	successFlag=false;
       		}
           
           if(ccPhase==null || ccPhase==""){
        	   successFlag=false;
           }*/
          
           if(ccStartDateString!=null && ccStartDateString != "" && ccEndDateString!=null && ccEndDateString!="" && ccStartDateString > ccEndDateString){
        	//   alert("Inside completion date ");
                 $("#endDateError").text('End date should be after start date.');
                 successFlag = false;
           }
          /* else if(ccStartDateString==null && ccStartDateString =="" && ccEndDateString!= null &&  ccEndDateString!=""){
        	   $("#startDateErrorr").text('Start date is required.');
               successFlag = false;
           }*/
           

           if(ccStartDateString!=null && ccStartDateString!= "" && perCCCancellationDateString!=null && perCCCancellationDateString!= "" && ccStartDateString > perCCCancellationDateString){
            //alert("Inside cancel date ");
        	  $('#perCCcancelledDateError').text('cancelled Date should be after start date');
        	  successFlag = false;
           }
           
            if(ccStartDateString!=null && ccStartDateString!= "" && perCCCompletionDateString!=null && perCCCompletionDateString!="" && ccStartDateString > perCCCompletionDateString){
            	//alert('Inside comp date');
            	$('#perCCcompletionDateError').text('Completion date should be after start date');
        	   successFlag = false;
           }
            
           if (successFlag) {
               return true;
         } else {
        	 // alert('show per CC form');
        	 // $('#perCCtableshown').show();
               return false;
         }
           
          /* if(successFlag==false) {
        	               alert('show Per CC Form');
        	        	   $('#perCcForm').show();
        	   }*/
       
       }

      
		
       /*START : Picklist code for 'Teams Involved' */
       $("#addTeam") .on( 'click', function() {
			 $(".parsley-itpmRequiredError").text("");
	         var p = $("#teamInvolvedPickList").find( "#teamsInvolvedData option:selected");
	         p.clone().appendTo("#teamsInvolvedResult");
	         p.remove();
	         var teamsInvolved =[];
	         $("#teamsInvolvedResult option").each(function()
	         {
	       	  	teamsInvolved.push($(this).val());
	   	    	$("#teamsInvolved").val(teamsInvolved);
	         });
		});
       
		$("#addAllTeam").on( 'click', function() {
			var p = $("#teamInvolvedPickList").find("#teamsInvolvedData option");
			p.clone().appendTo("#teamsInvolvedResult");
			p.remove();
			var teamsInvolved =[];
			$("#teamsInvolvedResult option").each(function()
			{
				teamsInvolved.push($(this).val());
				$("#teamsInvolved").val(teamsInvolved);
			});
		});

		$("#removeTeam") .on( 'click',function() {
              var p = $("#teamInvolvedPickList").find("#teamsInvolvedResult option:selected");
              p.clone().appendTo("#teamsInvolvedData");
              p.remove();
              var teamsInvolved =[];
              $("#teamsInvolvedResult option").each(function()
              {
            	  teamsInvolved.push($(this).val());
            	  $("#teamsInvolved").val(teamsInvolved);
              });
		});

		$("#removeAllTeam").on('click',function() {
			var p = $("#teamInvolvedPickList").find("#teamsInvolvedResult option");
			p.clone().appendTo("#teamsInvolvedData");
			p.remove();
			$("#teamsInvolved").val("");
		});
		/* END : Picklist code for 'Teams Involved' */
		
		//Assign the value for teamsInvolved on load of CC
		 var teamsInvolved =[];
		$("#teamsInvolvedResult option").each(function()
		{
			teamsInvolved.push($(this).val());
			$("#teamsInvolved").val(teamsInvolved);
		});
		
		$("#ccSave").on('click',function() {
			 var teamsInvolved =[];
			$("#teamsInvolvedResult option").each(function()
			{
				teamsInvolved.push($(this).val());
				$("#teamsInvolved").val(teamsInvolved);
			});
		});
		
		$(".goToPerPage").on('click',function() {
			if (confirm("Do you want discard the PER CC changes ??!!")) {
		        var perId = $("#perIdinCC").val();
		        $("#perIdForDetails").val(perId);
		        cancelCC="Y";
		    } else {
		    	cancelCC="N";
		    	return;
		    }
		});
		
		// When the user clicks the button, open the modal 
		$("#ccAttachmentButton").click(function(){
			/*var formInstance = $('#perCCForm').parsley();
			if (formInstance.validate('mandate')){
				alert("valid");
				attachmentModal.style.display = "block";
			}
			else{
				alert("not valid");
	            return;
			}*/
			attachmentModal.style.display = "block";
			
		});
		
		 //To clear the modal data on click of cancel button
	    $(".modalCancel").click(function(){
	 	   var cancelledModal = $(this).attr('data-modal-cancel');
	 	   var childModalAttr = "data-child-"+cancelledModal;
	 	   var modalElement = $('[' + childModalAttr + ']').get();
	 	   for(var c=0;c<modalElement.length;c++){
	 		   $(modalElement[c]).val("");
	 	   }
	    });
	    
	    $(".modalSubmit").click(function(){
	    	   
	    	   var modalToBesaved = this.id;
	    	   var form = $('#perCCForm');
	    	   
	    	  // if(form.parsley().validate({group: modalToBesaved}) && form.parsley().validate({group: 'parent'}) && validatePerCCForm() ){
	   				
			    	   var perVOUI = {};
			    	   
			    	   	//setting Status Code
			    	   $("#statusFlag").val("A");
						
			    	 //Forming Parent object
						var parentAttr = "data-parent";
						var parent = $('[' + parentAttr + ']').get();
						for(var i=0;i<parent.length;i++){
							var field = $(parent[i]).attr(parentAttr);
							var childAttr = "data-child-"+field;
							var child = $('[' + childAttr + ']').get();
							if(child.length>0){
								this[field] = {};
								for(var j=0;j<child.length;j++){
									var childField = $(child[j]).attr(childAttr);
									var childAttr1 = "data-child-"+childField;
									var child1 = $('[' + childAttr1 + ']').get();
									if(child1.length>0){
										this[childField] = {};
										for(var k=0;k<child1.length;k++){
											var childField1 = $(child1[k]).attr(childAttr1);
											var childVal1 = child1[k].value;
											if(childVal1 == ""){
												this[childField] [childField1]= null;
											}
											else{
												this[childField] [childField1]= childVal1;
											}
										}
										this [field][childField] = this[childField];
									}
									else{
										var childVal = child[j].value;
										if(childVal == ""){
											this[field] [childField] = null;
										}
										else{
											this[field] [childField] = childVal;
										}
									}
									
								}
								perVOUI [field] =this[field];
							}
							else{
								var parentVal = parent[i].value;
							
								if(parentVal == ""){
									perVOUI [field] = null;
								}
								else{
									perVOUI [field] = parentVal;
								}
								
							}
						}
						console.log(perVOUI);
						 $.ajax({
				                type: "POST",
				                url: "/Eztrac/ajax/perCCAjaxInsert",
				                data: JSON.stringify(perVOUI), 
				                dataType: "json", 
				                contentType: "application/json; charset=utf-8",
				                success :function(response) {
							       // do what ever you want with data
							    	  console.log("Response from controller");
							    	  console.log(response);
							    	  var listOfAttachments;
							    	  var s = response;
							    	  if(s.perChangeControl.attachmentList!=null){
							    		  for(var i=0;i<s.perChangeControl.attachmentList.length;i++){
							    			  listOfAttachments+= "<tr><td>"+s.perChangeControl.attachmentList[i].url+"</td><td>"+s.perChangeControl.attachmentList[i].createdBy+"</td><td>"+s.perChangeControl.attachmentList[i].createdOnString+"</td></tr>";
								    	  }
					                       if(listOfAttachments != ""){
					                    	 $("#attachmentLinkUrl").val("");
				                             $("#attachmentTableBody").html(listOfAttachments);
					                       }
					                       $("#ccId").val(s.perChangeControl.ccId);
							    	  }
				                }
				          });
	   			/*}
	   			else{
	   				return;
	   			}*/
	       });
	    
	  //When the user clicks on 'X' button - to close modal
		$("#attachmentModalClose").click(function(){
	        $('#attachmentModal').hide();
		});
		
		// When the user clicks anywhere outside of the modal, close it
	    window.onclick = function(event) {
	       if (event.target == attachmentModal) {
	             attachmentModal.style.display = "none";
	       }  
	    }
		
});
          