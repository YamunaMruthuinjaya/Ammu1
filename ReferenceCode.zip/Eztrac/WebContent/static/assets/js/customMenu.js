/* ---------------------------------------------- /*
 * Preloader
 /* ---------------------------------------------- */
(function(){
	
    $(document).ready(function() {
    
    	if($(".custom-menu-ul").length){
    		buildCustomMenu();
    	}
    	
    	function buildCustomMenu(){
    		var customMenuVal = $("#customizeJsonMap").val();
    		var genericDropDownAnchor;
    		var genericDropDownLI  = $("<li>").addClass("dropdown");
    		var subSectionAnchor= $("<a>");
    		var genericDropDownMenuUL = $("<ul>").addClass("dropdown-menu");
    		var customMenuClass = ".custom-menu-ul";
    		var first=0;
    		var second=0;
    		var previousSection="";
    		var previousSection1=[];
    		var previousSection3="";
    		var index=0;
    		var flag=false;
    		
    		/**  for loop to generate the data from json */
    		$.each(JSON.parse(customMenuVal), function(key, value) {
    			$.each(value, function(i) {
    				genericDropDownAnchor = $("<a/>").addClass("dropdown-toggle").attr({"data-toggle": "dropdown", "href": "#"});
    				genericDropDownLI  = $("<li>").addClass("dropdown");
    				console.log(value[i]);
    				var sectionVO = value[i];
    				var elligbleFlagSection = sectionVO.elligbleFlag, sectionId = sectionVO.sectionId, sectionName = sectionVO.sectionName;
    				var subSectionVOList = sectionVO.subSectionVO;
    				/**  to dynamically display the side bar */
    				
					if(sectionId==32){
						buildCustomSideBar(subSectionVOList);
					}
					/**  to dynamically display the menu */
					else {
						if(elligbleFlagSection) {
	    					sectionNameArr = sectionName.split("|"); // projects|per
	    					var len = sectionNameArr.length;
	    					
	    					/**  if the menu is having section as multi level as in per,build */
	    					if(len>1) {
								var dropDownDownChr =true;
								var ULSubSection=$("<ul>").addClass("dropdown-menu");
								/** for loop generates all the sub-sections  */
	        					$.each(subSectionVOList, function(i) {
	        						var subSectionVO = subSectionVOList[i];
		        					var elligFlagSubSection = subSectionVO.elligbleFlag, subSectionId = subSectionVO.subSectionId, subSectionName = subSectionVO.subSectionName;
		        					var anchorClass = "";
		        					/** if user is restricted to click onto sub-section then adding class to disable the click */
		        					if(elligFlagSubSection){
		        						anchorClass = "form-submit-_-"+(sectionName.trim().replace(/\|/g, '_').replace(/\s/g, '_')+"_"+subSectionName.trim().replace(/\s/g, '_')).toUpperCase();
		        					} else {
		        						anchorClass = "disableAnchor";
		        					}
		        					var anchorSubSection = $("<a>").addClass(anchorClass).attr({"th:href": "#", "href": "#"});
		        					var LISubSection  = $("<li>");
		        					anchorSubSection.text(subSectionName);
		        					LISubSection.append(anchorSubSection);
		        					ULSubSection.append(LISubSection);
	        					});
	        					
	        					
	    				
	        					genericDropDownAnchor.text(sectionNameArr[1]);
	        					genericDropDownLI.append(genericDropDownAnchor);
	        					genericDropDownLI.append(ULSubSection);
	        					var mainBarLi= $("<li>").addClass("dropdown");
	             				var mainBarAnchor= $("<a>").addClass("dropdown-toggle").attr({"data-toggle": "dropdown", "href": "#"});
	             				var mainUL=$("<ul>").addClass("dropdown-menu");
	             				/**  creating the top menu if menu is created for the new section for the first time */
	             				if((first==0)){
									mainBarAnchor.text(sectionNameArr[0]);
									mainBarLi.append(mainBarAnchor);
									mainBarLi.append(mainUL);
		             				mainUL.append(genericDropDownLI);
		             				mainUL.addClass(sectionNameArr[0]);
		        					$('[class*=" custom-menu-ul"]').append(mainBarLi);
		        					first = 1;
	             				} 
	             				
	             				
	             				/**  creating the top menu if menu is created for  second time for the previous section */
	             				
	             				
	             			/*	$.each(previousSection1, function(i) {
	             					var previousSection2=previousSection1[i];
	             				 if(previousSection2==sectionNameArr[0]){
	             					$('[class*="'+sectionNameArr[0]+'"]').append(genericDropDownLI);
	             				}
	             				});*/
	             				
	             				var count;
	             				for (count = 0; count < previousSection1.length; count++) { 
	             					var previousSection2= previousSection1[count];
	             					if(previousSection2==sectionNameArr[0]){
		             					$('[class*="'+sectionNameArr[0]+'"]').append(genericDropDownLI);
		             				}
	             				}
	             				
	             			
	             					/**  creating the menu with new section *//*
		             				 if((previousSection2!=sectionNameArr[0])&&(previousSection!=sectionNameArr[0])){
		             					mainBarAnchor.text(sectionNameArr[0]);
										mainBarLi.append(mainBarAnchor);
										mainBarLi.append(mainUL);
			             				mainUL.append(genericDropDownLI);
			             				mainUL.addClass(sectionNameArr[0]);
			        					$('[class*=" custom-menu-ul"]').append(mainBarLi);
		             				}*/
		             				 
	             				var flag=previousSection1.indexOf(sectionNameArr[0]);
	             				if(flag==-1){
	             			
		             					mainBarAnchor.text(sectionNameArr[0]);
										mainBarLi.append(mainBarAnchor);
										mainBarLi.append(mainUL);
			             				mainUL.append(genericDropDownLI);
			             				mainUL.addClass(sectionNameArr[0]);
			        					$('[class*=" custom-menu-ul"]').append(mainBarLi);
		             				}
	             				previousSection=sectionNameArr[0];
	             				previousSection3=sectionNameArr[0];
	             				previousSection1[index]=sectionNameArr[0];
	        					index++;
	        				}
	    					/** else, where the sub-section length is 1 */
	    					else if(len == 1){
	        				var genericDropDownLILevel1  = $("<li>").addClass("dropdown");
        					var ULSubSection=$("<ul>").addClass("dropdown-menu");
        					/** for loop generates all the sub-sections  */
             				$.each(subSectionVOList, function(i) {
	             				var subSectionVO = subSectionVOList[i];
	        					var elligFlagSubSection = subSectionVO.elligbleFlag, subSectionId = subSectionVO.subSectionId, subSectionName = subSectionVO.subSectionName;
	        					var anchorClass = "";
	        					/** if user is restricted to click onto sub-section then adding class to disable the click */
	        					if(elligFlagSubSection){
	        						anchorClass = "form-submit-_-"+(sectionName.trim().replace(/\|/g, '_').replace(/\s/g, '_')+"_"+subSectionName.trim().replace(/\s/g, '_')).toUpperCase();
	        					} else {
	        						anchorClass = "disableAnchor";
	        					}
	        					var anchorForSingleLevel1 = $("<a>").addClass(anchorClass).attr({"th:href": "#", "href": "#"});
	        					anchorForSingleLevel1.text(subSectionName);
	        					genericDropDownLILevel1.append(anchorForSingleLevel1);
	        					ULSubSection.append(genericDropDownLILevel1);
        					});
             				/** creating the menu where main bar section has  sub-sections length as 1 and greater than 1 */
             				
             				
             				if(previousSection==sectionNameArr[0]){
        					$('[class*="'+sectionNameArr[0]+'"]').append(genericDropDownLILevel1);
        					}
             				
             				
             				/** creating the menu where main bar section has only all subsections whose length is 1 */
             				else if(!(previousSection==sectionNameArr[0])){
             					var mainBarLi= $("<li>").addClass("dropdown");
                 				var mainBarAnchor= $("<a/>").addClass("dropdown-toggle").attr({"data-toggle": "dropdown", "href": "#"});
                 				mainBarAnchor.text(sectionName);
            					mainBarLi.append(mainBarAnchor);
            					mainBarLi.append(ULSubSection);
            					$('[class*=" custom-menu-ul"]').append(mainBarLi);
             				}
             				previousSection1[index]=sectionName;
        					index++;
             				
	        				}
	    				}
					}
    			});
    		});
    	}
    	
    	/** to build side bar dynamically */
    	function buildCustomSideBar(subSectionVOList){
			$.each(subSectionVOList, function(i) {
				var subSectionVO = subSectionVOList[i];
				var elligFlagSubSection = subSectionVO.elligbleFlag, subSectionId = subSectionVO.subSectionId, subSectionName = subSectionVO.subSectionName;
				var anchorSideBar = $("<a>").attr({"th:href": "#", "href": "#"});
				var genericSideBarLI  = $("<li>");
				var span=$("<span>");
				var spanClass="";
				var anchorClassSidebar="";
				if(subSectionName.toLowerCase()=="home"){
					spanClass="glyphicon glyphicon-home";
				} else if(subSectionName.trim().toLowerCase()=="my profile"){
					spanClass="fa fa-user-circle-o";
				} else if(subSectionName.toLowerCase()=="services"){
					spanClass="fa fa-thumbs-o-up";
				} else if(subSectionName.toLowerCase()=="about"){
					spanClass="glyphicon glyphicon-info-sign";
				} else if(subSectionName.toLowerCase()=="contact us"){
					spanClass="fa fa-phone";
				} else if(subSectionName.toLowerCase()=="change password"){
					spanClass="fa fa-pencil-square-o";
				} else if(subSectionName.toLowerCase()=="log out"){
					spanClass="fa fa-power-off";
				}
				anchorClassSidebar = "form-submit-_-"+(subSectionName.trim().replace(/\|/g, '_').replace(/\s/g, '_')).toUpperCase();
				span.addClass(spanClass).text(subSectionName);
				anchorSideBar.append(span);
				anchorSideBar.addClass(anchorClassSidebar);
				genericSideBarLI.append(anchorSideBar);
				$('[class*="side-menu-ul"]').append(genericSideBarLI);
			});
    	}
    	
    });
})(jQuery);
//{1 PMO={11=PROJECTS|PER$NEW#ENABLE,EDIT#ENABLE,UPLOAD#DISABLE,, 12=PROJECTS|BUILD$NEW#ENABLE,EDIT#ENABLE,, 13=PROJECTS|TIMESHEET,}}

