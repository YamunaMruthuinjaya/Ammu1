import java.io.*;
import java.util.ArrayList;
import java.util.List;
public class FetchTables {

	 public static void main(String [] args) {

	        // The name of the file to open.
	        String fileName = "D:\\Users\\ymruthui\\Desktop\\dbScript.txt";

	        // This will reference one line at a time
	        String line = null;
	        
	        List<String> tableNames = new ArrayList<String>();
	        String create = "CREATE";
	        String table = "TABLE";
	        try {
	            // FileReader reads text files in the default encoding.
	            FileReader fileReader =   new FileReader(fileName);

	            // Always wrap FileReader in BufferedReader.
	            BufferedReader bufferedReader = new BufferedReader(fileReader);

	            while((line = bufferedReader.readLine()) != null) {
	               // System.out.println(line);
	               // System.out.println("----------------");
	                String[] arr = line.split(" ");    
		            for(int i=0;i<arr.length;i++) {
		            	//System.out.println("++++"+arr[i]);
		            	if(create.equals(arr[i]) && table.equals(arr[i+1])) {
		            		System.out.println(arr[i+2]);
		            	}
		            }
	            }   
	           
	            // Always close files.
	            bufferedReader.close();         
	        }
	        catch(FileNotFoundException ex) {
	            System.out.println( "Unable to open file '" + fileName + "'");                
	        }
	        catch(IOException ex) {
	            System.out.println( "Error reading file '"  + fileName + "'");                  
	            // Or we could just do this: 
	            // ex.printStackTrace();
	        }
	    }
}


