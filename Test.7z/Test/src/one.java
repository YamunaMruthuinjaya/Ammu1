
public class one {

	public static void main(String[] args) {
		Object o = new two();
		System.out.println(o instanceof three);
	}
}
