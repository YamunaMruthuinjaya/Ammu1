package com.cg.classes;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class xlsmReadWrite {

public static void main(String[] args) throws IOException, InvalidFormatException {
		
		
		File excel = new File("C:/Users/ymruthui/Desktop/Eclipse_Luna/ammuworkspace/DataFetching/excelValidate.xlsm"); 
		File excel1 = new File("C:/Users/ymruthui/Desktop/Book4.xlsm"); 
		
		FileInputStream fis = new FileInputStream(excel); 
		FileOutputStream os = new FileOutputStream(excel1); 
		
		XSSFWorkbook book = new XSSFWorkbook(OPCPackage.open(excel));
	    XSSFSheet sheet = book.getSheetAt(0); 
	    
		Iterator<Row> itr = sheet.iterator(); 
		
		while (itr.hasNext()) {
			
			Row row = itr.next(); 
			
			Iterator<Cell> cellIterator = row.cellIterator(); 
			
			while (cellIterator.hasNext()) { 
				Cell cell = cellIterator.next(); 
				
				switch(cell.getCellType()){
					case Cell.CELL_TYPE_STRING: 
						System.out.print(cell.getStringCellValue() + "\t");
						break;
					case Cell.CELL_TYPE_NUMERIC: 
						System.out.print(cell.getNumericCellValue() + "\t");
						break;
					case Cell.CELL_TYPE_BLANK:
						System.out.println("no entry \t");
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						System.out.println(cell.getBooleanCellValue() + "\t");
						break;
				}
			} 
			
			System.out.println(""); 
				
			}
		
		
		book.write(os);
		fis.close();
		os.close(); 
		
		
	}

}
